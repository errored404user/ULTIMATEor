// SPDX-License-Identifier: GPL-3.0-or-later
// background.js - service worker.
// Owns ONE resilient WebSocket to the local bridge (ws://127.0.0.1:PORT).
// Keeping the socket here (not in the content script) avoids https→ws mixed
// content issues and centralises reconnect / timeout logic.
//
// Contract with content.js: every sendMessage ALWAYS gets a response object,
// even when the bridge is offline. The agentic loop must never hang waiting.

// 2.21.0: curated Blockbench bb_* table + local argument checks (pure JS, also
// required by tests/test-blockbench-mode.js). Classic worker → importScripts.
try { importScripts("src/core/blockbench_tools.js"); } catch (e) { console.warn("[total-bg] blockbench_tools.js not loaded", e); }
// Figma Desktop speaks MCP Streamable HTTP on its fixed loopback endpoint.
try { importScripts("src/core/figma_mcp.js"); } catch (e) { console.warn("[total-bg] figma_mcp.js not loaded", e); }
const PORT_ROBLOX = 17613;
const PORT_LOCAL = 17615; // AgentScript — native FS/terminal engine
const RUST_ROBLOX_HTTP = "http://127.0.0.1:3000";
const ENGINE_KEY = "rs-engine";
// Legacy or unknown engine ids safely fall back to the Roblox bridge.
function normalizeEngine(v) { return v === "local" ? "local" : "roblox"; }
let engine = "roblox"; // "roblox" | "local"
let rustMode = false; // true if Rust agent on 3000 is reachable (preferred)
chrome.storage?.local.get(ENGINE_KEY, (o) => {
  const want = normalizeEngine(o && o[ENGINE_KEY]);
  if (want !== engine) {
    engine = want;
    log(`engine init corrected to ${engineLabel()} -> ${engineUrl()}`);
    try { ws?.close(); } catch {}
    connected = false;
    reconnectDelay = RECONNECT_MIN;
    connect();
    broadcastStatus();
  }
});
// Probe Rust agent on 3000 at startup — if reachable, use HTTP pipe (CORS bypass) as primary
(async () => {
  try {
    const r = await fetch(`${RUST_ROBLOX_HTTP}/api/status`, { method: "GET" });
    if (r.ok) {
      rustMode = true;
      log("Rust agent detected on 3000 — HTTP pipe enabled (CORS bypass via background)");
    }
  } catch {}
})();
function engineUrl() { return `ws://127.0.0.1:${engine === "local" ? PORT_LOCAL : PORT_ROBLOX}`; }
// 1.42.0 — the AI's web tools (web_fetch / api_request) must never be able to
// probe this machine or the LAN: the local bridge (127.0.0.1:3000), routers,
// cloud metadata (169.254.169.254), *.local hosts. Public internet only.
function privateNetworkReason(rawUrl) {
  let u;
  try { u = new URL(String(rawUrl || "")); } catch { return "invalid url"; }
  if (u.protocol !== "http:" && u.protocol !== "https:") return "only http(s) urls are allowed";
  const host = u.hostname.replace(/^\[|\]$/g, "").toLowerCase();
  if (!host) return "missing host";
  if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || host.endsWith(".internal") || host === "0.0.0.0") return "local host names are not reachable from the AI's web tools";
  const v4 = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (v4) {
    const [a, b] = [Number(v4[1]), Number(v4[2])];
    if (a === 127 || a === 10 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224) return "private / loopback / link-local addresses are not reachable from the AI's web tools";
    return "";
  }
  if (host.includes(":")) {
    if (host === "::1" || host === "::" || /^fe[89ab]/.test(host) || /^f[cd]/.test(host) || host.startsWith("::ffff:")) return "private / loopback IPv6 addresses are not reachable from the AI's web tools";
  }
  return "";
}
function engineLabel() { return engine === "local" ? "AgentScript" : "Roblox"; }
chrome.storage?.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[ENGINE_KEY]) {
    const want = normalizeEngine(changes[ENGINE_KEY].newValue);
    if (want === engine) return; // dedupe rs-set-engine double fire
    engine = want;
    log(`engine switched to ${engineLabel()} -> ${engineUrl()} — FULL ISOLATION`);
    try { ws?.close(); } catch {}
    connected = false;
    mcpAlive = false;
    toolsCache = [];
    toolsCacheAt = 0;
    serversCache = [];
    setMcpLifecycle(manualStudioDisconnect ? "CLOSED" : "DISCONNECTED", {errorCode:"MCP_CONNECTION_CLOSED"});
    studioConnected = null;
    studioApp = null;
    studioProc = null;
    failAllPending(`engine switched to ${engine}`);
    reconnectDelay = RECONNECT_MIN;
    connect();
    broadcastStatus();
  }
});

// Chat sites where an TotalScript provider content script runs. Status pushes go
// to every tab matching these. Add the new provider's URL pattern here (and in
// manifest.json content_scripts + host_permissions) when integrating another AI.
const PROVIDER_URLS = ["https://chat.deepseek.com/*", "https://deepseek.com/*", "https://chatgpt.com/*", "https://chat.openai.com/*", "https://claude.ai/*", "https://www.claude.ai/*", "https://claude.com/*", "https://www.claude.com/*", "https://gemini.google.com/*", "https://aistudio.google.com/*", "https://kimi.ai/*", "https://www.kimi.ai/*", "https://chat.z.ai/*", "https://chat.qwen.ai/*", "https://arena.ai/*", "https://c.vani.ai/*", "https://huggingface.co/chat/*", "https://openrouter.ai/*", "https://www.openrouter.ai/*", "https://aifreeforever.com/*", "https://app.langdock.com/chat*"];
// CodeCraft API has no web chat: TotalScript hosts one at codecraft.html (an
// extension page), which runs the same bundle and needs the same broadcasts.
const CODECRAFT_PAGE = "codecraft.html";
// Queried separately from the web patterns: if an extension-URL pattern were
// ever rejected by tabs.query it must not take the whole broadcast down.
async function providerTabs() {
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: PROVIDER_URLS }); } catch {}
  try { tabs = tabs.concat(await chrome.tabs.query({ url: chrome.runtime.getURL(CODECRAFT_PAGE) + "*" })); } catch {}
  return tabs;
}

const RECONNECT_MIN = 500;
const RECONNECT_MAX = 5000;
const HEARTBEAT_MS = 10000;
// If no message (incl. pong) arrives within this window while we believe we're
// connected, the socket is half-open: force a reconnect instead of letting
// pending requests slowly time out.
const STALE_SOCKET_MS = 140000; // above 120s tool timeout so a long execute_luau never looks half-open
const REQUEST_TIMEOUT_DEFAULT = 130000; // tool execution timeout; connection/discovery use separate bounds
const MCP_CONNECT_TIMEOUT_MS = 6000;
const MCP_DISCOVERY_TIMEOUT_MS = 10000;
const MCP_CACHE_TTL_MS = 60000;
const MCP_MAX_RECONNECT_ATTEMPTS = 3;
const STATUS_SETTLE_MS = 1500; // a status poll waits this long for an in-flight (re)connect before reporting "down"

let ws = null;
let connected = false;
let reconnectDelay = RECONNECT_MIN;
let reconnectTimer = null;
let reconnectAttempts = 0;
let mcpLifecycle = "DISCONNECTED";
let connectionId = null;
let mcpConnectStarted=0;
let toolsCacheAt = 0;
const mcpDiagnostics = [];
function mcpTrace(operation, detail={}) { const row={timestamp:new Date().toISOString(),connectionId,requestId:detail.requestId||null,server:engineLabel(),transport:"websocket",operation,duration:detail.duration||0,status:detail.status||mcpLifecycle,errorCode:detail.errorCode||null,retryCount:detail.retryCount??reconnectAttempts};mcpDiagnostics.push(row);if(mcpDiagnostics.length>100)mcpDiagnostics.shift(); }
function setMcpLifecycle(next, detail={}) { mcpLifecycle=next;mcpTrace("lifecycle",{...detail,status:next}); }
// ── 2.12.0 Activity Center ──────────────────────────────────────────────────
// A bounded, human-readable event log for the popup (Activity tab, bell,
// error viewer). Lives in chrome.storage.session (cleared when the browser
// closes; survives MV3 worker restarts), capped at ACTIVITY_MAX entries.
// Entries: {at, kind: tool|conn|engine|server|blender|creation, level: ok|info|warn|error,
// text, tool?, code?, ms?, engine?}. No prompts, no conversation text.
const ACTIVITY_MAX = 200;
const ACTIVITY_KEY = "tsActivity";
let activityRing = null; // lazy-loaded from session storage
let activityWrite = Promise.resolve();
async function activityLoad() {
  if (activityRing) return activityRing;
  try { const o = await chrome.storage.session.get(ACTIVITY_KEY); activityRing = Array.isArray(o[ACTIVITY_KEY]) ? o[ACTIVITY_KEY].slice(-ACTIVITY_MAX) : []; }
  catch { activityRing = []; }
  return activityRing;
}
function pushActivity(kind, level, text, extra) {
  const item = { at: Date.now(), kind: String(kind || "info"), level: String(level || "info"), text: String(text || "").slice(0, 300), ...(extra || {}) };
  if (item.tool != null) item.tool = String(item.tool).slice(0, 120);
  if (item.code != null) item.code = String(item.code).slice(0, 60);
  if (item.engine == null) item.engine = engine;
  activityWrite = activityWrite.then(async () => {
    const ring = await activityLoad();
    ring.push(item);
    while (ring.length > ACTIVITY_MAX) ring.shift();
    try { await chrome.storage.session.set({ [ACTIVITY_KEY]: ring }); } catch {}
  }).catch(() => {});
  chrome.runtime.sendMessage({ type: "rs-activity", item }).catch(() => {});
  return item;
}
async function clearActivity() {
  activityRing = [];
  try { await chrome.storage.session.remove(ACTIVITY_KEY); } catch {}
}
let manualStudioDisconnect = false;
let heartbeatTimer = null;
let lastMessageAt = 0; // timestamp of the last frame received from the bridge
let nextId = 1;
const pending = new Map(); // id -> {resolve, timer}
let toolsCache = [];
let mcpAlive = false;
let serversCache = [];
// true/false = a PLACE is loaded and usable in Roblox Studio; null = unknown.
// The MCP process stays alive when Studio is closed or its MCP option is off,
// so this is probed separately (bridge "studio_status").
let studioConnected = null;
// true/false = a Roblox Studio app is connected to the MCP server at all; null =
// unknown. studioApp=true with studioConnected=false means "Studio open but no
// place"; studioApp=false means "Studio closed OR its MCP option disabled".
let studioApp = null;
// true/false = a Roblox Studio WINDOW/PROCESS exists on this machine (checked
// bridge-side via tasklist); null = unknown/old bridge. Distinguishes the two
// studioApp=false sub-cases the UI must word differently: Studio genuinely not
// launched ("open Roblox Studio") vs Studio OPEN but its MCP plugin never
// registered with the bridge - the documented fix for the latter is opening
// Assistant Settings > MCP Servers inside Studio (validated live 3x), which
// "open Roblox Studio" wording completely fails to convey.
let studioProc = null;
let robloxProc = false;
// Editor-backed status. A local bridge socket is not an editor connection.
let robloxEditorConnected = false;
let localReady = false; // agent's workspace is up (from /api/status local_ready)
let localFull = false; // AgentScript FULL PC ACCESS (agent is source of truth)
let fullSyncedOnce = false; // one-shot FULL re-sync after an agent restart (refreshProcStatus)
let localRoot = ""; // workspace path, injected into the AI's state line
let blenderAddon = false; // blender-mcp addon listening on TCP 9876
let blenderError = "";
let blenderScriptsReady = false;
// 2.21.0 Blockbench: link state mirrored from total-core (the TotalScript
// Bridge plugin inside Blockbench long-polls total-core; see bbRefresh()).
let bbConnected = false;        // last authoritative total-core liveness result
let bbStatusKnown = false;      // false means unknown/unverified, not disconnected
let bbStatusError = "";
let bbCheckedAt = 0;            // wall clock for UI payloads
let bbCheckedAtMono = 0;        // monotonic timestamp for freshness decisions
let bbRefreshTask = null;
let bbCoreApiOk = false;
let bbServerMismatch = "";
let bbCallMismatch = "";
let bbPluginFile = "";          // where total-core keeps TotalScript-Blockbench.js
const BB_STATUS_MAX_AGE_MS = 12000; // dedicated total-core heartbeat is queried every 5s; never claim stale connectivity
const FIGMA_STATUS_MAX_AGE_MS = 12000;
const FIGMA_MANUAL_KEY = "rs-figma-manual-disconnect";
let figmaConnected = false;
let figmaStatusKnown = false;
let figmaStatusError = "";
let figmaCheckedAt = 0;
let figmaCheckedAtMono = 0;
let figmaStatusBroadcastAt = 0;
let figmaToolsCache = [];
let figmaRefreshTask = null;
let figmaManualDisconnected = false;
// Figma Design's in-file plugin bridge is separate from Figma Desktop MCP.
// This status comes from total-core's dedicated token-paired plugin hub only.
let figmaPluginConnected = false;
let figmaPluginVerified = false;
let figmaPluginStatus = "unknown";
let figmaPluginStatusError = "Figma Design plugin has not been verified";
let figmaPluginCheckedAt = 0;
let figmaPluginTools = 0;
let figmaPluginPairingPending = false;
let figmaPluginPairingExpiresAt = null;
let figmaPluginStatusBroadcastAt = 0;
let figmaManualReady = new Promise((resolve) => {
  let settled = false;
  const finish = () => { if (!settled) { settled = true; resolve(); } };
  const fallback = setTimeout(finish, 500);
  try {
    chrome.storage.local.get(FIGMA_MANUAL_KEY, (value) => {
      clearTimeout(fallback);
      figmaManualDisconnected = !!(value && value[FIGMA_MANUAL_KEY]);
      finish();
    });
  } catch { clearTimeout(fallback); finish(); }
});
const figmaClient = typeof TotalFigmaMcp !== "undefined" && TotalFigmaMcp.Client
  ? new TotalFigmaMcp.Client()
  : null;
const BLENDER_TOOL_NAMES = new Set([
  "get_scene_info", "get_object_info", "execute_blender_code", "get_viewport_screenshot",
  "blender_export_fbx", "blender_import_fbx", "blender_export_obj", "blender_import_obj",
  "blender_mesh_dump", "blender_send_to_studio", "blender_execute_code",
  "blender_get_scene_info", "blender_get_object_info", "blender_screenshot",
  "export_blender_fbx", "import_blender_fbx",
]);
function btool(name, description, props, required) {
  return { name, server: "blender", description, inputSchema: { type: "object", properties: props || {}, required: required || [] } };
}
const BLENDER_TOOLS = [
  btool("get_scene_info", "Inspect the live Blender scene (objects, cameras, lights, collections).", {}, []),
  btool("get_object_info", "Details for one object in the Blender scene.", { name: { type: "string" } }, ["name"]),
  btool("execute_blender_code", "Run Python (bpy) inside Blender. Prefer the named blender_* tools.", { code: { type: "string" } }, ["code"]),
  btool("get_viewport_screenshot", "Capture the Blender 3D viewport.", { max_size: { type: "integer" } }, []),
  btool("blender_introspect", "READ-ONLY self-check before fixing a failed Blender call: Blender version, render engines, every object (name/type), materials, collections and - for the named or active object - its real transform, dimensions, modifiers with their settable properties, material slots, mesh counts (verts/faces/tris/UV layers/smooth faces) and custom props. Changes nothing.", { name: { type: "string" }, object: { type: "string" } }, []),
  btool("blender_asset_plan", "PLAN BEFORE MODELLING (no Blender call): turn a brief into a structured asset SPEC - category, style profile, dimensions (m), parts with primary/secondary/tertiary roles, scale-relative bevels, cuts/grooves/insets/tapers, smoothing policy, PBR materials + Roblox material hint, attachments, origin, triangle budget. Set detail_level to blockout | standard | hero | ultra (or numeric detail 0..1) to control recipe complexity; hero/ultra also add finishing bevels to hard-surface parts. Custom specs support shape:'lathe' with a normalized profile:[[radius,height],...] for a real turned mesh, shape:'extrusion' with a normalized 0..1 2D polygon capped through local Z, and shape:'sweep' with a normalized 0..1 profile + open path in part size + section_size in metres (capped ends); optional section_sizes [[w,h],...] and twist_degrees [...] provide one cross-section / roll per path station. Extrusions and sweeps include UVs, bevels, bounds / triangle estimates and closed-manifold QA, plus boolean cutters. Recipes: sword, blaster, crate, barrel, table, chair, lamp_post, pillar, wall_module, door_module, window_module, rock, tree, car + procedural generators (1.95.0) tree_procedural (recursive branch skeleton + leaf blobs on the real tips), terrain_tile (fBm heightfield; island / mesa / steep from the brief), rock_cluster, crystal_cluster, stairs, building, fence. Every material gets a procedural texture graph (bark grain, wood planks, brushed metal, voronoi stone, ...) - set materials.X.texture = flat to opt out. Styles: stylized_fantasy, realistic, scifi, low_poly, cartoon, anime, horror. Characters are not supported (says so).", { brief: { type: "string" }, recipe: { type: "string" }, style: { type: "string" }, style2: { type: "string", description: "second style for a hybrid" }, detail_level: { type: "string", enum: ["blockout", "standard", "hero", "ultra"], description: "recipe detail preset; hero/ultra for close-up or showcase assets" }, detail: { type: "number", description: "numeric detail override 0..1 (takes precedence over detail_level)" }, size: { type: "number", description: "main dimension in metres" }, primary: { type: "string", description: "colour name or #hex" }, accent: { type: "string" }, studs_per_meter: { type: "number", description: "default 3.5 (Roblox human scale)" }, collision: { type: "string", description: "box | hull | precise | none" } }, ["brief"]),
  btool("blender_asset_build", "Build a planned asset in Blender from a spec (from blender_asset_plan, edited as needed) or straight from a brief (plans first). For a brief, detail_level: hero|ultra (or numeric detail:0..1) controls the recipe detail and default hard-surface edge finishing. Custom spec part shapes include box/cylinder/sphere/cone/torus/ico, generator, lathe, extrusion (normalized 0..1 polygon, capped through local Z) and sweep (normalized profile + open path mapped across size, capped; section_size is the uniform default, optional section_sizes [[w,h],...] and twist_degrees [...] are per station); extrusions and sweeps carry UVs, bevels, bounds / triangle estimates and closed-manifold checks, with real cuts, grooves and procedural PBR textures. Creates a named collection + root empty, parts as separate named meshes (Asset_Part) with live Bevel / Mirror / Array / WeightedNormal stacks, baked boolean details, Principled materials, UVs, custom properties and ATT_* attachment empties. Returns per-part triangle counts, bounds, budget status and the structural validation report. Nothing reaches Studio until blender_send_to_studio.", { spec: { type: "object" }, brief: { type: "string" }, style: { type: "string" }, detail_level: { type: "string", enum: ["blockout", "standard", "hero", "ultra"] }, detail: { type: "number", description: "numeric detail override 0..1" }, replace: { type: "boolean", description: "replace an existing asset of the same name (default true)" } }, []),
  btool("blender_asset_validate", "Structural check of an asset built by blender_asset_build (or any collection / object name): non-manifold + loose + degenerate geometry, inconsistent normals, unapplied scale, missing materials / UVs, default names, triangle budget, overlap estimate, dims vs spec. Structural only - run blender_asset_inspect for the visual read.", { name: { type: "string" }, spec: { type: "object" } }, ["name"]),
  btool("blender_asset_inspect", "Render front / side / top / iso / closeup previews (all five by default) with a neutral 3-light rig and grey backdrop in a temporary Total_Inspect collection (removed afterwards; the asset is untouched). The PNGs are attached to the reply so you can judge silhouette, proportions, bevel read, material separation and intersections.", { name: { type: "string" }, views: { type: "array", items: { type: "string" }, description: "default: front, side, top, iso, closeup" }, size: { type: "integer", description: "pixels, default 768" }, keep: { type: "boolean" } }, ["name"]),
  btool("blender_asset_export", "Explicit, validated export of an asset: fbx (-Z forward, Y up, modifiers applied, FACE smoothing, custom props) | glb | obj. Refuses assets with structural errors unless force:true, then checks the file exists, is non-empty and has the right header, and lists referenced textures that are missing. Local file only - nothing is uploaded.", { name: { type: "string" }, format: { type: "string", description: "fbx | glb | obj" }, path: { type: "string" }, force: { type: "boolean" } }, ["name"]),
  btool("blender_asset_bake", "Bake the procedural material graphs of a built asset to PNG texture maps (base_color / roughness / metallic / normal / emission) with Cycles, into <workspace>/total_textures/Total_<asset>_<material>_<map>.png, and (apply:true, default) rewire the materials to the baked images so FBX/GLB exports carry real textures. Needs UVs (asset_build makes them). Local files only - nothing is uploaded and no Roblox asset ids are invented; the result says how to attach them as a SurfaceAppearance by hand.", { name: { type: "string", description: "asset / collection name" }, size: { type: "integer", description: "square map size 64-4096 (default 1024)" }, maps: { type: "array", items: { type: "string", enum: ["base_color", "roughness", "metallic", "normal", "emission"] } }, margin: { type: "integer", description: "bake margin px (default 4)" }, samples: { type: "integer", description: "Cycles samples (default 16)" }, apply: { type: "boolean", description: "rewire the materials to the baked PNGs (default true)" } }, ["name"]),
  btool("blender_light_rig", "Set up lighting from a preset, scaled to the target's real size: three_point | product (adds a white sweep backdrop) | sun | overcast | night | neon | dramatic | interior_warm. Lights live in the Total_Studio collection, replace the previous rig, and set a matching world. Use before blender_render_shot; blender_studio_clear removes everything again.", { preset: { type: "string", enum: ["three_point", "product", "sun", "overcast", "night", "neon", "dramatic", "interior_warm"] }, target: { type: "string", description: "asset / collection / object name (default: all meshes)" }, strength: { type: "number", description: "multiplier, default 1" }, warmth: { type: "number", description: "kelvin shift, e.g. -800 cooler / +800 warmer" }, backdrop: { type: "boolean", description: "add / skip the curved backdrop" } }, ["preset"]),
  btool("blender_camera_rig", "Add (or re-aim) the Total_Studio camera on a preset and frame the target with the real field of view: hero | product | front | side | back | top | closeup | wide | iso. Makes it the scene camera; optional depth of field focused on the target; turntable:true parents it to a pivot that turns 360 deg over frames.", { preset: { type: "string", enum: ["hero", "product", "front", "side", "back", "top", "closeup", "wide", "iso"] }, target: { type: "string" }, lens: { type: "number", description: "focal length mm (preset default)" }, dof: { type: "boolean" }, fstop: { type: "number" }, aspect: { type: "number", description: "render aspect, e.g. 1.777 or 1" }, name: { type: "string", description: "camera object name (default Total_Studio_Cam)" }, turntable: { type: "boolean" }, frames: { type: "integer", description: "turntable length (default 48)" }, margin: { type: "number", description: "framing margin, default 1.15" } }, ["preset"]),
  btool("blender_world_setup", "World / environment: studio_grey | white | black | night | sky (procedural Nishita sun sky: sun_elevation / sun_rotation deg) | hdri (a LOCAL .hdr/.exr path - nothing is downloaded).", { preset: { type: "string", enum: ["studio_grey", "white", "black", "night", "sky", "hdri"] }, strength: { type: "number" }, color: { type: "array", items: { type: "number" }, description: "override RGB 0-1" }, sun_elevation: { type: "number" }, sun_rotation: { type: "number" }, hdri: { type: "string", description: "local file path" } }, ["preset"]),
  btool("blender_render_setup", "Render settings in one call: engine eevee | cycles | workbench (mapped to this Blender's identifiers), quality preview (fast, 50 %) | standard | final, resolution, transparent film, denoise, samples, view transform (AgX / Filmic / Standard), exposure, output format png | jpg | exr, fps and output path. Reports what was actually set.", { engine: { type: "string", enum: ["eevee", "cycles", "workbench"] }, quality: { type: "string", enum: ["preview", "standard", "final"] }, width: { type: "integer" }, height: { type: "integer" }, transparent: { type: "boolean" }, denoise: { type: "boolean" }, samples: { type: "integer" }, view_transform: { type: "string" }, exposure: { type: "number" }, format: { type: "string", enum: ["png", "jpg", "exr"] }, fps: { type: "integer" }, output: { type: "string", description: "output file path / folder" } }, []),
  btool("blender_render_shot", "Render with the current engine / quality / world and attach the PNG(s): the scene camera, or one preset view per entry in views (hero, product, front, side, back, top, closeup, wide, iso - up to 7) re-aimed at target. Files: <workspace>/total_shot_<target>[_<view>].png. Slow with cycles + final - use render_setup quality:preview to iterate.", { target: { type: "string" }, views: { type: "array", items: { type: "string" } }, camera: { type: "string", description: "render this camera object" }, size: { type: "integer", description: "width px (128-4096), keeps the aspect" }, path: { type: "string", description: "output folder" }, lens: { type: "number" }, dof: { type: "boolean" }, fstop: { type: "number" }, margin: { type: "number" } }, []),
  btool("blender_turntable", "Render a 360 deg turntable of the target (camera on a pivot, linear): a PNG frame sequence (default) or an mp4 (H.264 via FFmpeg when this build has it) into <workspace>/total_turntable/, plus four quarter-turn stills attached to the reply.", { target: { type: "string" }, frames: { type: "integer", description: "8-720, default 48" }, size: { type: "integer", description: "width px (128-2048)" }, fps: { type: "integer" }, format: { type: "string", enum: ["png", "mp4"] }, path: { type: "string" }, preset: { type: "string", description: "camera preset when no turntable camera exists (default product)" }, lens: { type: "number" }, dof: { type: "boolean" }, fstop: { type: "number" }, margin: { type: "number" } }, []),
  btool("blender_studio_clear", "Remove the Total_Studio rig (lights, camera, pivot, backdrop) - assets and the user's own objects are untouched.", {}, []),
  btool("blender_send_to_studio", "ONE SHOT: read the live Blender meshes (selected objects, or objects[]; modifiers applied, world transforms, material base colour + base-colour image textures) and build them in Roblox Studio as real MeshParts (EditableMesh) under Workspace.Total_Imported, textures as live EditableImage SurfaceAppearances (not saved with the place unless publish:true). No file, no FBX. Limits per send: 20k triangles per mesh (blender_decimate first), 40k triangles total (send in groups). publish:true also uploads each mesh as a Mesh asset you own (permanent MeshId; asks for approval).", { objects: { type: "array", items: { type: "string" } }, dest: { type: "string", description: "parent in Workspace (default Workspace)" }, scale: { type: "number", description: "studs per Blender metre (default 20)" }, publish: { type: "boolean" }, append: { type: "boolean", description: "keep the previous Total_Imported and add to it" }, textures: { type: "boolean", description: "carry each material's base-colour image as a live EditableImage texture (default true)" }, texture_size: { type: "number", description: "texture pixels per side, 16..512 (default 256; 512 = ~1.4 MB per image)" } }, []),
  btool("blender_export_fbx", "Export meshes to an FBX (Forward -Z, Up Y). filepath optional. Also dumps meshes so blender_send_to_studio / asset_bridge_import can run with no path.", { filepath: { type: "string" }, objects: { type: "array", items: { type: "string" } }, path: { type: "string" } }, []),
  btool("blender_import_fbx", "Import an FBX into the live Blender scene. filepath optional — defaults to the last TotalScript export.", { filepath: { type: "string" }, path: { type: "string" } }, []),
  btool("blender_export_obj", "Export selected/all meshes to OBJ. filepath optional.", { filepath: { type: "string" }, objects: { type: "array", items: { type: "string" } }, path: { type: "string" } }, []),
  btool("blender_import_obj", "Import an OBJ into the live Blender scene.", { filepath: { type: "string" }, path: { type: "string" } }, ["filepath"]),
  btool("blender_add_cube", "Add a cube.", { name: { type: "string" }, size: { type: "number" }, location: { type: "array", items: { type: "number" } } }, []),
  btool("blender_add_sphere", "Add a UV sphere.", { name: { type: "string" }, radius: { type: "number" }, location: { type: "array" } }, []),
  btool("blender_add_cylinder", "Add a cylinder.", { name: { type: "string" }, radius: { type: "number" }, depth: { type: "number" }, location: { type: "array" } }, []),
  btool("blender_add_cone", "Add a cone.", { name: { type: "string" }, radius: { type: "number" }, depth: { type: "number" }, location: { type: "array" } }, []),
  btool("blender_add_plane", "Add a plane.", { name: { type: "string" }, size: { type: "number" }, location: { type: "array" } }, []),
  btool("blender_add_torus", "Add a torus.", { name: { type: "string" }, location: { type: "array" } }, []),
  btool("blender_add_monkey", "Add Suzanne (monkey head).", { name: { type: "string" }, location: { type: "array" } }, []),
  btool("blender_add_empty", "Add an Empty (use as a group parent).", { name: { type: "string" }, location: { type: "array" } }, []),
  btool("blender_add_camera", "Add a camera.", { name: { type: "string" }, location: { type: "array" } }, []),
  btool("blender_add_light", "Add a light (SUN/POINT/SPOT/AREA).", { name: { type: "string" }, type: { type: "string", enum: ["SUN","POINT","SPOT","AREA"] }, location: { type: "array" }, energy: { type: "number" } }, []),
  btool("blender_group", "Group objects: parent them to a new Empty and put them in a collection of the same name.", { name: { type: "string", description: "Group name" }, objects: { type: "array", items: { type: "string" }, description: "Object names; omit = selected/all meshes" } }, []),
  btool("blender_ungroup", "Ungroup: clear parent, keep world transforms, remove the group Empty.", { name: { type: "string" } }, []),
  btool("blender_parent", "Parent objects under an existing object/Empty.", { parent: { type: "string" }, objects: { type: "array", items: { type: "string" } }, keep_transform: { type: "boolean" } }, ["parent"]),
  btool("blender_unparent", "Clear parent, keep world transforms.", { objects: { type: "array", items: { type: "string" } } }, []),
  btool("blender_join", "Join mesh objects into one.", { objects: { type: "array", items: { type: "string" } }, name: { type: "string" } }, []),
  btool("blender_move_to_collection", "Move objects into a collection (created if missing).", { collection: { type: "string" }, objects: { type: "array", items: { type: "string" } } }, []),
  btool("blender_list_collections", "List collections and their objects.", {}, []),
  btool("blender_list_objects", "List every object: type, location, parent, collections.", {}, []),
  btool("blender_delete", "Delete objects.", { name: { type: "string" }, objects: { type: "array", items: { type: "string" } } }, []),
  btool("blender_duplicate", "Duplicate objects.", { name: { type: "string" }, objects: { type: "array", items: { type: "string" } }, offset: { type: "array", items: { type: "number" } } }, []),
  btool("blender_rename", "Rename an object.", { name: { type: "string" }, new_name: { type: "string" }, object: { type: "string" }, to: { type: "string" } }, ["new_name"]),
  btool("blender_select", "Select objects by name.", { name: { type: "string" }, objects: { type: "array", items: { type: "string" } } }, []),
  btool("blender_transform", "Set location / rotation (radians) / scale.", { name: { type: "string" }, objects: { type: "array" }, location: { type: "array" }, rotation: { type: "array" }, scale: { type: "array" }, rotation_deg: { type: "array", items: { type: "number" } }, dimensions: { type: "array", items: { type: "number" } } }, []),
  btool("blender_apply_transforms", "Apply rotation/scale (and optional location).", { objects: { type: "array" }, location: { type: "boolean" }, rotation: { type: "boolean" }, scale: { type: "boolean" } }, []),
  btool("blender_set_origin", "Set object origin (ORIGIN_GEOMETRY, ORIGIN_CURSOR, ORIGIN_CENTER_OF_MASS).", { name: { type: "string" }, type: { type: "string", enum: ["ORIGIN_GEOMETRY","ORIGIN_CURSOR","ORIGIN_CENTER_OF_MASS","ORIGIN_CENTER_OF_VOLUME","GEOMETRY_ORIGIN"] } }, []),
  btool("blender_shade_smooth", "Shade smooth.", { name: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_set_material", "Assign a Principled BSDF material. color = [r,g,b] or [r,g,b,a] 0–1.", { name: { type: "string" }, material: { type: "string" }, color: { type: "array" }, object: { type: "string" } }, []),
  btool("blender_add_modifier", "Add a modifier: SUBSURF, BEVEL, SOLIDIFY, MIRROR, ARRAY, BOOLEAN, DECIMATE. apply=true to apply.", { name: { type: "string" }, type: { type: "string", enum: ["SUBSURF","SUBDIVISION","BEVEL","SOLIDIFY","MIRROR","ARRAY","BOOLEAN","DECIMATE","TRIANGULATE","REMESH","WELD"] }, levels: { type: "integer" }, apply: { type: "boolean" }, target: { type: "string" }, width: { type: "number" }, segments: { type: "integer" }, thickness: { type: "number" }, count: { type: "integer" }, offset: { type: "array", items: { type: "number" } }, axis: { type: "string", enum: ["X","Y","Z"] }, ratio: { type: "number" }, operation: { type: "string", enum: ["DIFFERENCE","UNION","INTERSECT"] }, object: { type: "string" }, objects: { type: "array", items: { type: "string" } } }, []),
  btool("blender_boolean", "Boolean one mesh with another (DIFFERENCE/UNION/INTERSECT) and apply.", { name: { type: "string" }, target: { type: "string" }, operation: { type: "string", enum: ["DIFFERENCE","UNION","INTERSECT"] }, apply: { type: "boolean" } }, ["target"]),
  btool("blender_clear_scene", "Delete objects. keep = names to leave.", { keep: { type: "array", items: { type: "string" } } }, []),
  btool("blender_add_grid", "Add a grid.", { name: { type: "string" }, size: { type: "number" }, location: { type: "array" } }, []),
  btool("blender_add_text", "Add 3D text. text=string, extrude=thickness.", { name: { type: "string" }, text: { type: "string" }, extrude: { type: "number" }, location: { type: "array" }, body: { type: "string" } }, []),
  btool("blender_translate", "Move objects by offset [x,y,z] (relative).", { offset: { type: "array" }, name: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_rotate", "Set rotation in DEGREES [x,y,z]. add=true to add.", { rotation_deg: { type: "array" }, add: { type: "boolean" }, name: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_set_dimensions", "Set object size in meters [x,y,z].", { dimensions: { type: "array" }, name: { type: "string" }, size: { type: "array", items: { type: "number" } } }, []),
  btool("blender_origin_to_bottom", "Put origin at the lowest point (Roblox feet).", { name: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_drop_to_ground", "Move objects so the lowest vertex sits on Z=0.", { name: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_array", "Duplicate along offset, count times.", { count: { type: "integer" }, offset: { type: "array" }, objects: { type: "array" }, unique: { type: "boolean" }, name: { type: "string" } }, []),
  btool("blender_mirror", "Mirror-duplicate across X/Y/Z.", { axis: { type: "string", enum: ["X","Y","Z"] }, objects: { type: "array" } }, []),
  btool("blender_triangulate", "Convert faces to triangles (needed before Studio).", { objects: { type: "array" } }, []),
  btool("blender_apply_modifiers", "Apply every modifier so dump/export sees the result.", { objects: { type: "array" } }, []),
  btool("blender_remove_modifier", "Remove modifiers by type (BEVEL, SUBSURF, ...) or name from the named/selected objects; no type removes all.", { name: { type: "string" }, objects: { type: "array", items: { type: "string" } }, type: { type: "string" }, modifier: { type: "string" } }, []),
  btool("blender_merge", "Merge-by-distance (remove doubles).", { distance: { type: "number" }, objects: { type: "array" } }, []),
  btool("blender_recalc_normals", "Recalculate outside normals.", { objects: { type: "array" }, inside: { type: "boolean" }, name: { type: "string" } }, []),
  btool("blender_hide", "Hide objects.", { name: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_unhide", "Unhide objects (omit names = all).", { name: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_undo", "Undo last Blender action.", {}, []),
  btool("blender_stats", "Vertex/face/modifier counts.", { objects: { type: "array" } }, []),
  btool("blender_get_selection", "Names of selected objects.", {}, []),
  btool("blender_uv_unwrap", "Smart UV project.", { objects: { type: "array" } }, []),
  btool("blender_look_at", "Point an object/camera at a target or location.", { name: { type: "string" }, target: { type: "string" }, location: { type: "array" } }, []),
  btool("blender_align_camera", "Align the scene camera to an axis (front/back/left/right/top/bottom/iso) looking at a target or the selection.", { axis: { type: "string", enum: ["front","back","left","right","top","bottom","iso"] }, distance: { type: "number" }, target: { type: "string" }, name: { type: "string" }, view: { type: "string" } }, []),
  btool("blender_align_camera_axis", "Same as blender_align_camera.", { axis: { type: "string" }, distance: { type: "number" }, target: { type: "string" }, name: { type: "string" }, view: { type: "string" } }, []),
  btool("blender_view_axis", "Align the 3D viewport to FRONT/BACK/LEFT/RIGHT/TOP/BOTTOM (or iso via camera).", { axis: { type: "string" }, view: { type: "string" } }, []),
  btool("blender_camera_to_view", "Move the scene camera to match the current 3D viewport.", {}, []),
  btool("blender_set_camera_lens", "Set camera focal length, clip planes, or orthographic mode.", { name: { type: "string" }, lens: { type: "number" }, clip_start: { type: "number" }, clip_end: { type: "number" }, ortho: { type: "boolean" }, ortho_scale: { type: "number" } }, []),
  btool("blender_scale", "Scale selected/named objects. scale:[x,y,z] or a number. multiply=true multiplies current scale.", { name: { type: "string" }, scale: { type: "array" }, factor: { type: "array" }, multiply: { type: "boolean" } }, []),
  btool("blender_bevel", "Bevel mesh edges in edit mode.", { name: { type: "string" }, width: { type: "number" }, segments: { type: "number" }, offset: { type: "number" }, objects: { type: "array", items: { type: "string" } } }, []),
  btool("blender_solidify", "Add a Solidify modifier (thickness).", { name: { type: "string" }, thickness: { type: "number" } }, []),
  btool("blender_extrude", "Extrude the mesh along normals.", { name: { type: "string" }, distance: { type: "number" }, offset: { type: "number" } }, []),
  btool("blender_add_curve", "Add a Bezier curve.", { name: { type: "string" }, location: { type: "array" } }, []),
  btool("blender_add_armature", "Add an armature (single bone).", { name: { type: "string" }, location: { type: "array" } }, []),
  btool("blender_keyframe_insert", "Insert a keyframe on location/rotation/scale (or data_path) at frame.", { name: { type: "string" }, frame: { type: "number" }, data_path: { type: "string" } }, []),
  btool("blender_set_frame", "Set the current scene frame.", { frame: { type: "number" } }, []),
  btool("blender_set_active_camera", "Make a camera the scene camera.", { name: { type: "string" } }, []),
  btool("blender_track_to", "TRACK_TO constraint from selected objects toward target.", { target: { type: "string" }, name: { type: "string" } }, ["target"]),
  btool("blender_cursor_to_selected", "Move the 3D cursor to the selection midpoint.", { name: { type: "string" } }, []),
  btool("blender_randomize_transform", "Jitter location/rotation/scale of selected objects.", { name: { type: "string" }, location: { type: "number" }, rotation: { type: "number" }, scale: { type: "number" }, seed: { type: "number" } }, []),
  btool("blender_hide_render", "Hide (or unhide) objects from render.", { name: { type: "string" }, hide: { type: "boolean" } }, []),
  btool("blender_subdivision", "Add a Subdivision Surface modifier.", { name: { type: "string" }, levels: { type: "number" }, render_levels: { type: "number" } }, []),
  btool("blender_origin_to_geometry", "Set origin to geometry for selected objects.", { name: { type: "string" } }, []),
  btool("blender_capture_id", "Capture unique IDs (session_uid, data name, materials, collections) for selected Blender objects.", { name: { type: "string" }, objects: { type: "array" } }, []),
  btool("capture_id", "Capture unique IDs for selected Blender objects (alias of blender_capture_id).", { name: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_export_gltf", "Export selected/all objects to GLTF or GLB.", { filepath:{type:"string"}, objects:{type:"array"}, format:{type:"string",enum:["GLB","GLTF_SEPARATE"]} }, []),
  btool("blender_import_gltf", "Import a GLTF or GLB file.", { filepath:{type:"string"} }, ["filepath"]),
  btool("blender_scene_cleanup", "Remove orphan data, empty collections, and optionally unused materials.", { purge_orphans:{type:"boolean"}, empty_collections:{type:"boolean"}, unused_materials:{type:"boolean"} }, []),
  btool("blender_set_world", "Set world background color and strength.", { color:{type:"array"}, strength:{type:"number"} }, []),
  btool("blender_set_render", "Set render engine, resolution, samples, frame range and output path.", { engine:{type:"string"}, width:{type:"integer"}, height:{type:"integer"}, samples:{type:"integer"}, frame_start:{type:"integer"}, frame_end:{type:"integer"}, filepath:{type:"string"} }, []),
  btool("blender_render_image", "Render the active camera to an image file.", { filepath:{type:"string"}, frame:{type:"integer"} }, []),
  btool("blender_principled_material", "Create/update a node-based Principled material with color, metallic, roughness and emission.", { name:{type:"string"}, material:{type:"string"}, color:{type:"array"}, metallic:{type:"number"}, roughness:{type:"number"}, emission:{type:"array"}, emission_strength:{type:"number"} }, []),
  btool("blender_inset", "Inset selected/all faces on mesh objects.", { name:{type:"string"}, thickness:{type:"number"}, depth:{type:"number"} }, []),
  btool("blender_add_bone", "Add a named bone to an armature with head/tail coordinates and optional parent.", { armature:{type:"string"}, name:{type:"string"}, head:{type:"array"}, tail:{type:"array"}, parent:{type:"string"} }, ["armature","name"]),
  btool("blender_normalize_weights", "Normalize all vertex-group weights on selected mesh objects.", { objects:{type:"array"} }, []),
  btool("scene_list", "List real Blender scenes.", {}, []),
  btool("scene_create", "Create a Blender scene.", {name:{type:"string"}}, ["name"]),
  btool("scene_delete", "Delete a Blender scene except the only remaining scene.", {name:{type:"string"}}, ["name"]),
  btool("scene_duplicate", "Duplicate a Blender scene.", {name:{type:"string"},new_name:{type:"string"}}, []),
  btool("scene_set_active", "Set the active Blender scene.", {name:{type:"string"}}, ["name"]),
  btool("object_delete", "Delete selected or named objects.", {name:{type:"string"},objects:{type:"array"}}, []),
  btool("object_duplicate", "Duplicate selected or named objects.", {name:{type:"string"},objects:{type:"array"}, offset: { type: "array", items: { type: "number" } } }, []),
  btool("object_select", "Select named objects.", {name:{type:"string"},objects:{type:"array"}}, []),
  btool("object_deselect", "Deselect every object.", {}, []),
  btool("object_rename", "Rename an object.", {name:{type:"string"},new_name:{type:"string"}, object: { type: "string" }, to: { type: "string" } }, ["name","new_name"]),
  btool("object_parent", "Parent objects while preserving transforms.", {parent:{type:"string"},objects:{type:"array"}, keep_transform: { type: "boolean" } }, ["parent"]),
  btool("object_unparent", "Clear object parents while preserving transforms.", {objects:{type:"array"}}, []),
  btool("object_join", "Join mesh objects.", {objects:{type:"array"},name:{type:"string"}}, []),
  btool("object_separate", "Separate mesh loose parts.", {name:{type:"string"}}, []),
  btool("object_get_transform", "Read object location, rotation, scale and dimensions.", {name:{type:"string"}}, []),
  btool("object_set_transform", "Set object location, rotation and scale.", {name:{type:"string"},location:{type:"array"},rotation:{type:"array"},scale:{type:"array"}, rotation_deg: { type: "array", items: { type: "number" } }, dimensions: { type: "array", items: { type: "number" } } }, []),
  btool("object_apply_transform", "Apply object transforms.", {objects:{type:"array"},location:{type:"boolean"},rotation:{type:"boolean"},scale:{type:"boolean"}}, []),
  btool("mesh_bevel", "Bevel mesh edges.", {name:{type:"string"},width:{type:"number"},segments:{type:"integer"}, offset: { type: "number" }, objects: { type: "array", items: { type: "string" } } }, []),
  btool("mesh_extrude", "Extrude selected mesh faces.", {name:{type:"string"},distance:{type:"number"}, offset: { type: "number" } }, []),
  btool("mesh_inset", "Inset mesh faces.", {name:{type:"string"},thickness:{type:"number"},depth:{type:"number"}}, []),
  btool("mesh_subdivide", "Subdivide mesh geometry.", {name:{type:"string"},cuts:{type:"integer"}, levels: { type: "integer" } }, []),
  btool("mesh_merge", "Merge vertices by distance.", {objects:{type:"array"},distance:{type:"number"}}, []),
  btool("mesh_decimate", "Decimate selected meshes.", {objects:{type:"array"},ratio:{type:"number"}, apply: { type: "boolean" }, type: { type: "string", enum: ["COLLAPSE","UNSUBDIV","DISSOLVE"] } }, []),
  btool("mesh_cleanup", "Clean scene and mesh data.", {purge_orphans:{type:"boolean"},empty_collections:{type:"boolean"}, unused_materials: { type: "boolean" } }, []),
  btool("modifier_add", "Add a supported Blender modifier.", {name:{type:"string"},type: { type: "string", enum: ["SUBSURF","SUBDIVISION","BEVEL","SOLIDIFY","MIRROR","ARRAY","BOOLEAN","DECIMATE","TRIANGULATE","REMESH","WELD"] },target:{type:"string"}, width: { type: "number" }, segments: { type: "integer" }, thickness: { type: "number" }, count: { type: "integer" }, offset: { type: "array", items: { type: "number" } }, axis: { type: "string", enum: ["X","Y","Z"] }, ratio: { type: "number" }, operation: { type: "string", enum: ["DIFFERENCE","UNION","INTERSECT"] }, object: { type: "string" }, objects: { type: "array", items: { type: "string" } }, levels: { type: "integer" }, apply: { type: "boolean" } }, ["type"]),
  btool("modifier_remove", "Remove a named modifier.", {name:{type:"string"},modifier:{type:"string"}, type: { type: "string" }}, ["modifier"]),
  btool("modifier_configure", "Set validated properties on a modifier.", {name:{type:"string"},modifier:{type:"string"},properties:{type:"object"}}, ["modifier","properties"]),
  btool("modifier_apply", "Apply all modifiers on selected objects.", {objects:{type:"array"}}, []),
  btool("modifier_list", "List modifiers on an object.", {name:{type:"string"}}, []),
  btool("material_create", "Create a node-enabled material.", {material:{type:"string"}, name: { type: "string" } }, ["material"]),
  btool("material_assign", "Assign or create a Principled material.", {name:{type:"string"},material:{type:"string"},color:{type:"array"}, object: { type: "string" } }, []),
  btool("material_remove", "Remove and unlink a material.", {material:{type:"string"}, name: { type: "string" } }, ["material"]),
  btool("material_duplicate", "Duplicate a material.", {material:{type:"string"},new_name:{type:"string"}, name: { type: "string" } }, ["material"]),
  btool("node_create", "Create a shader node in a material.", {material:{type:"string"},type:{type:"string"},name:{type:"string"}}, ["material","type"]),
  btool("node_delete", "Delete a shader node.", {material:{type:"string"},name:{type:"string"}}, ["material","name"]),
  btool("node_inspect", "Inspect material nodes and links.", {material:{type:"string"}}, ["material"]),
  btool("uv_unwrap", "Smart unwrap selected mesh objects.", {objects:{type:"array"}}, []),
  btool("uv_pack", "Pack UV islands.", {objects:{type:"array"},margin:{type:"number"}}, []),
  btool("uv_inspect", "Inspect UV layers.", {objects:{type:"array"}}, []),
  btool("animation_list", "List actions and animated objects.", {}, []),
  btool("keyframe_insert", "Insert an object keyframe.", {name:{type:"string"},frame:{type:"integer"},data_path:{type:"string"}}, ["name","frame"]),
  btool("timeline_set", "Set current timeline frame.", {frame:{type:"integer"}}, ["frame"]),
  btool("camera_create", "Create a camera.", {name:{type:"string"},location:{type:"array"}}, []),
  btool("camera_set_active", "Set active scene camera.", {name:{type:"string"}}, ["name"]),
  btool("light_create", "Create a light.", {name:{type:"string"},type: { type: "string", enum: ["SUN","POINT","SPOT","AREA"] },location:{type:"array"},energy:{type:"number"}}, []),
  btool("world_set", "Set world color and strength.", {color:{type:"array"},strength:{type:"number"}}, []),
];
for (const t of BLENDER_TOOLS) BLENDER_TOOL_NAMES.add(t.name);

function bbStatusSnapshot() {
  const monoNow = typeof performance !== "undefined" && typeof performance.now === "function" ? performance.now() : Date.now();
  const age = Math.max(0, monoNow - bbCheckedAtMono);
  const fresh = bbStatusKnown && age <= BB_STATUS_MAX_AGE_MS;
  return {
    known: fresh,
    connected: fresh && bbConnected,
    error: fresh ? "" : (bbStatusKnown ? "Blockbench status is stale; check again to verify it" : (bbStatusError || "Blockbench status has not been verified")),
  };
}
function bbStatusChanged(before, after) {
  return before.known !== after.known || before.connected !== after.connected || before.error !== after.error;
}
function figmaStatusSnapshot() {
  if (figmaManualDisconnected) return { known: true, connected: false, state: "disconnected", error: "Figma MCP was disconnected in TotalScript", manual: true };
  const monoNow = typeof performance !== "undefined" && typeof performance.now === "function" ? performance.now() : Date.now();
  const age = Math.max(0, monoNow - figmaCheckedAtMono);
  const fresh = figmaStatusKnown && age <= FIGMA_STATUS_MAX_AGE_MS;
  return {
    known: fresh,
    connected: fresh && figmaConnected,
    state: fresh ? (figmaConnected ? "connected" : "disconnected") : "unknown",
    error: fresh ? "" : (figmaStatusKnown ? "Figma MCP status is stale; check again to verify it" : (figmaStatusError || "Figma Desktop MCP has not been verified")),
  };
}
function figmaStatusChanged(before, after) {
  return before.known !== after.known || before.connected !== after.connected || before.state !== after.state || before.error !== after.error;
}
function figmaTools() {
  return figmaStatusSnapshot().connected ? figmaToolsCache.slice() : [];
}
function figmaStatusPayload() {
  const state = figmaStatusSnapshot();
  return {
    ok: state.connected, figma: state.connected, connected: state.connected,
    verified: state.known, status: state.state, status_error: state.error || undefined,
    manual_disconnected: !!figmaManualDisconnected,
    checked_at: figmaCheckedAt || undefined, tools: state.connected ? figmaToolsCache.length : 0,
    endpoint: typeof TotalFigmaMcp !== "undefined" ? TotalFigmaMcp.ENDPOINT : undefined,
  };
}
async function figmaRefresh(force, timeoutMs) {
  await figmaManualReady;
  if (force && figmaManualDisconnected) {
    figmaManualDisconnected = false;
    try { chrome.storage.local.set({ [FIGMA_MANUAL_KEY]: false }); } catch {}
  }
  if (figmaManualDisconnected) return figmaStatusSnapshot();
  const current = figmaStatusSnapshot();
  if (!force && current.known) return current;
  if (figmaRefreshTask) return figmaRefreshTask;
  const before = figmaStatusSnapshot();
  const task = (async () => {
    try {
      if (!figmaClient) throw new Error("Figma MCP transport module did not load; reload the TotalScript extension");
      figmaToolsCache = await figmaClient.refresh(Number(timeoutMs) || 3000);
      figmaConnected = true;
      figmaStatusKnown = true;
      figmaStatusError = "";
    } catch (error) {
      figmaConnected = false;
      figmaStatusKnown = false;
      figmaToolsCache = [];
      figmaStatusError = String(error && error.message || error || "Figma Desktop MCP could not be verified").slice(0, 240);
      try { figmaClient && figmaClient.disconnect(); } catch {}
    }
    figmaCheckedAt = Date.now();
    figmaCheckedAtMono = typeof performance !== "undefined" && typeof performance.now === "function" ? performance.now() : figmaCheckedAt;
    const after = figmaStatusSnapshot();
    if (figmaStatusChanged(before, after)) {
      if (after.connected) pushActivity("figma", "ok", `Figma Desktop MCP connected (${figmaToolsCache.length} tools)`);
      else if (before.connected) pushActivity("figma", "warn", "Figma MCP status could not be verified; its connection is unknown");
    }
    // Keep the extension surfaces' 12s freshness checks alive even when the
    // Roblox/total-core socket is offline. Do not emit a status message every
    // periodic MCP tools/list refresh.
    if (figmaStatusChanged(before, after) || (after.connected && figmaCheckedAt - figmaStatusBroadcastAt >= 8000)) {
      figmaStatusBroadcastAt = figmaCheckedAt;
      broadcastStatus();
    }
    return after;
  })();
  figmaRefreshTask = task;
  task.then(() => { if (figmaRefreshTask === task) figmaRefreshTask = null; }, () => { if (figmaRefreshTask === task) figmaRefreshTask = null; });
  return task;
}
async function figmaDisconnect() {
  await figmaManualReady;
  figmaManualDisconnected = true;
  figmaConnected = false;
  figmaStatusKnown = true;
  figmaStatusError = "Figma MCP was disconnected in TotalScript";
  figmaToolsCache = [];
  figmaCheckedAt = Date.now();
  figmaCheckedAtMono = typeof performance !== "undefined" && typeof performance.now === "function" ? performance.now() : figmaCheckedAt;
  figmaStatusBroadcastAt = figmaCheckedAt;
  try { figmaClient && figmaClient.disconnect(); } catch {}
  try { chrome.storage.local.set({ [FIGMA_MANUAL_KEY]: true }); } catch {}
  pushActivity("figma", "info", "Figma MCP session disconnected in TotalScript; Figma Desktop was left running");
  broadcastStatus();
  return figmaStatusPayload();
}
function isFigmaPluginToolName(name) {
  return /^figma_plugin_[A-Za-z][A-Za-z0-9_.-]{0,54}$/.test(String(name || "").split("/").pop());
}
function isFigmaToolName(name) {
  return /^figma_[A-Za-z][A-Za-z0-9_.-]{0,54}$/.test(String(name || "").split("/").pop());
}
async function dispatchFigmaTool(exposedName, args, timeoutMs, requestId) {
  await figmaManualReady;
  const name = String(exposedName || "").split("/").pop();
  if (!isFigmaToolName(name)) return { ok: false, kind: "validation", errorCode: "FIGMA_TOOL_INVALID", error: "Invalid Figma MCP tool name" };
  if (figmaManualDisconnected) return { ok: false, kind: "disconnected", errorCode: "FIGMA_DISCONNECTED", error: "Figma MCP is disconnected in TotalScript. Press Connect Figma in Settings → MCP servers before retrying." };
  let state = figmaStatusSnapshot();
  if (!state.known || !state.connected) state = await figmaRefresh(false, 6500);
  if (!state.known) return { ok: false, kind: "status-unknown", errorCode: "FIGMA_STATUS_UNKNOWN", error: "Could not verify the Figma Desktop MCP connection. Open Figma Desktop, enable its local MCP server, then press Connect Figma. " + (state.error || "") };
  if (!state.connected) return { ok: false, kind: "disconnected", errorCode: "FIGMA_DISCONNECTED", error: "Figma MCP is not connected. Open Figma Desktop, enable its local MCP server, then press Connect Figma in Settings → MCP servers." };
  const listed = figmaToolsCache.find((tool) => tool && tool.name === name);
  if (!listed) return { ok: false, kind: "validation", errorCode: "FIGMA_TOOL_STALE", error: "Figma no longer advertises that tool. Refresh the Figma tool list before retrying." };
  if (!figmaClient) return { ok: false, kind: "transport", errorCode: "FIGMA_TRANSPORT_UNAVAILABLE", error: "Figma MCP transport module did not load; reload the TotalScript extension." };
  const rawName = name.slice("figma_".length);
  const started = performance.now();
  try {
    const result = await figmaClient.callTool(rawName, args || {}, timeoutMs, requestId);
    const ms = Math.round(performance.now() - started);
    if (result && result.requestId === undefined && requestId !== undefined) result.requestId = requestId;
    pushActivity("figma", result && result.ok ? "ok" : "error", `${rawName} ${result && result.ok ? "ok" : "failed"}`, { tool: name, ms, code: result && result.errorCode });
    return result;
  } catch (error) {
    const detail = String(error && error.message || error || "Figma MCP tool call failed").slice(0, 1000);
    const kind = error && error.kind || "transport";
    const code = error && error.code || "FIGMA_MCP_ERROR";
    if (kind === "cancelled") {
      const message = "Figma MCP request was cancelled locally; Figma may already have completed the operation.";
      pushActivity("figma", "info", `${rawName} cancelled`, { tool: name, ms: Math.round(performance.now() - started), code });
      return { ok: false, kind, errorCode: code, error: message, requestId };
    }
    if (kind !== "tool" && kind !== "validation") {
      figmaConnected = false;
      figmaStatusKnown = false;
      figmaToolsCache = [];
      figmaStatusError = detail.slice(0, 240);
      figmaCheckedAt = Date.now();
      figmaCheckedAtMono = typeof performance !== "undefined" && typeof performance.now === "function" ? performance.now() : figmaCheckedAt;
      try { figmaClient.disconnect(); } catch {}
      broadcastStatus();
    }
    // Keep server text / document names out of the persistent activity history.
    pushActivity("figma", "error", `${rawName} failed (${code})`, { tool: name, ms: Math.round(performance.now() - started), code });
    return { ok: false, kind, errorCode: code, error: detail, requestId };
  }
}
function blenderServers(list, snapshot) {
  // The cached WebSocket server list is diagnostic only for Blockbench. Its
  // dedicated total-core heartbeat is the liveness authority; Figma uses its MCP handshake.
  const input = Array.isArray(list) ? list : [];
  const oldBb = input.find((s) => s && s.id === "blockbench");
  const oldFigma = input.find((s) => s && s.id === "figma");
  const bb = snapshot || bbStatusSnapshot();
  const figma = figmaStatusSnapshot();
  const rest = input.filter((s) => s && s.id !== "blender" && s.id !== "blockbench" && s.id !== "figma" && s.id !== "figma_plugin");
  if (bb.known) rest.push(Object.assign({ id: "blockbench", name: "Blockbench" }, oldBb || {}, { alive: bb.connected, tools: bb.connected ? bbToolList().length : 0 }));
  if (blenderAddon) rest.push({ id: "blender", name: "Blender", alive: true, tools: BLENDER_TOOLS.length });
  rest.push({
    id: "figma_plugin", name: "Figma Design plugin",
    alive: figmaPluginVerified && figmaPluginConnected,
    status: figmaPluginVerified ? figmaPluginStatus : "unknown",
    tools: figmaPluginVerified && figmaPluginConnected ? figmaPluginTools : 0,
  });
  rest.push(Object.assign({ id: "figma", name: "Figma Desktop MCP" }, oldFigma || {}, { alive: figma.connected, tools: figma.connected ? figmaToolsCache.length : 0, status: figma.state }));
  return rest;
}
// App-specific MCP tools are merged only after their own connection is verified.
function mergeBlenderTools(tools) {
  const base = (Array.isArray(tools) ? tools : []).filter((t) => {
    if (!t) return false;
    const name = String(t.name || "").split("/").pop();
    const pairedPluginTool = t.server === "figma_plugin" || /^figma_plugin_/.test(name);
    if (pairedPluginTool && !figmaPluginConnected && name !== "figma_plugin_status") return false;
    return !(/^bb_/.test(name) || (/^figma_/.test(name) && !pairedPluginTool));
  });
  const have = new Set(base.map((t) => t && t.name));
  if (blenderAddon) for (const t of BLENDER_TOOLS) if (!have.has(t.name)) base.push(t);
  if (bbStatusSnapshot().connected) for (const t of bbToolList()) if (!have.has(t.name)) base.push(t);
  if (figmaStatusSnapshot().connected) for (const t of figmaToolsCache) if (!have.has(t.name)) base.push(t);
  return base;
}
function noteBlockbenchServers(list) {
  if (!Array.isArray(list)) return;
  const entry = list.find((s) => s && s.id === "blockbench");
  if (!entry || typeof entry.alive !== "boolean") return;
  const verified = bbStatusSnapshot();
  if (!verified.known) return;
  if (entry.alive === verified.connected) { bbServerMismatch = ""; return; }
  const signature = `${entry.alive ? "alive" : "down"}/${verified.connected ? "connected" : "disconnected"}`;
  if (!bbServerMismatch.startsWith(signature + ":")) {
    bbServerMismatch = `${signature}: cached WebSocket server list says Blockbench ${entry.alive ? "alive" : "down"}, while the fresh dedicated status says ${verified.connected ? "connected" : "disconnected"}.`;
    pushActivity("blockbench", "warn", "Blockbench status mismatch; the dedicated total-core heartbeat remains authoritative.");
    bbRefresh();
  }
}

function log(...a) {
  console.log("[total-bg]", ...a);
}

// ── WebSocket lifecycle ─────────────────────────────────────────────────
function connect() {
  if (manualStudioDisconnect) return;
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }
  clearTimeout(reconnectTimer); reconnectTimer = null; // (a fired timer kept its stale id, which read as "reconnecting" forever)
  const url = engineUrl();
  let sock;
  try {
    sock = new WebSocket(url);
  } catch (e) {
    log("WebSocket ctor failed", e);
    scheduleReconnect();
    return;
  }
  ws = sock;
  mcpConnectStarted=performance.now();setMcpLifecycle(reconnectAttempts ? "RECONNECTING" : "CONNECTING");

  sock.onopen = () => {
    if (sock !== ws) return;
    connected = true;
    reconnectDelay = RECONNECT_MIN;
    reconnectAttempts = 0;
    connectionId = `mcp-${Date.now().toString(36)}`;
    setMcpLifecycle("CONNECTED");mcpTrace("connect",{duration:Math.round(performance.now()-mcpConnectStarted),status:"CONNECTED"});
    pushActivity("conn", "ok", `Bridge connected (${engineLabel()})`, { ms: Math.round(performance.now() - mcpConnectStarted) });
    lastMessageAt = Date.now();
    log(`connected to ${engineLabel()} bridge (${url})`);
    startHeartbeat();
    refreshProcStatus();
    broadcastStatus();
  };

  sock.onmessage = (ev) => {
    if (sock !== ws) return;
    lastMessageAt = Date.now();
    let msg;
    try {
      msg = JSON.parse(ev.data);
    } catch {
      return;
    }
    handleBridgeMessage(msg);
  };

  sock.onclose = () => {
    if (sock !== ws) return;
    if (connected) pushActivity("conn", manualStudioDisconnect ? "info" : "warn", manualStudioDisconnect ? "Bridge disconnected on request" : "Bridge connection dropped — reconnecting", { code: manualStudioDisconnect ? undefined : "MCP_CONNECTION_CLOSED" });
    connected = false;
    mcpAlive = false;
    studioConnected = null;
    studioApp = null;
    studioProc = null;
    robloxEditorConnected = false;
    toolsCache = [];
    serversCache = [];
    stopHeartbeat();
    failAllPending("bridge connection closed");
    broadcastStatus();
    scheduleReconnect();
  };

  sock.onerror = () => {
    if (sock !== ws) return;
    // onclose will follow; nothing to do here but avoid an unhandled error.
    try { sock.close(); } catch {}
  };
}

const RECONNECT_SLOW_MS = 15000; // after the fast attempts, keep knocking gently
function scheduleReconnect() {
  if (manualStudioDisconnect) return;
  if (reconnectAttempts >= MCP_MAX_RECONNECT_ATTEMPTS) {
    // Fast attempts exhausted: report ERROR for the UI, but never stop trying.
    // total-core is usually started AFTER the browser, so a slow background
    // retry (plus the /api/status nudge) is what makes Start unlock on its own.
    if (mcpLifecycle !== "ERROR") setMcpLifecycle("ERROR", { errorCode: "MCP_SERVER_UNAVAILABLE" });
    clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(connect, RECONNECT_SLOW_MS);
    return;
  }
  clearTimeout(reconnectTimer);reconnectAttempts++;
  const delay=Math.min(RECONNECT_MAX,reconnectDelay)+Math.floor(Math.random()*Math.max(50,reconnectDelay*.2));
  setMcpLifecycle("RECONNECTING",{retryCount:reconnectAttempts});
  reconnectTimer=setTimeout(connect,delay);reconnectDelay=Math.min(reconnectDelay*2,RECONNECT_MAX);
}

function startHeartbeat() {
  stopHeartbeat();
  heartbeatTimer = setInterval(() => {
    if (connected) {
      // Half-open socket: the WS still reports OPEN but nothing comes through.
      // The pong (and every other frame) refreshes lastMessageAt; if it has
      // gone stale, drop the dead socket so onclose triggers a reconnect.
      const toolPending = [...pending.values()].some((p) => p.type === "call_tool");
      if (lastMessageAt && Date.now() - lastMessageAt > STALE_SOCKET_MS) {
        if (toolPending) return; // execute_luau owns the helper — pong resumes after it
        log("socket stale, forcing reconnect");
        try { ws.close(); } catch {}
        return;
      }
      // Keeps the MV3 service worker alive AND detects a half-open socket.
      // Use short timeout so pending ping doesn't leak for 130s
      send({ type: "ping" }, 12000).catch(() => {});
      refreshStudioStatus();
      // ── MCP auto-heal (v1.12) ────────────────────────────────────────────
      // The StudioMCP helper the agent spawns can die on its own (Studio
      // update, sleep/resume, crash). The agent only recycles it when a TOOL
      // call proves the helper dead - so between calls the bar kept showing
      // "connected" with a corpse helper and every command failed. If the
      // helper has been dead for two consecutive heartbeats, restart it
      // proactively (max once per 3 min so a legitimately closed Studio can't
      // cause a restart loop - the agent refuses when Studio's MCP option is
      // off, and that answer must win).
      if ((engine === "roblox" || engine === "anim") && !toolPending) {
        // Studio closed / MCP plugin off: do not restart-loop the helper.
        if (studioProc === false || studioApp === false) {
          mcpDownStreak = 0;
        } else if (!mcpAlive) {
          mcpDownStreak++;
          // Idle heal: one missed heartbeat, 30s cooldown. Never heal mid-tool.
          if (mcpDownStreak >= 2 && mcpHealAttempts < 3 && Date.now() - lastMcpHealAt > 30000 * Math.pow(2,mcpHealAttempts)) {
            lastMcpHealAt = Date.now();
            mcpDownStreak = 0;
            mcpHealAttempts++;
            log("MCP helper down across heartbeats - auto-restarting Studio MCP");
            send({ type: "restart_mcp" }, 30000).then((r) => {
              if (r && r.ok) {
                send({ type: "list_tools" }, 10000).catch(() => {});
                refreshStudioStatus();
              }
            }).catch(() => {});
          }
        } else {
          mcpDownStreak = 0;mcpHealAttempts=0;
        }
      }
    }
  }, HEARTBEAT_MS);
}
// Auto-heal state (see startHeartbeat).
let mcpDownStreak = 0;
let lastMcpHealAt = 0;
let mcpHealAttempts = 0;

function stopHeartbeat() {
  clearInterval(heartbeatTimer);
  heartbeatTimer = null;
}

// Resolve once the socket is OPEN, or false after `timeout` ms.
function waitForConnection(timeout = MCP_CONNECT_TIMEOUT_MS) {
  return new Promise((resolve) => {
    if (connected && ws && ws.readyState === WebSocket.OPEN) return resolve(true);
    connect(); // nudge a (re)connection - important after a worker wake-up
    const t0 = Date.now();
    const iv = setInterval(() => {
      if (connected && ws && ws.readyState === WebSocket.OPEN) {
        clearInterval(iv);
        resolve(true);
      } else if (Date.now() - t0 > timeout) {
        clearInterval(iv);
        resolve(false);
      }
    }, 100);
  });
}

// ── request/response over the socket ────────────────────────────────────
const IDEMPOTENT_STUDIO_TOOLS = new Set([
  "script_read","script_search","script_grep","inspect_instance","search_game_tree",
  "get_studio_state","get_console_output","get_children","get_descendants",
  "find_first_child","list_roblox_studios","selection_info","screen_capture"
]);
function bridgeRequestIsIdempotent(obj) {
  if (!obj || obj.type !== "call_tool") return true;
  const name=String(obj.name||"").split("/").pop();
  return IDEMPOTENT_STUDIO_TOOLS.has(name);
}
async function send(obj, timeout = REQUEST_TIMEOUT_DEFAULT) {
  // The MV3 service worker can be suspended; the first message after a wake-up
  // arrives before the socket has re-opened. Wait for it instead of failing -
  // otherwise Kimi wrongly hears "bridge offline".
  if (!connected || !ws || ws.readyState !== WebSocket.OPEN) {
    await waitForConnection(20000);
  }
  const attempt = () => new Promise((resolve) => {
    if (!connected || !ws || ws.readyState !== WebSocket.OPEN) {
      resolve({ ok:false,kind:"disconnected",errorCode:mcpLifecycle==="ERROR"?"MCP_SERVER_UNAVAILABLE":"MCP_CONNECTION_REFUSED",error:"bridge not connected",sent:false });
      return;
    }
    const id = nextId++;
    const requestId = obj.requestId || `or-${Date.now().toString(36)}-${id}-${crypto.randomUUID().slice(0,8)}`;
    const payload = {
      ...obj,
      version: "1.0",
      requestId,
      command: obj.type === "call_tool" ? obj.name : obj.type,
      args: obj.arguments || {},
      timestamp: Date.now(),
      id
    };
    const timer = setTimeout(() => {
      if (pending.has(id)) {
        pending.delete(id);
        resolve({ok:false,kind:"timeout",errorCode:obj.type==="list_tools"?"MCP_TOOL_DISCOVERY_FAILED":"MCP_REQUEST_TIMEOUT",error:"bridge did not respond in time",sent:true});
      }
    }, timeout);
    pending.set(id, { resolve, timer, type: obj.type, requestId, createdAt: Date.now() });
    try {
      ws.send(JSON.stringify(payload));
    } catch (e) {
      clearTimeout(timer);
      pending.delete(id);
      resolve({ ok: false, kind: "disconnected", error: String(e), sent: true });
    }
  });
  let r = await attempt();
  // Never replay a mutating Studio request after it may have reached the bridge.
  // A timeout is ambiguous: the first execution may still complete. Read-only
  // operations may be retried once after reconnect; requests proven unsent may
  // also be attempted once. This replaces the former unconditional 3 retries.
  const retryable = r && r.kind === "disconnected" &&
    (r.sent === false || bridgeRequestIsIdempotent(obj));
  if (retryable) {
    try { if (ws) ws.close(); } catch {}
    ws = null;
    connected = false;
    connect();
    await waitForConnection(12000);
    r = await attempt();
  }
  return r;
}

// Ask the bridge whether a Roblox Studio instance is actually connected to the
// MCP server. Broadcasts only on change so the UI updates promptly but quietly.
let studioProbing = false;
async function refreshStudioStatus() {
  if (studioProbing || !connected) return;
  if ([...pending.values()].some((p) => p.type === "call_tool")) return;
  studioProbing = true;
  try {
    const r = await send({ type: "studio_status" }, 12000);
    const v = r && r.ok && typeof r.studio === "boolean" ? r.studio : null;
    if (engine === "roblox" || engine === "anim") robloxEditorConnected = v === true;
    // local readiness comes from the agent's /api/status (local_ready), not editor probes
    if (v !== studioConnected) {
      studioConnected = v;
      broadcastStatus();
    } else {
      // The probe result can change independently of the tri-state cache when a
      // timeout returns null, so still publish the strict editor flag.
      broadcastStatus();
    }
  } finally {
    studioProbing = false;
  }
}

function handleBridgeMessage(msg) {
  if ("studio" in msg && (typeof msg.studio === "boolean" || msg.studio === null)) {
    studioConnected = msg.studio;
  }
  if ("studio_app" in msg && (typeof msg.studio_app === "boolean" || msg.studio_app === null)) {
    studioApp = msg.studio_app;
  }
  if ("studio_proc" in msg && (typeof msg.studio_proc === "boolean" || msg.studio_proc === null)) {
    studioProc = msg.studio_proc;
  }
  if (msg.type === "studio_status") {
    const online = studioConnected === true;
    if (engine === "roblox" || engine === "anim") robloxEditorConnected = online;
    resolvePending(msg.id, { ok: true, studio: online });
    broadcastStatus();
    return;
  }
  if (msg.type === "connected") {
    mcpAlive = !!msg.mcp_alive;
    if (Array.isArray(msg.tools)) { toolsCache = msg.tools; toolsCacheAt=Date.now(); }
    if (Array.isArray(msg.servers)) { serversCache = msg.servers; noteBlockbenchServers(msg.servers); }
    const online = msg.studio === true;
    if (engine === "roblox" || engine === "anim") robloxEditorConnected = online;
    broadcastStatus();
    return;
  }
  if (msg.type === "pong") {
    resolvePending(msg.id, { ok: true });
    return;
  }
  if (msg.type === "tools") {
    setMcpLifecycle("READY");
    if (Array.isArray(msg.tools)) { toolsCache = msg.tools; toolsCacheAt=Date.now(); }
    if (Array.isArray(msg.servers)) { serversCache = msg.servers; noteBlockbenchServers(msg.servers); }
    mcpAlive = !!msg.mcp_alive;
    const online = msg.studio === true;
    if (engine === "roblox" || engine === "anim") robloxEditorConnected = online;
    resolvePending(msg.id, { ok: !!msg.ok, tools: toolsCache, studio: online });
    broadcastStatus();
    return;
  }
  if (msg.type === "tool_result") {
    const result = msg.result && typeof msg.result === "object" ? msg.result : null;
    const rawError = msg.error ?? result?.error;
    const errorCode = msg.errorCode || msg.code || rawError?.code || result?.errorCode;
    const errorText = typeof rawError === "string" ? rawError : rawError?.message || (rawError == null ? "" : JSON.stringify(rawError));
    const text = msg.text ?? result?.text ?? (typeof result?.content === "string" ? result.content : undefined);
    resolvePending(msg.id ?? msg.requestId, msg.ok !== false
      ? { ok: true, text, images: msg.images || result?.images || [], version:msg.version, requestId:msg.requestId }
      : { ok: false, kind: msg.kind || "execution", error: errorText || "Bridge command failed", errorCode: errorCode || "BRIDGE_COMMAND_FAILED", version:msg.version, requestId:msg.requestId });
    return;
  }
  if (msg.type === "mcp_status") {
    mcpAlive = !!msg.alive;
    if (Array.isArray(msg.tools)) { toolsCache = msg.tools; toolsCacheAt=Date.now(); }
    if (Array.isArray(msg.servers)) {
      serversCache = msg.servers;
      const rbx = serversCache.find((x) => x.id === "roblox" || x.id === "studio");
      if (rbx) robloxEditorConnected = !!rbx.alive;
      const loc = serversCache.find((x) => x.id === "local");
      if (loc) localReady = !!loc.alive;
    }
    resolvePending(msg.id, { ok: !!msg.ok, alive: mcpAlive, error: msg.error });
    broadcastStatus();
    return;
  }
  if (msg.type === "server_changed") {
    // The bridge acks, then restarts itself to reload config.json. The socket
    // will drop right after this - the content script shows a spinner until the
    // reconnect lands and a fresh status arrives.
    resolvePending(msg.id, { ok: !!msg.ok, error: msg.error, restarting: !!msg.restarting });
    return;
  }
  if (msg.type === "error") {
    const err = msg.error;
    resolvePending(msg.id ?? msg.requestId, { ok: false, kind: "protocol", error: typeof err === "string" ? err : err?.message || JSON.stringify(err || "Bridge error"), errorCode: msg.errorCode || msg.code || err?.code || "BRIDGE_PROTOCOL_ERROR", requestId: msg.requestId });
    return;
  }}

function resolvePending(id, value) {
  let transportId = id;
  let p = pending.get(transportId);
  if (!p && id != null) {
    for (const [candidate, entry] of pending) { if (entry.requestId === String(id)) { transportId=candidate; p=entry; break; } }
  }
  if (!p) return; // duplicate, cancelled, timed-out, or stale response
  // The transport id is allocated per send and is the authoritative correlation
  // key. Older MCP bridges return their own nested requestId (or omit it), so
  // treating that optional diagnostic field as a second correlation key caused
  // valid Studio replies to fail with BRIDGE_PROTOCOL_ERROR. A stale reply can
  // still never resolve another operation: it must match an active transport id.
  if (value && value.requestId && value.requestId !== p.requestId) {
    mcpTrace("response_request_id_normalized", {requestId:p.requestId,status:"OK"});
    value={...value,requestId:p.requestId};
  }
  clearTimeout(p.timer);
  pending.delete(transportId);
  p.resolve(value);
}

function failAllPending(reason) {
  for (const [, p] of pending) {
    clearTimeout(p.timer);
    p.resolve({ ok: false, kind: "disconnected", error: reason });
  }
  pending.clear();
}

// ── status push to any open DeepSeek tab + popup ─────────────────────────
function statusObj() {
  // 2.2.1: tell the tabs WHY we are not connected. `reconnecting` = a dial is in
  // flight or scheduled (a blip, a worker wake-up); `lifecycle` ERROR = the fast
  // attempts are exhausted (a real outage); `manual` = mcp.disconnect / studio.disconnect
  // was called on purpose. The content script shows the red banner only for the
  // outage, never for the blip.
  const reconnecting = !connected && !manualStudioDisconnect && ((ws && ws.readyState === WebSocket.CONNECTING) || !!reconnectTimer);
  const bb = bbStatusSnapshot();
  const figma = figmaStatusSnapshot();
  return {
    type: "rs-status", connected, mcpAlive, studio: studioConnected, studioApp, studioProc,
    lifecycle: mcpLifecycle, reconnecting, manual: manualStudioDisconnect,
    robloxProc, roblox_connected: robloxEditorConnected,
    local_connected: localReady, local_full: localFull,
    local_root: localRoot,
    tools: mergeBlenderTools(toolsCache).length,
    servers: blenderServers(serversCache, bb), engine,
    blender: blenderAddon, blender_error: blenderError || undefined,
    blockbench: bb.connected, blockbench_verified: bb.known,
    blockbench_status: bb.known ? (bb.connected ? "connected" : "disconnected") : "unknown",
    blockbench_status_error: bb.error || undefined, blockbench_checked_at: bbCheckedAt || undefined,
    blockbench_core_api: bbCoreApiOk, blockbench_bridge_connected: connected,
    blockbench_server_list_mismatch: bb.known ? (bbServerMismatch || undefined) : undefined,
    blockbench_call_mismatch: bbCallMismatch || undefined,
    blockbench_plugin_file: bbPluginFile || undefined,
    figma: figma.connected, figma_verified: figma.known, figma_status: figma.state,
    figma_status_error: figma.error || undefined, figma_checked_at: figmaCheckedAt || undefined,
    figma_manual_disconnected: !!figmaManualDisconnected,
    figma_tools: figma.connected ? figmaToolsCache.length : 0,
    figma_plugin_connected: figmaPluginConnected,
    figma_plugin_verified: figmaPluginVerified,
    figma_plugin_status: figmaPluginStatus,
    figma_plugin_status_error: figmaPluginStatusError || undefined,
    figma_plugin_checked_at: figmaPluginCheckedAt || undefined,
    figma_plugin_tools: figmaPluginConnected ? figmaPluginTools : 0,
    figma_plugin_pairing_pending: figmaPluginPairingPending,
    figma_plugin_pairing_expires_at: figmaPluginPairingExpiresAt || undefined,
  };
}

async function refreshProcStatus() {
  try {
    const r = await fetch(`${RUST_ROBLOX_HTTP}/api/status`, { method: "GET" });
    if (!r.ok) return;
    // total-core answers on 3000 but our WebSocket is down: the agent was started
    // AFTER the worker gave up its bounded reconnect attempts. Re-arm the
    // backoff and dial again right away so Start unlocks within one poll.
    if (!connected && !manualStudioDisconnect && !(ws && ws.readyState === WebSocket.CONNECTING)) {
      reconnectAttempts = 0;
      reconnectDelay = RECONNECT_MIN;
      connect();
    }
    const j = await r.json();
    const nr = !!j.roblox_proc;
    const nl = j.local_ready === true;
    const nf = j.local_full === true;
    const nrRoot = typeof j.local_root === "string" ? j.local_root : localRoot;
    // Blockbench liveness is checked only through /api/blockbench/status;
    // /api/status fields are retained for plugin-path discovery, not as a
    // second liveness source.
    const previousPluginFile = bbPluginFile;
    if (typeof j.blockbench_plugin_file === "string") bbPluginFile = j.blockbench_plugin_file;
    const previousFigmaPlugin = [figmaPluginConnected, figmaPluginVerified, figmaPluginStatus, figmaPluginStatusError, figmaPluginTools, figmaPluginPairingPending, figmaPluginPairingExpiresAt].join("|");
    const reportedFigmaPluginStatus = ["connected", "disconnected", "unknown"].includes(j.figma_plugin_status) ? j.figma_plugin_status : "unknown";
    const reportedFigmaPluginConnected = j.figma_plugin_connected === true;
    const figmaPluginStatusConsistent = (reportedFigmaPluginStatus === "connected" && reportedFigmaPluginConnected)
      || (reportedFigmaPluginStatus === "disconnected" && !reportedFigmaPluginConnected);
    figmaPluginVerified = j.figma_plugin_verified === true && figmaPluginStatusConsistent;
    figmaPluginStatus = figmaPluginVerified ? reportedFigmaPluginStatus : "unknown";
    figmaPluginConnected = figmaPluginStatus === "connected";
    figmaPluginStatusError = figmaPluginVerified ? String(j.figma_plugin_status_error || "")
      : String(j.figma_plugin_status_error || "Figma Design plugin status is not verified").slice(0, 240);
    figmaPluginCheckedAt = Number(j.figma_plugin_checked_at) || Date.now();
    figmaPluginTools = figmaPluginConnected ? Math.max(0, Number(j.figma_plugin_tools) || 0) : 0;
    figmaPluginPairingPending = j.figma_plugin_pairing_pending === true;
    figmaPluginPairingExpiresAt = Number(j.figma_plugin_pairing_expires_at) || null;
    const currentFigmaPlugin = [figmaPluginConnected, figmaPluginVerified, figmaPluginStatus, figmaPluginStatusError, figmaPluginTools, figmaPluginPairingPending, figmaPluginPairingExpiresAt].join("|");
    const figmaPluginHeartbeat = figmaPluginStatus !== "unknown" && Date.now() - figmaPluginStatusBroadcastAt >= 8000;
    const changed = nr !== robloxProc || nl !== localReady || nf !== localFull || nrRoot !== localRoot || previousPluginFile !== bbPluginFile || previousFigmaPlugin !== currentFigmaPlugin || figmaPluginHeartbeat;
    robloxProc = nr;
    localReady = nl;
    localFull = nf;
    localRoot = nrRoot;
    // One-shot re-sync: if the agent restarted with FULL off but the user's
    // persisted toggle says ON, re-apply their choice once.
    if (!fullSyncedOnce) {
      fullSyncedOnce = true;
      try {
        chrome.storage.local.get("rs-local-full", (o) => {
          const want = o && o["rs-local-full"];
          if (typeof want === "boolean" && want !== nf) {
            fetch("http://127.0.0.1:3000/api/local-full", {
              method: "POST", headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ enabled: want }),
            }).then((r2) => r2.json()).then((j2) => { localFull = j2.local_full === true; broadcastStatus(); }).catch(() => {});
          }
        });
      } catch {}
    }
    if (changed) {
      if (figmaPluginStatus !== "unknown") figmaPluginStatusBroadcastAt = Date.now();
      broadcastStatus();
    }
  } catch {}
}

function broadcastStatus() {
  chrome.runtime.sendMessage(statusObj()).catch(() => {});
  providerTabs().then((tabs) => {
    for (const t of tabs) chrome.tabs.sendMessage(t.id, statusObj()).catch(() => {});
  });
}


async function ddgSearch(query, limit) {
  const q = String(query || "").trim();
  const n = Math.max(1, Math.min(8, Number(limit) || 5));
  if (!q) return [];
  const ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36";
  const pushUnique = (arr, item) => {
    if (!item || !item.url) return;
    let url = String(item.url);
    try {
      const um = url.match(/[?&]uddg=([^&]+)/);
      if (um) url = decodeURIComponent(um[1]);
    } catch {}
    if (!/^https?:\/\//i.test(url)) return;
    if (/duckduckgo\.com|javascript:/i.test(url)) return;
    if (arr.some((x) => x.url === url)) return;
    arr.push({ title: String(item.title || url).replace(/<[^>]+>/g, "").trim() || url, url: url, snippet: String(item.snippet || "").replace(/<[^>]+>/g, "").trim() });
  };
  const parseHtmlLinks = (html, max) => {
    const out = [];
    const reA = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
    let m;
    while ((m = reA.exec(html)) && out.length < max) pushUnique(out, { url: m[1], title: m[2] });
    const reLite = /<a[^>]+href="(https?:[^"]+)"[^>]*>([\s\S]{3,200}?)<\/a>/gi;
    while ((m = reLite.exec(html)) && out.length < max) pushUnique(out, { url: m[1], title: m[2] });
    const reBing = /<li class="b_algo"[\s\S]*?<a[^>]+href="(https?:[^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
    while ((m = reBing.exec(html)) && out.length < max) pushUnique(out, { url: m[1], title: m[2] });
    return out;
  };

  try {
    const res = await fetch("https://api.duckduckgo.com/?q=" + encodeURIComponent(q) + "&format=json&no_html=1&skip_disambig=1", {
      headers: { "Accept": "application/json", "User-Agent": ua },
    });
    if (res.ok) {
      const j = await res.json();
      const out = [];
      if (j.AbstractURL) pushUnique(out, { title: j.Heading || q, url: j.AbstractURL, snippet: j.AbstractText || "" });
      const topics = [];
      for (const t of (j.RelatedTopics || [])) {
        if (t.FirstURL) topics.push(t);
        if (t.Topics) for (const s of t.Topics) if (s.FirstURL) topics.push(s);
      }
      for (const t of topics) pushUnique(out, { title: t.Text, url: t.FirstURL, snippet: t.Text });
      for (const r of (j.Results || [])) pushUnique(out, { title: r.Text, url: r.FirstURL });
      if (out.length) return out.slice(0, n);
    }
  } catch {}

  for (const url of [
    "https://html.duckduckgo.com/html/?q=" + encodeURIComponent(q),
    "https://lite.duckduckgo.com/lite/?q=" + encodeURIComponent(q),
  ]) {
    try {
      const res = await fetch(url, { headers: { "User-Agent": ua, "Accept": "text/html" } });
      if (!res.ok) continue;
      const hits = parseHtmlLinks(await res.text(), n);
      if (hits.length) return hits;
    } catch {}
  }

  try {
    const res = await fetch("https://en.wikipedia.org/w/api.php?action=opensearch&limit=" + n + "&namespace=0&format=json&origin=*&search=" + encodeURIComponent(q), {
      headers: { "Accept": "application/json", "User-Agent": ua },
    });
    if (res.ok) {
      const j = await res.json();
      const out = [];
      const titles = j[1] || [], descs = j[2] || [], urls = j[3] || [];
      for (let i = 0; i < urls.length; i++) pushUnique(out, { title: titles[i], url: urls[i], snippet: descs[i] });
      if (out.length) return out;
    }
  } catch {}

  try {
    const res = await fetch("https://en.wikipedia.org/w/api.php?action=query&list=search&srlimit=" + n + "&utf8=1&format=json&origin=*&srsearch=" + encodeURIComponent(q), {
      headers: { "Accept": "application/json", "User-Agent": ua },
    });
    if (res.ok) {
      const j = await res.json();
      const rows = (j.query && j.query.search) || [];
      const out = [];
      for (const row of rows) {
        pushUnique(out, {
          title: row.title,
          url: "https://en.wikipedia.org/wiki/" + encodeURIComponent(String(row.title || "").replace(/ /g, "_")),
          snippet: String(row.snippet || "").replace(/<[^>]+>/g, ""),
        });
      }
      if (out.length) return out.slice(0, n);
    }
  } catch {}

  try {
    const res = await fetch("https://www.bing.com/search?q=" + encodeURIComponent(q), {
      headers: { "User-Agent": ua, "Accept": "text/html" },
    });
    if (res.ok) {
      const hits = parseHtmlLinks(await res.text(), n);
      if (hits.length) return hits;
    }
  } catch {}

  try {
    const res = await fetch("https://search.brave.com/search?q=" + encodeURIComponent(q), {
      headers: { "User-Agent": ua, "Accept": "text/html" },
    });
    if (res.ok) {
      const hits = parseHtmlLinks(await res.text(), n);
      if (hits.length) return hits;
    }
  } catch {}

  try {
    const res = await fetch("https://r.jina.ai/https://lite.duckduckgo.com/lite/?q=" + encodeURIComponent(q), {
      headers: { "Accept": "text/plain", "User-Agent": ua },
    });
    if (res.ok) {
      const md = await res.text();
      const out = [];
      const re = /\[([^\]]{3,120})\]\((https?:[^)\s]+)\)/g;
      let m;
      while ((m = re.exec(md)) && out.length < n) pushUnique(out, { title: m[1], url: m[2] });
      if (out.length) return out;
    }
  } catch {}
  return [];
}
function htmlToText(html) {
  let s = String(html || "");
  s = s.replace(/<script[\s\S]*?<\/script>/gi, " ");
  s = s.replace(/<style[\s\S]*?<\/style>/gi, " ");
  s = s.replace(/<noscript[\s\S]*?<\/noscript>/gi, " ");
  s = s.replace(/<!--[\s\S]*?-->/g, " ");
  s = s.replace(/<br\s*\/?>/gi, "\n");
  s = s.replace(/<\/(p|div|h[1-6]|li|tr|section|article|header|footer|blockquote|pre|ul|ol|table)>/gi, "\n");
  s = s.replace(/<[^>]+>/g, " ");
  s = s.replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&quot;/gi, '"').replace(/&#39;/g, "'");
  s = s.replace(/&#(\d+);/g, (_, n) => { try { return String.fromCharCode(Number(n)); } catch { return " "; } });
  s = s.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").replace(/[ \t]{2,}/g, " ").trim();
  return s;
}


// ── Blender (one-shot TCP 9876 via AgentScript) ─────────────────────────
// Native bin/total-core.exe rejects add_server/uvx. Chrome cannot open raw TCP.
// Connect is a short PowerShell/Python probe of the blender-mcp addon the
// user already started. Tool calls write a JSON request, run blender_once,
// then read the JSON response. No daemon, so the agent console is not
// flooded with failed `start /B py` / shim-restart loops.
function isBlenderToolName(name) {
  const bare = String(name || "").split("/").pop().split(".").pop();
  return BLENDER_TOOL_NAMES.has(bare) || /^blender_/.test(bare);
}
const BLENDER_KEY = "rs-blender-on";
try {
  chrome.storage?.local.get(BLENDER_KEY, (o) => {
    if (o && o[BLENDER_KEY]) blenderAddon = true;
  });
} catch {}
function setBlender(on, err) {
  const was = blenderAddon;
  blenderAddon = !!on;
  blenderError = on ? "" : (err || blenderError);
  try { chrome.storage.local.set({ [BLENDER_KEY]: !!on }); } catch {}
  if (was !== blenderAddon) broadcastStatus();
}

async function sendLocalEngine(obj, timeout = 25000) {
  if (engine === "local" && connected && ws && ws.readyState === WebSocket.OPEN) {
    return send(obj, timeout);
  }
  return await new Promise((resolve) => {
    let sock;
    try { sock = new WebSocket(`ws://127.0.0.1:${PORT_LOCAL}`); }
    catch (e) { resolve({ ok: false, error: "bin/total-core.exe is not running" }); return; }
    const id = 800000 + Math.floor(Math.random() * 99999);
    let settled = false;
    const done = (v) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try { sock.close(); } catch {}
      resolve(v);
    };
    const timer = setTimeout(() => done({ ok: false, error: "bin/total-core.exe did not answer — is it running?" }), timeout);
    sock.onerror = () => done({ ok: false, error: "bin/total-core.exe is not running" });
    sock.onopen = () => {
      try { sock.send(JSON.stringify({ ...obj, id })); }
      catch (e) { done({ ok: false, error: String(e) }); }
    };
    sock.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.type === "connected") {
        if (typeof msg.workspace_root === "string" && msg.workspace_root) localRoot = msg.workspace_root;
        return;
      }
      const matches = msg.id == null || msg.id === id || msg.requestId === obj.requestId;
      if (msg.type === "tool_result" && matches) {
        const result = msg.result && typeof msg.result === "object" ? msg.result : null;
        const raw = msg.error ?? result?.error;
        const text = typeof raw === "string" ? raw : raw?.message || (raw == null ? "" : JSON.stringify(raw));
        done(msg.ok !== false ? { ok: true, text: msg.text ?? result?.text, images: msg.images || result?.images || [], requestId:msg.requestId } : { ok: false, kind:msg.kind||"execution", error: text || "Local command failed", errorCode:msg.errorCode || msg.code || raw?.code || "LOCAL_COMMAND_FAILED", requestId:msg.requestId });
        return;
      }
      if (msg.type === "error" && matches) {
        const raw=msg.error; done({ ok:false, kind:"protocol", error:typeof raw === "string" ? raw : raw?.message || JSON.stringify(raw || "Bridge error"), errorCode:msg.errorCode || msg.code || raw?.code || "BRIDGE_PROTOCOL_ERROR", requestId:msg.requestId });
      }
    };
  });
}

async function extText(name) {
  const r = await fetch(chrome.runtime.getURL(name));
  if (!r.ok) throw new Error("extension file missing: " + name);
  return await r.text();
}

async function localWrite(path, content) {
  const r = await sendLocalEngine({
    type: "call_tool", name: "write_file",
    arguments: { path, content },
  }, 20000);
  if (!r || !r.ok) throw new Error((r && r.error) || ("could not write " + path));
  return r.text || "";
}

async function localRead(path, offset, limit=4000) {
  const r = await sendLocalEngine({
    type: "call_tool", name: "read_file",
    arguments: { path, offset: offset || 1, limit },
  }, 20000);
  if (!r || !r.ok) throw new Error((r && r.error) || ("could not read " + path));
  const lines = String(r.text || "").split("\n");
  const body = [];
  let more = false;
  let next = offset || 1;
  for (const ln of lines) {
    const cont = ln.match(/\.\.\. lines (\d+)/);
    if (cont) { more = true; next = Number(cont[1]); continue; }
    const m = ln.match(/^\s*\d+\s+\|\s(.*)$/);
    if (m) body.push(m[1]);
  }
  return { text: body.join("\n"), more, next, count: body.length };
}
async function localReadAll(path) {
  let offset = 1, chunks = [];
  for (let i = 0; i < 20; i++) {
    const part = await localRead(path, offset);
    if (part.text) chunks.push(part.text);
    if (!part.more || !part.count) break;
    offset = part.next || (offset + part.count);
  }
  return chunks.join("\n");
}

// Read a file that was written as short (<= 3000-char) lines by
// blender_once.* / blender_ops.py and join the lines back together. total-core's
// read_file clips ONE read at 40k characters, so a 1 MB mesh dump can only
// cross the native transport eight short lines at a time (same trick as the
// screenshot base64 below). Returns "" when the file is missing.
async function localReadWrapped(path) {
  let offset = 1, chunks = [];
  for (let i = 0; i < 4000; i++) {
    let part;
    try { part = await localRead(path, offset, 8); } catch (e) { if (!chunks.length) throw e; break; }
    if (part.text) chunks.push(part.text.split("\n").join(""));
    if (!part.more || !part.count) break;
    offset = part.next || (offset + part.count);
  }
  return chunks.join("").replace(/^\uFEFF/, "").trim();
}

async function localImageBase64(imagePath) {
  // The upstream Blender addon requires a filepath and returns metadata, not
  // transferable image bytes. Encode the workspace-owned capture in bounded
  // text lines so the native read_file transport never truncates one huge line.
  const script=[
    "import base64,sys,textwrap",
    "data=base64.b64encode(open(sys.argv[1],'rb').read()).decode('ascii')",
    "open(sys.argv[2],'w',encoding='ascii').write('\\n'.join(textwrap.wrap(data,3000)))",
  ].join("\n");
  await localWrite("total_encode_image.py",script);
  const input=String(imagePath||"total_blender_shot.png");
  const output="total_blender_shot.b64";
  let encoded=false,last="";
  for(const command of [`py -3 total_encode_image.py "${input.replace(/"/g,'')}" ${output}`,`python total_encode_image.py "${input.replace(/"/g,'')}" ${output}`,`python3 total_encode_image.py "${input.replace(/"/g,'')}" ${output}`]){
    const r=await localRun(command,20);last=String(r&&r.text||r&&r.error||"");
    if(r&&r.ok&&!/exit code [1-9]/i.test(last)){encoded=true;break;}
  }
  if(!encoded)throw new Error(last||"No Python runner could encode the Blender screenshot");
  let offset=1,chunks=[];
  for(let i=0;i<1000;i++){
    const part=await localRead(output,offset,8);
    if(part.text)chunks.push(part.text.replace(/\s+/g,""));
    if(!part.more||!part.count)break;
    offset=part.next||offset+part.count;
  }
  const data=chunks.join("");
  if(data.length<100||!/^[A-Za-z0-9+/]+={0,2}$/.test(data))throw new Error("Encoded Blender screenshot was empty or malformed");
  return data;
}

async function localRun(command, timeoutSeconds = 12) {
  return sendLocalEngine({
    type: "call_tool", name: "run_command",
    arguments: { command, timeout_seconds: timeoutSeconds },
  }, (timeoutSeconds + 8) * 1000);
}

function probeCommands(win) {
  if (win) {
    return [
      "powershell -NoProfile -Command try{$c=New-Object Net.Sockets.TcpClient;$c.ReceiveTimeout=2500;$c.Connect('127.0.0.1',9876);$c.Close();Write-Output BLENDER_UP}catch{Write-Output BLENDER_DOWN}",
    ];
  }
  return [
    "python3 -c \"import socket;s=socket.create_connection(('127.0.0.1',9876),2);s.close();print('BLENDER_UP')\"",
    "python -c \"import socket;s=socket.create_connection(('127.0.0.1',9876),2);s.close();print('BLENDER_UP')\"",
    "(echo >/dev/tcp/127.0.0.1/9876) >/dev/null 2>&1 && echo BLENDER_UP || echo BLENDER_DOWN",
  ];
}

async function probeBlenderTcp() {
  let plat = { os: "win" };
  try { plat = await chrome.runtime.getPlatformInfo(); } catch {}
  const win = plat.os === "win";
  let last = "";
  for (const cmd of probeCommands(win)) {
    const r = await localRun(cmd, 8);
    const text = String((r && (r.text || r.error)) || "");
    last = text;
    if (/BLENDER_UP/.test(text)) return { ok: true };
    if (r && r.ok === false && /not running|not connected|timeout/i.test(text)) {
      return { ok: false, error: "bin/total-core.exe is not running — start it, then Connect Blender again." };
    }
  }
  const down = /BLENDER_DOWN/.test(last);
  const err = down
    ? "Blender addon is not on port 9876. In Blender: press N → MCP for Blender → Start MCP Server."
    : (last && last.slice(0, 220)) || "Could not reach Blender. Run bin/total-core.exe, then Start MCP Server in Blender.";
  return { ok: false, error: err };
}

async function connectBlender() {
  const p = await probeBlenderTcp();
  if (!p || !p.ok) {
    const error = String((p && p.error) || "Blender did not answer on port 9876.");
    setBlender(false, error);
    broadcastStatus();
    return { ok: false, blender: false, error };
  }
  // A listening TCP port alone is not a working Blender link. Keep the worker
  // flag, tool catalogue and ChatGPT prompt offline until the addon successfully
  // answers the same read-only command the work mode uses as its first probe.
  let ping = null;
  try { ping = await blenderCall("get_scene_info", {}, 20000, true); }
  catch (e) { ping = { ok: false, error: String(e && e.message || e) }; }
  if (!ping || ping.ok !== true) {
    const reason = String((ping && ping.error) || "no successful get_scene_info response").slice(0, 240);
    const error = `Blender is reachable on port 9876, but get_scene_info failed: ${reason}`;
    setBlender(false, error);
    broadcastStatus();
    return { ok: false, blender: false, error };
  }
  setBlender(true, "");
  broadcastStatus();
  return { ok: true, blender: true };
}

// ── Blockbench (2.21.0: TotalScript Bridge plugin via total-core) ──────────
// plugin/TotalScript-Blockbench.js runs inside Blockbench and long-polls
// total-core. Its dedicated /api/blockbench/status heartbeat is the sole
// authority; /api/status and the cached WebSocket server list are diagnostics.
function bbToolList() {
  try { return typeof TotalBlockbench !== "undefined" ? TotalBlockbench.toolList() : []; } catch { return []; }
}
function bbSetConnected(on) {
  const previous = bbStatusSnapshot();
  bbConnected = !!on;
  bbStatusKnown = true;
  bbStatusError = "";
  bbCheckedAt = Date.now();
  bbCheckedAtMono = typeof performance !== "undefined" && typeof performance.now === "function" ? performance.now() : bbCheckedAt;
  if (bbConnected && !previous.connected) pushActivity("blockbench", "ok", "Blockbench plugin connected (verified by total-core)");
  else if (!bbConnected && previous.known && previous.connected) pushActivity("blockbench", "info", "Blockbench plugin disconnected (verified by total-core)");
}
function bbSetUnknown(reason) {
  const wasConnected = bbStatusSnapshot().connected;
  bbConnected = false;
  bbStatusKnown = false;
  bbStatusError = String(reason || "total-core did not return a usable Blockbench status").slice(0, 240);
  bbCheckedAt = Date.now();
  bbCheckedAtMono = typeof performance !== "undefined" && typeof performance.now === "function" ? performance.now() : bbCheckedAt;
  if (wasConnected) pushActivity("blockbench", "warn", "Blockbench status could not be verified; the connection state is unknown");
}
// Re-read the dedicated heartbeat. Failed or malformed reads become UNKNOWN;
// never preserve a stale green flag and never infer liveness from the server list.
function bbRefresh() {
  if (bbRefreshTask) return bbRefreshTask;
  const before = bbStatusSnapshot();
  const wasCoreApiOk = bbCoreApiOk;
  const beforeServerMismatch = bbServerMismatch;
  const beforeCallMismatch = bbCallMismatch;
  const controller = typeof AbortController === "function" ? new AbortController() : null;
  const timeout = setTimeout(() => { try { controller && controller.abort(); } catch {} }, 4000);
  const task = (async () => {
    try {
      const r = await fetch(`${RUST_ROBLOX_HTTP}/api/blockbench/status`, { method: "GET", cache: "no-store", ...(controller ? { signal: controller.signal } : {}) });
      if (!r.ok) {
        bbCoreApiOk = false;
        bbSetUnknown("Blockbench status endpoint answered HTTP " + r.status);
        return false;
      }
      bbCoreApiOk = true;
      const j = await r.json();
      const validState = j && (j.status === "connected" || j.status === "disconnected") && j.verified === true && typeof j.connected === "boolean" && ((j.status === "connected") === j.connected);
      if (!validState) {
        bbSetUnknown((j && typeof j.status_error === "string" && j.status_error) || "Blockbench status response was stale, unverified, or contradictory");
        return false;
      }
      bbSetConnected(j.status === "connected");
      if (typeof j.plugin_file === "string") bbPluginFile = j.plugin_file;
      if (Array.isArray(serversCache)) noteBlockbenchServers(serversCache);
      return bbStatusSnapshot().connected;
    } catch (e) {
      bbCoreApiOk = false;
      bbSetUnknown((e && e.message) || String(e));
      return false;
    } finally {
      clearTimeout(timeout);
      const after = bbStatusSnapshot();
      if (bbStatusChanged(before, after) || wasCoreApiOk !== bbCoreApiOk || beforeServerMismatch !== bbServerMismatch || beforeCallMismatch !== bbCallMismatch) broadcastStatus();
    }
  })();
  bbRefreshTask = task;
  task.then(() => { if (bbRefreshTask === task) bbRefreshTask = null; }, () => { if (bbRefreshTask === task) bbRefreshTask = null; });
  return task;
}
function bbStatusPayload() {
  const status = bbStatusSnapshot();
  const steps = typeof TotalBlockbench !== "undefined" ? TotalBlockbench.connectSteps(bbPluginFile) : [];
  return {
    ok: status.connected, blockbench: status.connected, verified: status.known,
    status: status.known ? (status.connected ? "connected" : "disconnected") : "unknown",
    status_error: status.error || undefined, checked_at: bbStatusKnown ? bbCheckedAt : undefined,
    plugin_file: bbPluginFile || undefined, core: bbCoreApiOk, core_api: bbCoreApiOk,
    bridge_connected: connected, tools: status.connected ? bbToolList().length : 0, steps,
    server_list_mismatch: status.connected || status.known ? (bbServerMismatch || undefined) : undefined,
    call_mismatch: bbCallMismatch || undefined,
  };
}

function trustedFigmaSettingsPopup(sender) {
  if (!sender || sender.id !== chrome.runtime.id || sender.tab) return false;
  const expected = chrome.runtime.getURL("popup.html");
  return String(sender.url || "").split(/[?#]/, 1)[0] === expected;
}
function setFigmaPluginStatus(payload) {
  const before = [figmaPluginConnected, figmaPluginVerified, figmaPluginStatus, figmaPluginStatusError, figmaPluginTools, figmaPluginPairingPending, figmaPluginPairingExpiresAt].join("|");
  const status = payload && ["connected", "disconnected", "unknown"].includes(payload.status) ? payload.status : "unknown";
  const connected = !!(payload && payload.connected === true);
  const consistent = (status === "connected" && connected) || (status === "disconnected" && !connected);
  figmaPluginVerified = !!(payload && payload.verified === true && consistent);
  figmaPluginStatus = figmaPluginVerified ? status : "unknown";
  figmaPluginConnected = figmaPluginStatus === "connected";
  figmaPluginStatusError = figmaPluginVerified ? String(payload.status_error || "")
    : String((payload && payload.status_error) || "Figma Design plugin status could not be verified").slice(0, 240);
  figmaPluginCheckedAt = Number(payload && payload.checked_at) || Date.now();
  figmaPluginTools = figmaPluginConnected ? Math.max(0, Number(payload && payload.tools) || 0) : 0;
  figmaPluginPairingPending = !!(payload && payload.pairing_pending);
  figmaPluginPairingExpiresAt = Number(payload && payload.pairing_expires_at) || null;
  const after = [figmaPluginConnected, figmaPluginVerified, figmaPluginStatus, figmaPluginStatusError, figmaPluginTools, figmaPluginPairingPending, figmaPluginPairingExpiresAt].join("|");
  if (before !== after) { figmaPluginStatusBroadcastAt = Date.now(); broadcastStatus(); }
  return {
    ok: figmaPluginConnected,
    connected: figmaPluginConnected,
    verified: figmaPluginVerified,
    status: figmaPluginStatus,
    status_error: figmaPluginStatusError || undefined,
    checked_at: figmaPluginCheckedAt,
    tools: figmaPluginTools,
    pairing_pending: figmaPluginPairingPending,
    pairing_expires_at: figmaPluginPairingExpiresAt || undefined,
    queue: Number(payload && payload.queue) || 0,
  };
}
async function figmaPluginHttp(route, init, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs || 5000);
  try {
    const response = await fetch(`${RUST_ROBLOX_HTTP}/api/figma-plugin/${route}`, Object.assign({ cache: "no-store", signal: controller.signal }, init || {}));
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) return { ok: false, status: response.status, error: String(payload.error || `total-core answered HTTP ${response.status}`) };
    return payload && typeof payload === "object" ? payload : { ok: false, error: "Invalid Figma plugin status response" };
  } catch (error) {
    return { ok: false, error: String(error && error.message || error || "Could not reach total-core on port 3000") };
  } finally { clearTimeout(timer); }
}
async function refreshFigmaPluginStatus() {
  const result = await figmaPluginHttp("status", { method: "GET" }, 4500);
  if (result && result.status === 404) {
    result.status = "unknown";
    result.connected = false;
    result.verified = false;
    result.status_error = "This TotalScript desktop build does not expose the Figma Design plugin bridge yet";
  }
  return setFigmaPluginStatus(result);
}

async function agentWorkspaceRoot() {
  if (localRoot) return localRoot;
  const r = await sendLocalEngine({ type: "call_tool", name: "workspace_info", arguments: {} }, 12000);
  const t = String((r && r.text) || "");
  const m = t.match(/Workspace root:\s*(.+)/);
  if (m) { localRoot = m[1].trim(); return localRoot; }
  return "";
}

const BLENDER_CMD = {
  // 1.83.0 spec-driven asset pipeline (tools/blender_asset.py)
  blender_asset_build: "asset_build", blender_asset_validate: "asset_validate", blender_asset_inspect: "asset_inspect", blender_asset_export: "asset_export", blender_asset_bake: "asset_bake",
  // 1.95.0 studio rig (tools/blender_studio.py)
  blender_light_rig: "light_rig", blender_camera_rig: "camera_rig", blender_world_setup: "world_setup", blender_render_setup: "render_setup", blender_render_shot: "render_shot", blender_turntable: "turntable", blender_studio_clear: "studio_clear",
  blender_export_fbx: "export_fbx", export_blender_fbx: "export_fbx",
  blender_import_fbx: "import_fbx", import_blender_fbx: "import_fbx",
  blender_export_obj: "export_obj", blender_import_obj: "import_obj",
  blender_mesh_dump: "dump", blender_send_to_studio: "dump",
  blender_group: "group", blender_ungroup: "ungroup",
  blender_parent: "parent", blender_unparent: "unparent", blender_join: "join",
  blender_move_to_collection: "move_to_collection",
  blender_list_collections: "list_collections", blender_list_objects: "list_objects",
  blender_delete: "delete", blender_duplicate: "duplicate", blender_rename: "rename",
  blender_select: "select", blender_transform: "transform",
  blender_apply_transforms: "apply_transforms", blender_set_origin: "set_origin",
  blender_shade_smooth: "shade_smooth", blender_set_material: "set_material",
  blender_add_modifier: "add_modifier", blender_boolean: "boolean",
  blender_add_cube: "add_cube", blender_add_sphere: "add_sphere",
  blender_add_cylinder: "add_cylinder", blender_add_cone: "add_cone",
  blender_add_plane: "add_plane", blender_add_torus: "add_torus",
  blender_add_monkey: "add_monkey", blender_add_empty: "add_empty",
  blender_add_camera: "add_camera", blender_add_light: "add_light",
  blender_add_ico_sphere: "add_ico_sphere", blender_add_grid: "add_grid",
  blender_add_circle: "add_circle", blender_add_text: "add_text",
  blender_clear_scene: "clear_scene",
  blender_select_all: "select_all", blender_deselect: "deselect",
  blender_invert_selection: "invert_selection", blender_select_children: "select_children",
  blender_get_selection: "get_selection",
  blender_translate: "translate", blender_rotate: "rotate_deg", blender_rotate_deg: "rotate_deg",
  blender_set_dimensions: "set_dimensions",
  blender_origin_to_bottom: "origin_to_bottom", blender_drop_to_ground: "drop_to_ground",
  blender_center: "center", blender_snap_to_grid: "snap_to_grid",
  blender_shade_flat: "shade_flat",
  blender_apply_modifiers: "apply_modifiers", blender_remove_modifier: "remove_modifier", blender_introspect: "introspect",
  blender_triangulate: "triangulate", blender_decimate: "decimate",
  blender_merge: "merge", blender_recalc_normals: "recalc_normals",
  blender_flip_normals: "flip_normals", blender_separate: "separate_loose",
  blender_subdivide: "subdivide", blender_uv_unwrap: "uv_unwrap",
  blender_array: "array", blender_mirror: "mirror",
  blender_hide: "hide", blender_unhide: "unhide", blender_unhide_all: "unhide_all",
  blender_hide_unselected: "hide_unselected",
  blender_undo: "undo", blender_redo: "redo",
  blender_frame_selected: "frame_selected", blender_stats: "stats",
  blender_save: "save_blend", blender_look_at: "look_at",
  blender_convert_to_mesh: "convert_to_mesh",
  blender_align_camera: "align_camera_axis", blender_align_camera_axis: "align_camera_axis",
  blender_view_axis: "view_axis", blender_camera_to_view: "camera_to_view",
  blender_set_camera_lens: "set_camera_lens",
  blender_scale: "scale", blender_bevel: "bevel", blender_solidify: "solidify",
  blender_extrude: "extrude", blender_add_curve: "add_curve", blender_add_armature: "add_armature",
  blender_keyframe: "keyframe_insert", blender_keyframe_insert: "keyframe_insert",
  blender_set_frame: "set_frame", blender_set_active_camera: "set_active_camera",
  blender_track_to: "track_to", blender_cursor_to_selected: "cursor_to_selected",
  blender_randomize: "randomize_transform", blender_randomize_transform: "randomize_transform",
  blender_hide_render: "hide_render", blender_subdivision: "subdivision",
  blender_subsurf: "subdivision", blender_origin_to_geometry: "origin_to_geometry",
  blender_capture_id: "capture_id", capture_id: "capture_id",
  blender_export_gltf: "export_gltf", blender_import_gltf: "import_gltf",
  blender_scene_cleanup: "scene_cleanup", blender_set_world: "set_world",
  blender_set_render: "set_render", blender_render_image: "render_image",
  blender_principled_material: "principled_material", blender_inset: "inset",
  blender_add_bone: "add_bone", blender_normalize_weights: "normalize_weights",
  scene_list:"scene_list",scene_create:"scene_create",scene_delete:"scene_delete",scene_duplicate:"scene_duplicate",scene_set_active:"scene_set_active",
  object_delete:"delete",object_duplicate:"duplicate",object_select:"select",object_deselect:"deselect",object_rename:"rename",object_parent:"parent",object_unparent:"unparent",object_join:"join",object_separate:"separate_loose",object_get_transform:"get_transform",object_set_transform:"transform",object_apply_transform:"apply_transforms",
  mesh_bevel:"bevel",mesh_extrude:"extrude",mesh_inset:"inset",mesh_subdivide:"subdivide",mesh_merge:"merge",mesh_decimate:"decimate",mesh_cleanup:"scene_cleanup",
  modifier_add:"add_modifier",modifier_remove:"remove_modifier",modifier_configure:"modifier_configure",modifier_apply:"apply_modifiers",modifier_list:"modifier_list",
  material_create:"material_create",material_assign:"set_material",material_remove:"material_remove",material_duplicate:"material_duplicate",
  node_create:"node_create",node_delete:"node_delete",node_inspect:"node_inspect",uv_unwrap:"uv_unwrap",uv_pack:"uv_pack",uv_inspect:"uv_inspect",
  animation_list:"animation_list",keyframe_insert:"keyframe_insert",timeline_set:"set_frame",camera_create:"add_camera",camera_set_active:"set_active_camera",light_create:"add_light",world_set:"set_world",
};

const BLENDER_ASSET_CMDS = new Set(["asset_build", "asset_validate", "asset_inspect", "asset_export", "asset_bake"]);
const BLENDER_STUDIO_CMDS = new Set(["light_rig", "camera_rig", "world_setup", "render_setup", "render_shot", "turntable", "studio_clear"]);
function blenderScriptFor(cmd) {
  const c = String(cmd || "");
  if (BLENDER_ASSET_CMDS.has(c)) return "tools/blender_asset.py";
  if (BLENDER_STUDIO_CMDS.has(c)) return "tools/blender_studio.py";
  return "tools/blender_ops.py";
}
async function blenderOpsCode(cmd, args) {
  let py = await extText(blenderScriptFor(cmd));
  const status = "total_status.json";
  const mesh = "total_mesh.json";
  // Blender's working directory is its install folder (often read-only) and
  // never the total-core workspace that TotalScript reads from, so hand it absolute paths
  // inside the workspace. TotalScript keeps reading the relative names (same files).
  let root = "";
  try { root = await agentWorkspaceRoot(); } catch {}
  root = String(root || "").replace(/[\\/]+$/, "");
  const sep = /\\/.test(root) ? "\\" : "/";
  const abs = (name) => (root ? root + sep + name : name);
  py = py.split("__TOTAL_CMD__").join(String(cmd || ""));
  py = py.split("__TOTAL_ARGS__").join(JSON.stringify(args || {}));
  py = py.split("__TOTAL_OUT__").join(JSON.stringify(abs(status)));
  py = py.split("__TOTAL_MESH__").join(JSON.stringify(abs(mesh)));
  return { py, status, mesh };
}

function wrapBlenderUserCode(code) {
  const src = String(code || "");
  if (!src.trim()) return src;
  if (src.indexOf("_total_items") >= 0 && src.indexOf("_total_src =") >= 0) return src;
  return [
    "import bpy, re as _total_re",
    "_total_src = " + JSON.stringify(src),
    "try:",
    "    _total_items = set(getattr(it, 'identifier', str(it)) for it in bpy.context.scene.render.bl_rna.properties['engine'].enum_items)",
    "except Exception:",
    "    _total_items = set()",
    "if 'BLENDER_EEVEE_NEXT' not in _total_items and 'BLENDER_EEVEE' in _total_items:",
    "    _total_src = _total_src.replace('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE')",
    "elif 'BLENDER_EEVEE' not in _total_items and 'BLENDER_EEVEE_NEXT' in _total_items:",
    "    _total_src = _total_re.sub(r'BLENDER_EEVEE(?!_NEXT)', 'BLENDER_EEVEE_NEXT', _total_src)",
    "if not hasattr(bpy.context.scene, 'eevee_next') and hasattr(bpy.context.scene, 'eevee'):",
    "    _total_src = _total_src.replace('.eevee_next', '.eevee')",
    "exec(compile(_total_src, '<total_blender>', 'exec'))",
  ].join("\n");
}

async function blenderPayload(name, args) {
  const bare = String(name || "").split("/").pop().split(".").pop();
  const a = args || {};
  if (bare === "get_scene_info" || bare === "blender_get_scene_info") return { type: "get_scene_info", params: {} };
  if (bare === "get_object_info" || bare === "blender_get_object_info") return { type: "get_object_info", params: { name: a.name || a.object_name || "" } };
  if (bare === "execute_blender_code" || bare === "execute_code" || bare === "blender_execute_code") return { type: "execute_code", params: { code: wrapBlenderUserCode(a.code || "") } };
  if (bare === "get_viewport_screenshot" || bare === "blender_screenshot") {
    // The installed Blender MCP addon requires an explicit filepath. Keep it in
    // TotalScript's sandboxed workspace, then convert it to an attachment after the
    // addon finishes; the machine-local path is never exposed to the AI page.
    let shot="total_blender_shot.png";const root=await agentWorkspaceRoot();
    if(root)shot=root.replace(/[\\/]+$/,"")+"/total_blender_shot.png";
    return {type:"get_viewport_screenshot",params:{max_size:Math.max(256,Math.min(1600,Number(a.max_size)||800)),filepath:shot,format:"png"},_totalScreenshotPath:shot};
  }
  const mapped = BLENDER_CMD[bare];
  if (mapped) {
    const packed = await blenderOpsCode(mapped, a);
    return { type: "execute_code", params: { code: packed.py }, _totalStatus: packed.status, _totalMesh: packed.mesh };
  }
  const params = Object.assign({}, a);
  delete params.user_prompt;
  return { type: bare, params };
}

async function ensureBlenderScripts() {
  if (blenderScriptsReady) return;
  const py = await extText("tools/blender_once.py");
  const ps = await extText("tools/blender_once.ps1");
  await localWrite("blender_once.py", py);
  await localWrite("blender_once.ps1", ps);
  blenderScriptsReady = true;
}

let blenderCallLock = Promise.resolve();
function blenderScreenshotImages(result) {
  let value=result;
  if(typeof value==="string"&&/^\s*[\[{]/.test(value)){try{value=JSON.parse(value);}catch{}}
  const out=[];
  const add=(candidate,mime)=>{
    if(candidate&&typeof candidate==="object")candidate=candidate.data||candidate.base64||candidate.image;
    if(typeof candidate!=="string")return;
    const match=candidate.match(/^data:(image\/[a-z0-9.+-]+);base64,(.+)$/is);
    const data=(match?match[2]:candidate).replace(/\s+/g,"");
    // Reject paths, messages, and tiny malformed payloads; screenshots are PNG/JPEG base64.
    if(data.length<100||!/^[A-Za-z0-9+/]+={0,2}$/.test(data))return;
    const normalizedMime=/^image\//i.test(String(mime||""))?String(mime):String(mime||"").toLowerCase()==="jpg"?"image/jpeg":"image/png";
    out.push({mimeType:match?match[1]:normalizedMime,data});
  };
  if(value&&typeof value==="object"){
    for(const image of Array.isArray(value.images)?value.images:[])add(image,image&&image.mimeType);
    add(value.data,value.mimeType||value.format);
    add(value.base64,value.mimeType||value.format);
    add(value.image,value.mimeType||value.format);
    if(value.screenshot&&typeof value.screenshot==="object")add(value.screenshot,value.screenshot.mimeType);
  }
  return out;
}

function blenderInlinePayload(stdoutText) {
  const lines = String(stdoutText || "").split(/\r?\n/).filter((l) => l.startsWith("TOTAL_MESH_JSON:"));
  for (let i = lines.length - 1; i >= 0; i--) {
    try {
      const v = JSON.parse(lines[i].slice("TOTAL_MESH_JSON:".length));
      if (v && typeof v === "object") return v;
    } catch {}
  }
  return null;
}

// 1.84.0: keep the structured failure fields the tools scripts emit
// (error_class / allowed / hint / parameter / blender version) instead of
// flattening everything to one string - main.js renders them for the model.
function blenderStructuredError(result, fallback) {
  const out = { ok: false, error: String(result.error || fallback), skipped: result.skipped };
  for (const k of ["error_class", "deterministic", "allowed", "hint", "value", "parameter", "attribute", "blender", "command", "available"]) {
    if (result[k] !== undefined && result[k] !== null && result[k] !== "") out[k] = result[k];
  }
  return out;
}
async function blenderCall(name, args, timeout, allowUnverified = false) {
  if (!blenderAddon && !allowUnverified) {
    return { ok: false, error: "Blender is not connected. Click Connect Blender (Blender: N → MCP for Blender → Start MCP Server)." };
  }
  const run = async () => {
    await ensureBlenderScripts();
    const payload = await blenderPayload(name, args);
    const statusPath = payload._totalStatus || "";
    const meshPath = payload._totalMesh || "";
    const wire = { type: payload.type, params: payload.params };
    await localWrite("total_blender_in.json", JSON.stringify(wire));
    // If every Python runner fails before launching, an old successful output
    // file must not satisfy the live get_scene_info handshake (or any tool call).
    await localWrite("total_blender_out.json", "");
    let plat = { os: "win" };
    try { plat = await chrome.runtime.getPlatformInfo(); } catch {}
    const win = plat.os === "win";
    const secs = Math.max(20, Math.min(180, Math.round((timeout || 120000) / 1000)));
    const cmds = win ? [
      "powershell -NoProfile -ExecutionPolicy Bypass -File blender_once.ps1 total_blender_in.json total_blender_out.json",
      "py -3 blender_once.py total_blender_in.json total_blender_out.json",
      "python blender_once.py total_blender_in.json total_blender_out.json",
    ] : [
      "python3 blender_once.py total_blender_in.json total_blender_out.json",
      "python blender_once.py total_blender_in.json total_blender_out.json",
    ];
    let last = "";
    let okRun = false;
    for (const cmd of cmds) {
      const r = await localRun(cmd, secs);
      last = String((r && (r.text || r.error)) || "");
      if (/TOTAL_BLENDER_OK/.test(last)) { okRun = true; break; }
      // Blender refused / socket error — do not try py/python after PowerShell already ran.
      if (/TOTAL_BLENDER_ERR/.test(last)) break;
      // Missing interpreter only: try the next runner. Anything else is a real error.
      if (!/not recognized|cannot find|No such file|not found|is not recognized/i.test(last)) break;
    }
    let raw = "";
    try { raw = await localReadWrapped("total_blender_out.json"); } catch (e) {
      if (!okRun) return { ok: false, error: last.slice(0, 400) || String(e.message || e) };
    }
    let data;
    try { data = JSON.parse(raw); } catch {
      return { ok: false, error: raw ? raw.slice(0, 400) : (last.slice(0, 400) || "empty Blender response") };
    }
    if (data && data.status === "error") {
      const msg = data.message || "Blender addon error";
      const socketDropped = /not listening|closed|actively refused|10061|Connection refused/i.test(msg);
      const definitelyNotDispatched = /not listening|actively refused|10061|Connection refused/i.test(msg);
      if (socketDropped) setBlender(false, "Blender addon dropped. Start MCP Server in Blender, then Connect Blender again.");
      // A refused TCP connection proves no tool reached Blender; a closed socket
      // could have happened after execution, so clear status but never replay it.
      if (definitelyNotDispatched) return { ok: false, kind: "disconnected", errorCode: "BLENDER_OFFLINE", error: msg };
      return { ok: false, error: msg };
    }
    let result = (data && Object.prototype.hasOwnProperty.call(data, "result")) ? data.result : data;
    // execute_code answers {executed:true, result:"<captured stdout>"}; our ops
    // script prints its whole payload on one "TOTAL_MESH_JSON:" line there. Read
    // it from the stdout STRING (the old code searched JSON.stringify(result),
    // where the payload's quotes are escaped, so JSON.parse never succeeded).
    const stdoutText = result && typeof result === "object" && typeof result.result === "string" ? result.result
      : typeof result === "string" ? result : "";
    const inline = blenderInlinePayload(stdoutText);
    if (inline) result = inline;
    if (result && result.ok === false) {
      return blenderStructuredError(result, "Blender FBX failed");
    }
    if (statusPath && !inline) {
      // Fallback only: the status file lives in the workspace when total-core told
      // us its root; otherwise Blender wrote it next to its own executable.
      try {
        const st = await localReadWrapped(statusPath);
        if (st) {
          try { result = JSON.parse(st); } catch {}
        }
      } catch {}
    }
    if (result && result.ok === false) {
      return blenderStructuredError(result, "Blender command failed");
    }
    let meshes = result && result.meshes;
    const mf = (result && result.mesh_file) || meshPath || "total_mesh.json";
    const wantsMeshes = payload.type === "execute_code" && /"dump"|"export_fbx"/.test(String(payload.params && payload.params.code || "").slice(0, 400));
    if ((!meshes || !meshes.length) && mf && (wantsMeshes || (result && result.inline === false))) {
      for (const cand of [meshPath || "total_mesh.json", "total_mesh.json"]) {
        try {
          const rawM = await localReadWrapped(cand);
          if (!rawM) continue;
          const parsed = JSON.parse(rawM);
          meshes = parsed.meshes || (parsed.result && parsed.result.meshes);
          if (meshes && meshes.length) break;
        } catch {}
      }
    }
    if (meshes && meshes.length && result && typeof result === "object") result.meshes = meshes;
    const screenshotImages=payload.type==="get_viewport_screenshot"?blenderScreenshotImages(result):[];
    if(payload.type==="get_viewport_screenshot"&&!screenshotImages.length&&payload._totalScreenshotPath){
      try{screenshotImages.push({mimeType:"image/png",data:await localImageBase64(payload._totalScreenshotPath)});}
      catch(e){return {ok:false,error:`Blender created the viewport capture, but TotalScript could not attach it: ${String(e&&e.message||e)}`};}
    }
    if(payload.type==="get_viewport_screenshot"&&!screenshotImages.length)return {ok:false,error:"Blender returned no viewport image data"};
    // 1.83.0: asset_inspect renders several PNGs (front / side / top / iso) into
    // the workspace; attach every file that really exists so the model judges
    // the asset from more than one angle. Missing files are reported, not faked.
    if(result&&typeof result==="object"&&Array.isArray(result.render_files)&&result.render_files.length){
      const missing=[];
      for(const fp of result.render_files.slice(0,7)){
        try{screenshotImages.push({mimeType:"image/png",data:await localImageBase64(String(fp))});}
        catch(e){missing.push(String(fp)+": "+String(e&&e.message||e));}
      }
      if(missing.length)result.render_attach_errors=missing;
      if(!screenshotImages.length)return {ok:false,error:"Blender rendered the inspection views but TotalScript could not attach them: "+missing.join("; ")};
    }
    let textResult = result;
    if (result && typeof result === "object" && Array.isArray(result.meshes)) {
      textResult = Object.assign({}, result);
      delete textResult.meshes;
      textResult.mesh_summary = result.meshes.map((m) => ({ name: m.name, verts: (m.verts || []).length, tris: m.tris || Math.floor((m.faces || []).length / 3) }));
    }
    let textOut = typeof textResult === "string" ? textResult : JSON.stringify(textResult, null, 2);
    return { ok: true, text: textOut, images: screenshotImages, meshFile: mf, filepath: result && result.filepath, meshes: meshes || undefined, skipped: result && result.skipped };
  };
  const prev = blenderCallLock;
  let release;
  blenderCallLock = new Promise((res) => { release = res; });
  await prev.catch(() => {});
  try { return await run(); }
  finally { release(); }
}

async function dispatchBlenderTool(name, args, timeout) {
  if (!isBlenderToolName(name)) return null;
  if (!blenderAddon) {
    return {
      ok: false,
      kind: "disconnected",
      errorCode: "BLENDER_OFFLINE",
      error: blenderError || "Blender is not connected. Start MCP Server in Blender, then use Connect Blender in TotalScript.",
    };
  }
  return blenderCall(name, args, timeout);
}

async function robloxCsrf() {
  try {
    const r = await fetch("https://auth.roblox.com/v2/logout", { method: "POST", credentials: "include" });
    return r.headers.get("x-csrf-token") || r.headers.get("X-CSRF-TOKEN") || "";
  } catch {
    return "";
  }
}
async function robloxAuthedFetch(url, opts) {
  opts = opts || {};
  const method = opts.method || "GET";
  // FormData bodies must set their own multipart boundary - never force JSON on them.
  const isForm = typeof FormData !== "undefined" && opts.body instanceof FormData;
  const headers = Object.assign({}, method !== "GET" && !isForm ? { "Content-Type": "application/json" } : {}, opts.headers || {});
  const go = async (token) => {
    const h = Object.assign({}, headers);
    if (token) h["X-CSRF-TOKEN"] = token;
    const r = await fetch(url, { method, credentials: "include", headers: h, body: opts.body });
    const text = await r.text();
    const csrf = r.headers.get("x-csrf-token") || r.headers.get("X-CSRF-TOKEN") || "";
    return { r, text, csrf };
  };
  let token = await robloxCsrf();
  let res = await go(token);
  if ((res.r.status === 403 || res.r.status === 401) && res.csrf && res.csrf !== token) {
    res = await go(res.csrf);
  }
  let data = null;
  try { data = JSON.parse(res.text); } catch {}
  return { ok: res.r.ok, status: res.r.status, text: res.text, data };
}
async function robloxResolveUniverse(msg) {
  let universeId = Number(msg.universeId || msg.universe_id || msg.gameId || 0) || 0;
  const placeId = Number(msg.placeId || msg.place_id || 0) || 0;
  if (universeId > 0) return { ok: true, universeId, placeId };
  if (placeId > 0) {
    const res = await robloxAuthedFetch("https://apis.roblox.com/universes/v1/places/" + placeId + "/universe", { method: "GET" });
    const id = Number(res.data && (res.data.universeId || res.data.id) || 0) || 0;
    if (id > 0) return { ok: true, universeId: id, placeId };
  }
  const listed = await robloxAuthedFetch("https://develop.roblox.com/v1/user/universes?limit=50&sortOrder=Desc", { method: "GET" });
  const rows = (listed.data && listed.data.data) || [];
  if (placeId > 0) {
    const hit = rows.find((u) => Number(u.rootPlaceId) === placeId || Number(u.id) === placeId);
    if (hit) return { ok: true, universeId: Number(hit.id), placeId, name: hit.name };
  }
  if (rows.length === 1) return { ok: true, universeId: Number(rows[0].id), placeId: Number(rows[0].rootPlaceId) || placeId, name: rows[0].name };
  if (rows.length > 1) {
    const top = rows[0];
    return {
      ok: true,
      universeId: Number(top.id),
      placeId: Number(top.rootPlaceId) || placeId,
      name: top.name,
      candidates: rows.slice(0, 8).map((u) => ({ id: u.id, name: u.name, rootPlaceId: u.rootPlaceId })),
    };
  }
  const who = await robloxAuthedFetch("https://users.roblox.com/v1/users/authenticated", { method: "GET" });
  if (!who.ok) return { ok: false, error: "Could not reach the game. Sign into roblox.com in this Chrome profile, publish the place in Studio, then retry." };
  return { ok: false, error: "Could not reach a universe for this place (GameId/PlaceId empty). Publish the place (File > Publish to Roblox) so it has a Universe ID." };
}
async function creatorAssetInfo(assetId){
  const id=Number(assetId);if(!Number.isInteger(id)||id<1)return {success:false,error:{code:"INVALID_PARAMETER",message:"assetId must be a positive integer"}};
  try{const r=await fetch(`https://economy.roblox.com/v2/assets/${id}/details`,{method:"GET",credentials:"include",redirect:"error"});const raw=await r.text();let data=null;try{data=JSON.parse(raw);}catch{}if(r.status===401||r.status===403)return {success:false,error:{code:"AUTH_REQUIRED",message:"Roblox authentication or asset permission is required"},status:r.status};if(!r.ok)return {success:false,error:{code:r.status===404?"COMMAND_NOT_FOUND":"PERMISSION_DENIED",message:data&&data.message||raw.slice(0,300)||`HTTP ${r.status}`},status:r.status};return {success:true,operation:"getPublishedAsset",assetId:id,status:"verified",asset:data};}catch(e){return {success:false,error:{code:"PUBLISH_FAILED",message:String(e&&e.message||e)}};}
}
// ── Monetization through the user's roblox.com browser session ──
// 1.45.0: Roblox retired the legacy routes on 2026-04-23 (POST game-passes/v1/
// game-passes, …/{id}/details, developer-products/v1 …/developerproducts,
// games.roblox.com/v1/games/{id}/game-passes). The documented Open Cloud
// endpoints accept the same .ROBLOSECURITY cookie (+ X-CSRF-TOKEN), so the
// extension keeps working with zero setup — and total-core offers the identical
// calls with an API key (cloud_* tools) for people who prefer that.
const RBX_APIS = "https://apis.roblox.com";
function robloxErrorText(res) {
  const d = res.data || {};
  return String(d.errorMessage || d.message || d.error || (Array.isArray(d.errors) && d.errors[0] && d.errors[0].message) || (res.text || "").slice(0, 280) || ("HTTP " + res.status)) + (d.field ? " (field " + d.field + ")" : "") + (d.hint ? " — " + d.hint : "");
}
function robloxPrice(p) {
  if (!p || typeof p !== "object") return null;
  if (p.price != null) return p.price;
  const pi = p.priceInformation;
  if (pi && typeof pi === "object") {
    for (const k of ["defaultPriceInRobux", "price", "priceInRobux"]) if (pi[k] != null) return pi[k];
  }
  return p.priceInRobux != null ? p.priceInRobux : null;
}
async function robloxIconBlob(msg, placeholderLabel) {
  if (msg.iconDataUrl && /^data:image\//.test(String(msg.iconDataUrl))) {
    try { return await (await fetch(String(msg.iconDataUrl))).blob(); } catch {}
  }
  return placeholderLabel ? await robloxPlaceholderIcon(placeholderLabel) : null;
}
async function robloxCreateDevProduct(msg) {
  const resolved = await robloxResolveUniverse(msg);
  if (!resolved.ok) return resolved;
  const universeId = resolved.universeId;
  const name = String(msg.name || "").trim();
  const description = String(msg.description || name).trim();
  const priceInRobux = Math.floor(Number(msg.priceInRobux || msg.price || 0));
  if (!name) return { ok: false, error: "name required" };
  if (!priceInRobux || priceInRobux < 1) return { ok: false, error: "priceInRobux must be >= 1" };
  const form = new FormData();
  form.append("name", name);
  form.append("description", description);
  form.append("price", String(priceInRobux));
  form.append("isForSale", msg.isForSale === false ? "false" : "true");
  const icon = await robloxIconBlob(msg, "");
  if (icon) form.append("imageFile", icon, "icon.png");
  const res = await robloxAuthedFetch(RBX_APIS + "/developer-products/v2/universes/" + universeId + "/developer-products", { method: "POST", body: form });
  if (!res.ok) {
    return { ok: false, error: robloxAuthError(res) + " (universe " + universeId + (resolved.name ? " / " + resolved.name : "") + ")", status: res.status, universeId: universeId, dashboard: "https://create.roblox.com/dashboard/creations/experiences/" + universeId + "/monetization/developer-products" };
  }
  const product = res.data || {};
  return { ok: true, product: product, productId: Number(product.productId || product.id || 0) || 0, universeId: universeId, universeName: resolved.name || "", price: priceInRobux, text: JSON.stringify(product) };
}
async function robloxUpdateDevProduct(msg) {
  const productId = Number(msg.productId || msg.product_id || msg.id || 0) || 0;
  if (!productId) return { ok: false, error: "productId required" };
  const resolved = await robloxResolveUniverse(msg);
  if (!resolved.ok) return resolved;
  const form = new FormData();
  let fields = 0;
  if (msg.name != null && String(msg.name).trim()) { form.append("name", String(msg.name).trim()); fields++; }
  if (msg.description != null) { form.append("description", String(msg.description)); fields++; }
  const price = msg.price != null ? Math.floor(Number(msg.price)) : NaN;
  if (Number.isFinite(price) && price >= 1) { form.append("price", String(price)); fields++; }
  if (msg.isForSale != null) { form.append("isForSale", msg.isForSale ? "true" : "false"); fields++; }
  const icon = await robloxIconBlob(msg, "");
  if (icon) { form.append("imageFile", icon, "icon.png"); fields++; }
  if (!fields) return { ok: false, error: "nothing to update - pass name, description, price, isForSale or iconDataUrl" };
  const res = await robloxAuthedFetch(RBX_APIS + "/developer-products/v2/universes/" + resolved.universeId + "/developer-products/" + productId, { method: "PATCH", body: form });
  if (!res.ok) return { ok: false, error: robloxAuthError(res), status: res.status };
  return { ok: true, productId: productId, universeId: resolved.universeId, updated: fields, details: res.data || {}, text: res.text || ("HTTP " + res.status) };
}
async function robloxListDevProducts(msg) {
  const resolved = await robloxResolveUniverse(msg);
  if (!resolved.ok) return resolved;
  const universeId = resolved.universeId;
  const res = await robloxAuthedFetch(RBX_APIS + "/developer-products/v2/universes/" + universeId + "/developer-products/creator?pageSize=100", { method: "GET" });
  if (!res.ok) return { ok: false, error: robloxAuthError(res), status: res.status };
  const list = (res.data && Array.isArray(res.data.developerProducts) ? res.data.developerProducts : []).map((p) => ({ id: p.productId, name: p.name, price: robloxPrice(p), forSale: p.isForSale, description: p.description }));
  return { ok: true, universeId: universeId, universeName: resolved.name || "", products: list, text: JSON.stringify(list) };
}

// ── Game passes (same browser session, same Open Cloud routes) ──
function robloxAuthError(res) {
  const err = robloxErrorText(res);
  if (res.status === 401 || res.status === 403) {
    return "Not signed into Roblox in this Chrome profile (or no edit rights on this experience). Open roblox.com, log in with the account that owns the game, then retry. (" + err + ")";
  }
  return String(err);
}
// 512x512 PNG icon so a pass can be created without the user drawing one.
async function robloxPlaceholderIcon(label) {
  if (typeof OffscreenCanvas === "undefined") return null;
  try {
    const c = new OffscreenCanvas(512, 512);
    const g = c.getContext("2d");
    const bg = g.createLinearGradient(0, 0, 0, 512);
    bg.addColorStop(0, "#1b1a22"); bg.addColorStop(1, "#2a2436");
    g.fillStyle = bg; g.fillRect(0, 0, 512, 512);
    const disc = g.createRadialGradient(256, 236, 20, 256, 256, 190);
    disc.addColorStop(0, "#ffe9a3"); disc.addColorStop(0.6, "#f2b63a"); disc.addColorStop(1, "#b87414");
    g.fillStyle = disc; g.beginPath(); g.arc(256, 256, 186, 0, Math.PI * 2); g.fill();
    g.lineWidth = 14; g.strokeStyle = "#5a3a0a"; g.stroke();
    const text = String(label || "").trim().slice(0, 2).toUpperCase() || "GP";
    g.fillStyle = "#3a2405"; g.font = "bold 190px sans-serif"; g.textAlign = "center"; g.textBaseline = "middle";
    g.fillText(text, 256, 268);
    return await c.convertToBlob({ type: "image/png" });
  } catch {
    return null;
  }
}
async function robloxCreateGamePass(msg) {
  const resolved = await robloxResolveUniverse(msg);
  if (!resolved.ok) return resolved;
  const universeId = resolved.universeId;
  const name = String(msg.name || "").trim();
  const description = String(msg.description || name).trim();
  const price = Math.floor(Number(msg.price || msg.priceInRobux || 0)) || 0;
  if (!name) return { ok: false, error: "name required" };
  const form = new FormData();
  form.append("name", name);
  form.append("description", description);
  if (price > 0) form.append("price", String(price));
  form.append("isForSale", price > 0 && msg.isForSale !== false ? "true" : "false");
  const icon = await robloxIconBlob(msg, name);
  if (icon) form.append("imageFile", icon, "icon.png");
  const res = await robloxAuthedFetch(RBX_APIS + "/game-passes/v1/universes/" + universeId + "/game-passes", { method: "POST", body: form });
  if (!res.ok) {
    return { ok: false, error: robloxAuthError(res) + " (universe " + universeId + (resolved.name ? " / " + resolved.name : "") + ")", status: res.status, universeId: universeId, dashboard: "https://create.roblox.com/dashboard/creations/experiences/" + universeId + "/monetization/passes" };
  }
  const created = res.data || {};
  const gamePassId = Number(created.gamePassId || created.id || 0) || 0;
  return { ok: true, gamePassId: gamePassId, universeId: universeId, universeName: resolved.name || "", name: name, price: price > 0 ? price : 0, forSale: price > 0 && msg.isForSale !== false, created: created, text: JSON.stringify(created) };
}
async function robloxUpdateGamePass(msg) {
  const gamePassId = Number(msg.gamePassId || msg.gamepass_id || msg.id || 0) || 0;
  if (!gamePassId) return { ok: false, error: "gamePassId required" };
  const resolved = await robloxResolveUniverse(msg);
  if (!resolved.ok) return resolved;
  const form = new FormData();
  let fields = 0;
  if (msg.name != null && String(msg.name).trim()) { form.append("name", String(msg.name).trim()); fields++; }
  if (msg.description != null) { form.append("description", String(msg.description)); fields++; }
  const price = msg.price != null ? Math.floor(Number(msg.price)) : NaN;
  if (Number.isFinite(price) && price >= 0) { form.append("price", String(price)); fields++; }
  const forSale = msg.isForSale != null ? !!msg.isForSale : (Number.isFinite(price) && price > 0 ? true : null);
  if (forSale !== null) { form.append("isForSale", forSale ? "true" : "false"); fields++; }
  const icon = await robloxIconBlob(msg, "");
  if (icon) { form.append("imageFile", icon, "icon.png"); fields++; }
  if (!fields) return { ok: false, error: "nothing to update - pass name, description, price, isForSale or iconDataUrl" };
  const res = await robloxAuthedFetch(RBX_APIS + "/game-passes/v1/universes/" + resolved.universeId + "/game-passes/" + gamePassId, { method: "PATCH", body: form });
  if (!res.ok) return { ok: false, error: robloxAuthError(res), status: res.status };
  return { ok: true, gamePassId: gamePassId, universeId: resolved.universeId, updated: fields, details: res.data || {}, text: res.text || ("HTTP " + res.status) };
}
async function robloxListGamePasses(msg) {
  const resolved = await robloxResolveUniverse(msg);
  if (!resolved.ok) return resolved;
  const universeId = resolved.universeId;
  const res = await robloxAuthedFetch(RBX_APIS + "/game-passes/v1/universes/" + universeId + "/game-passes/creator?pageSize=100", { method: "GET" });
  if (!res.ok) return { ok: false, error: robloxAuthError(res), status: res.status };
  const list = (res.data && Array.isArray(res.data.gamePasses) ? res.data.gamePasses : []).map((p) => ({ id: p.gamePassId, name: p.name, price: robloxPrice(p), forSale: p.isForSale, description: p.description }));
  return { ok: true, universeId: universeId, universeName: resolved.name || "", passes: list, text: JSON.stringify(list) };
}

// ── Animations (browser session) ──
// The Studio plugin serialises the KeyframeSequence to .rbxmx (animation_export);
// the upload itself needs a roblox.com identity. Two cookie routes, in order:
//   1. apis.roblox.com/assets/user-auth/v1/assets — the Assets API as Studio's
//      own asset manager calls it (same payload as Open Cloud, cookie + CSRF),
//      then the operation is polled for the asset id;
//   2. www.roblox.com/ide/publish/uploadnewanimation — the classic Animation
//      Editor upload (response body = the new asset id).
// total-core's cloud_animation_publish is the API-key variant of route 1.
async function robloxWhoAmI() {
  const who = await robloxAuthedFetch("https://users.roblox.com/v1/users/authenticated", { method: "GET" });
  return who.ok && who.data ? { id: Number(who.data.id || 0) || 0, name: String(who.data.name || "") } : { id: 0, name: "" };
}
async function robloxPublishAnimation(msg) {
  const xml = String(msg.xml || "");
  if (!/^\s*<roblox[\s>]/.test(xml) || !xml.includes('class="KeyframeSequence"')) return { ok: false, error: "xml must be the .rbxmx of a KeyframeSequence (animation_export)" };
  if (xml.length > 4000000) return { ok: false, error: "animation too large to upload (" + xml.length + " bytes)" };
  const name = String(msg.name || "Animation").trim().slice(0, 50) || "Animation";
  const description = String(msg.description || name).trim().slice(0, 1000);
  const isGroup = /group/i.test(String(msg.creatorType || "")) && Number(msg.creatorId) > 0;
  let userId = Number(msg.userId || 0) || 0;
  const me = await robloxWhoAmI();
  if (!me.id) return { ok: false, error: "Not signed into Roblox in this Chrome profile. Open roblox.com, log in with the account that owns the game, then retry." };
  if (!userId) userId = me.id;
  const creator = isGroup ? { groupId: String(msg.creatorId) } : { userId: String(userId) };
  const tried = [];
  // Route 1 — Assets API with the browser session.
  try {
    const form = new FormData();
    form.append("request", JSON.stringify({ assetType: "Animation", displayName: name, description: description, creationContext: { creator: creator } }));
    form.append("fileContent", new Blob([xml], { type: "model/x-rbxm" }), "animation.rbxmx");
    const res = await robloxAuthedFetch(RBX_APIS + "/assets/user-auth/v1/assets", { method: "POST", body: form });
    if (res.ok) {
      const op = res.data || {};
      let assetId = Number(op.response && op.response.assetId || 0) || 0;
      const path = op.path || (op.operationId ? "operations/" + op.operationId : "");
      let last = op;
      for (let i = 0; !assetId && path && i < 30; i++) {
        await new Promise((r) => setTimeout(r, 1000));
        const poll = await robloxAuthedFetch(RBX_APIS + "/assets/user-auth/v1/" + path, { method: "GET" });
        if (!poll.ok) continue;
        last = poll.data || {};
        if (last.done) { assetId = Number(last.response && last.response.assetId || 0) || 0; break; }
      }
      if (assetId) return { ok: true, assetId: assetId, animationId: "rbxassetid://" + assetId, name: name, via: "roblox.com session (Assets API)", creator: isGroup ? "group" : "user", moderation: last.response && last.response.moderationResult && last.response.moderationResult.moderationState || null };
      tried.push("assets api: " + (last.error ? JSON.stringify(last.error).slice(0, 200) : "operation did not finish"));
    } else {
      tried.push("assets api: HTTP " + res.status + " " + robloxErrorText(res).slice(0, 160));
    }
  } catch (e) { tried.push("assets api: " + String(e && e.message || e).slice(0, 160)); }
  // Route 2 — the classic animation upload.
  try {
    const q = new URLSearchParams({ assetTypeName: "Animation", name: name, description: description, AllID: "1", ispublic: "False", allowComments: "True", isGamesAsset: "False" });
    if (isGroup) q.set("groupId", String(msg.creatorId));
    const res = await robloxAuthedFetch("https://www.roblox.com/ide/publish/uploadnewanimation?" + q.toString(), { method: "POST", body: xml, headers: { "Content-Type": "application/xml" } });
    const id = Number(String(res.text || "").trim()) || 0;
    if (res.ok && id > 0) return { ok: true, assetId: id, animationId: "rbxassetid://" + id, name: name, via: "roblox.com session (animation upload)", creator: isGroup ? "group" : "user" };
    tried.push("upload: HTTP " + res.status + " " + String(res.text || "").slice(0, 160));
  } catch (e) { tried.push("upload: " + String(e && e.message || e).slice(0, 160)); }
  return { ok: false, error: "could not upload the animation with the browser session — " + tried.join(" | "), tried: tried };
}

// Image Studio provider profiles live behind the service worker. The content
// script receives only public metadata (configured + masked key tail), never a
// stored credential. Native integrations are pinned to their official hosts;
// only the explicit OpenAI-compatible profile accepts a custom base URL.
const IMAGE_API_PROVIDERS = Object.freeze({
  openai: Object.freeze({ protocol: "openai-compatible", base: "https://api.openai.com/v1", model: "gpt-image-1" }),
  google: Object.freeze({ protocol: "google-imagen", base: "https://generativelanguage.googleapis.com/v1beta", model: "imagen-4.0-generate-001" }),
  stability: Object.freeze({ protocol: "stability", base: "https://api.stability.ai", model: "core" }),
  replicate: Object.freeze({ protocol: "replicate", base: "https://api.replicate.com", model: "black-forest-labs/flux-schnell" }),
  compatible: Object.freeze({ protocol: "openai-compatible", base: "", model: "" }),
});
const IMAGE_API_PROVIDER_IDS = Object.keys(IMAGE_API_PROVIDERS);
const IMAGE_API_MAX_BYTES = 20 * 1024 * 1024;
function normalizeImageApiConfig(raw) {
  raw = raw && typeof raw === "object" ? raw : {};
  const profilesIn = raw.profiles && typeof raw.profiles === "object" ? raw.profiles : null;
  const profiles = {};
  if (profilesIn) {
    for (const id of IMAGE_API_PROVIDER_IDS) {
      const saved = profilesIn[id] && typeof profilesIn[id] === "object" ? profilesIn[id] : {};
      const defaults = IMAGE_API_PROVIDERS[id];
      const savedModel = String(saved.model == null ? defaults.model : saved.model).trim();
      profiles[id] = {
        base: id === "compatible" ? String(saved.base == null ? defaults.base : saved.base).trim() : defaults.base,
        model: id !== "compatible" && !savedModel ? defaults.model : savedModel,
        key: String(saved.key || ""),
      };
    }
  }
  let legacyProvider = null;
  if (!profilesIn && ("base" in raw || "model" in raw || "key" in raw)) {
    const legacyBase = String(raw.base || "").trim().replace(/\/+$/, "");
    legacyProvider = IMAGE_API_PROVIDER_IDS.includes(raw.provider) ? raw.provider :
      (legacyBase && legacyBase !== IMAGE_API_PROVIDERS.openai.base ? "compatible" : "openai");
    const defaults = IMAGE_API_PROVIDERS[legacyProvider];
    const legacyModel = String(raw.model == null ? defaults.model : raw.model).trim();
    profiles[legacyProvider] = {
      base: legacyProvider === "compatible" ? String(raw.base == null ? defaults.base : raw.base).trim() : defaults.base,
      model: legacyProvider !== "compatible" && !legacyModel ? defaults.model : legacyModel,
      key: String(raw.key || ""),
    };
  }
  for (const id of IMAGE_API_PROVIDER_IDS) {
    if (!profiles[id]) profiles[id] = { base: IMAGE_API_PROVIDERS[id].base, model: IMAGE_API_PROVIDERS[id].model, key: "" };
  }
  const provider = IMAGE_API_PROVIDER_IDS.includes(raw.provider) ? raw.provider : (legacyProvider || "openai");
  return { version: 2, provider, profiles };
}
function imageApiPublicStatus(raw) {
  const config = normalizeImageApiConfig(raw), profiles = {};
  for (const id of IMAGE_API_PROVIDER_IDS) {
    const profile = config.profiles[id];
    profiles[id] = { base: profile.base, model: profile.model, configured: !!profile.key, key_masked: profile.key ? "…" + profile.key.slice(-4) : "" };
  }
  const active = config.profiles[config.provider];
  return { ok: true, provider: config.provider, configured: !!active.key, base: active.base, model: active.model,
    key_masked: active.key ? "…" + active.key.slice(-4) : "", profiles };
}
async function readImageApiConfig() {
  const stored = (await chrome.storage.local.get("rs_image_api")).rs_image_api || {};
  const config = normalizeImageApiConfig(stored);
  // One-time migration from the original {base, model, key} setting.
  if (!stored.profiles && ("base" in stored || "model" in stored || "key" in stored)) {
    await chrome.storage.local.set({ rs_image_api: config });
  }
  return config;
}
function updateImageApiConfig(raw, msg) {
  const config = normalizeImageApiConfig(raw);
  const provider = String(msg.provider || config.provider);
  if (!IMAGE_API_PROVIDER_IDS.includes(provider)) return { ok: false, error: "unknown image API provider" };
  const profile = config.profiles[provider];
  const action = String(msg.action || "");
  if (action === "select") {
    config.provider = provider;
  } else if (action === "save" || action === "clear") {
    if (action === "clear") profile.key = "";
    else {
      const key = String(msg.key || "").trim();
      if (key.length > 4096) return { ok: false, error: "API key is too long" };
      if (key) profile.key = key; // blank means keep the existing credential
    }
    if (provider === "compatible" && msg.base != null) {
      const base = String(msg.base || "").trim();
      if (base.length > 2048) return { ok: false, error: "image API base URL is too long" };
      profile.base = base;
    }
    if (msg.model != null) {
      const model = String(msg.model || "").trim();
      if (model.length > 300) return { ok: false, error: "image API model name is too long" };
      profile.model = provider !== "compatible" && !model ? IMAGE_API_PROVIDERS[provider].model : model;
    }
    config.provider = provider;
  } else return { ok: false, error: "unknown image API settings action" };
  config.version = 2;
  return { ok: true, config };
}
function imageApiSafeText(value, key) {
  let text = typeof value === "string" ? value : String(value == null ? "provider error" : value);
  if (key) text = text.split(key).join("[redacted]");
  return text.slice(0, 400);
}
function imageApiAspect(kind) {
  return /^(thumbnail|gui_background|gui_button)$/.test(String(kind || "")) ? "16:9" : "1:1";
}
function imageApiBytesToBase64(bytes) {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  return btoa(binary);
}
async function imageApiJsonResponse(res, key) {
  const text = await res.text();
  if (text.length > 30 * 1024 * 1024) return { json: null, text: "provider response exceeded the 30 MB safety limit" };
  let json = null;
  try { json = JSON.parse(text); } catch {}
  return { json, text: imageApiSafeText(text, key) };
}
async function imageApiGenerate(msg) {
  let key = "";
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 180000);
  try {
    const config = await readImageApiConfig();
    const provider = config.provider;
    const meta = IMAGE_API_PROVIDERS[provider];
    const profile = config.profiles[provider];
    key = String(profile.key || "");
    if (!key) return { ok: false, error: `no ${provider} image API key saved (Images window → API providers & keys)` };
    const model = String(profile.model || "").trim();
    if (!model) return { ok: false, error: `select a model for ${provider} in the Images window → API providers & keys` };
    const prompt = String(msg.prompt || "").slice(0, 4000);
    if (!prompt) return { ok: false, error: "prompt is required" };
    const base = String(profile.base || meta.base || "").trim().replace(/\/+$/, "");
    if (!/^https?:\/\//i.test(base)) return { ok: false, error: provider === "compatible" ? "custom image API base URL must start with http:// or https://" : "invalid image API endpoint" };
    const aspect = imageApiAspect(msg.kind);
    let url, init;
    if (provider === "google") {
      url = base + "/models/" + encodeURIComponent(model) + ":predict";
      init = { method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify({ instances: [{ prompt }], parameters: { sampleCount: 1, aspectRatio: aspect, outputMimeType: "image/png" } }), signal: controller.signal };
    } else if (provider === "stability") {
      const form = new FormData();
      form.set("prompt", prompt); form.set("output_format", "png"); form.set("aspect_ratio", aspect);
      url = base + "/v2beta/stable-image/generate/" + encodeURIComponent(model);
      init = { method: "POST", headers: { "Authorization": "Bearer " + key, "Accept": "image/*" }, body: form, signal: controller.signal };
    } else if (provider === "replicate") {
      const parts = model.split("/");
      if (parts.length !== 2 || parts.some((part) => !/^[A-Za-z0-9_.-]+$/.test(part))) return { ok: false, error: "Replicate model must be an owner/name path (for example black-forest-labs/flux-schnell)" };
      url = base + "/v1/models/" + parts.map(encodeURIComponent).join("/") + "/predictions";
      init = { method: "POST", headers: { "Authorization": "Bearer " + key, "Content-Type": "application/json", "Prefer": "wait=60" },
        body: JSON.stringify({ input: { prompt, aspect_ratio: aspect, output_format: "png" } }), signal: controller.signal };
    } else {
      const family = /gpt-image/i.test(model) ? "gpt-image" : /dall-e-3/i.test(model) ? "dall-e-3" : /dall-e-2/i.test(model) ? "dall-e-2" : "generic";
      const landscape = /^(thumbnail|gui_background|gui_button)$/.test(String(msg.kind || ""));
      const size = !landscape ? "1024x1024" : family === "gpt-image" ? "1536x1024" : family === "dall-e-3" ? "1792x1024" : "1024x1024";
      const body = { model, prompt, n: 1, size };
      if (family === "gpt-image") { body.output_format = "png"; if (msg.transparent) body.background = "transparent"; }
      else body.response_format = "b64_json";
      url = base + "/images/generations";
      init = { method: "POST", headers: { "Content-Type": "application/json", "Authorization": "Bearer " + key }, body: JSON.stringify(body), signal: controller.signal };
    }
    let res = await fetch(url, init);
    if (provider === "stability") {
      if (!res.ok) {
        const body = await res.text();
        return { ok: false, error: `HTTP ${res.status}: ${imageApiSafeText(body, key)}` };
      }
      const mime = String(res.headers.get("content-type") || "image/png").split(";")[0].trim().toLowerCase();
      const bytes = new Uint8Array(await res.arrayBuffer());
      if (bytes.length > IMAGE_API_MAX_BYTES) return { ok: false, error: "Stability returned an image larger than 20 MB" };
      if (!/^image\//.test(mime)) return { ok: false, error: "Stability response was not an image (" + mime + ")" };
      return { ok: true, b64: imageApiBytesToBase64(bytes), mime, provider, model, size: aspect };
    }
    let read = await imageApiJsonResponse(res, key);
    let json = read.json;
    if (!res.ok) {
      const detail = json && json.error && (json.error.message || json.error.code) || read.text;
      return { ok: false, error: `HTTP ${res.status}: ${imageApiSafeText(detail, key)}` };
    }
    if (provider === "replicate") {
      const deadline = Date.now() + 174000;
      while (json && (json.status === "starting" || json.status === "processing")) {
        const id = String(json.id || "");
        if (!id) return { ok: false, error: "Replicate returned a running prediction without an id" };
        if (Date.now() >= deadline) return { ok: false, error: "Replicate image generation timed out after 180 s" };
        await new Promise((resolve) => setTimeout(resolve, 1500));
        res = await fetch(base + "/v1/predictions/" + encodeURIComponent(id), {
          headers: { "Authorization": "Bearer " + key, "Content-Type": "application/json" }, signal: controller.signal,
        });
        read = await imageApiJsonResponse(res, key); json = read.json;
        if (!res.ok) return { ok: false, error: `Replicate status HTTP ${res.status}: ${imageApiSafeText((json && json.error) || read.text, key)}` };
      }
      if (json && (json.status === "failed" || json.status === "canceled")) return { ok: false, error: "Replicate prediction " + json.status + ": " + imageApiSafeText(json.error || "no provider detail", key) };
      const output = json && (Array.isArray(json.output) ? json.output[0] : json.output);
      if (typeof output !== "string" || !output) return { ok: false, error: "Replicate prediction returned no image URL" };
      return { ok: true, url: output, provider, model, size: aspect };
    }
    if (json && json.error) return { ok: false, error: imageApiSafeText(json.error.message || json.error.code || json.error, key) };
    if (provider === "google") {
      const prediction = json && Array.isArray(json.predictions) ? json.predictions[0] : null;
      const b64 = prediction && (prediction.bytesBase64Encoded || prediction.bytes_base64_encoded);
      if (!b64) return { ok: false, error: "Google Imagen returned no image bytes" };
      if (String(b64).length > Math.ceil(IMAGE_API_MAX_BYTES * 4 / 3) + 8) return { ok: false, error: "Google Imagen returned an image larger than 20 MB" };
      return { ok: true, b64: String(b64), mime: String(prediction.mimeType || "image/png"), provider, model, size: aspect };
    }
    const data = json && Array.isArray(json.data) ? json.data[0] : null;
    if (!data) return { ok: false, error: "the API returned no data[0]" };
    if (data.b64_json) {
      if (String(data.b64_json).length > Math.ceil(IMAGE_API_MAX_BYTES * 4 / 3) + 8) return { ok: false, error: "image API returned an image larger than 20 MB" };
      return { ok: true, b64: String(data.b64_json), mime: "image/png", provider, model, size: data.size || "", revised: data.revised_prompt || "" };
    }
    if (data.url) return { ok: true, url: String(data.url), provider, model, size: data.size || "", revised: data.revised_prompt || "" };
    return { ok: false, error: "data[0] carries neither b64_json nor url" };
  } catch (e) {
    return { ok: false, error: e && e.name === "AbortError" ? "image API timed out after 180 s" : imageApiSafeText(e && e.message || e, key) };
  } finally { clearTimeout(timer); }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (!msg || typeof msg !== "object" || typeof msg.type !== "string") {
      sendResponse({ ok:false, kind:"invalid-message", error:"background message requires a string type" });
      return;
    }
    switch (msg.type) {
      case "creator_asset_info":
        sendResponse(await creatorAssetInfo(msg.assetId));break;
      case "command_catalog":
        sendResponse({ok:true,commands:BLENDER_TOOLS,environment:"BLENDER",connected:blenderAddon});
        break;
      case "rs-get-engine":
        sendResponse({ engine });
        break;
      case "rs-open-extension-page": {
        // Only pages we ship may be opened this way (the AI switcher on a web
        // page cannot open chrome-extension:// URLs itself).
        const page = String(msg.page || "");
        // 2.21.0: only the CodeCraft page itself (the API-profile query went with the DeepSeek API chat)
        if (page !== CODECRAFT_PAGE) { sendResponse({ ok: false, error: "unknown extension page" }); break; }
        const url = chrome.runtime.getURL(CODECRAFT_PAGE);
        try {
          const tabs = await chrome.tabs.query({ url: url + "*" });
          if (tabs.length) { await chrome.tabs.update(tabs[0].id, { active: true }); try { await chrome.windows.update(tabs[0].windowId, { focused: true }); } catch {} }
          else await chrome.tabs.create({ url });
          sendResponse({ ok: true });
        } catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "rs-set-engine":
        engine = normalizeEngine(msg.engine);
        try { await chrome.storage.local.set({ [ENGINE_KEY]: engine }); } catch {}
        // fully isolate — wipe previous engine's cache so hallucination impossible
        try { ws?.close(); } catch {}
        connected = false;
        mcpAlive = false;
        toolsCache = [];
        serversCache = [];
        studioConnected = null;
        studioApp = null;
        studioProc = null;
        robloxEditorConnected = false;
        failAllPending(`engine switched to ${engine}`);
        pushActivity("engine", "info", `Engine switched to ${engine === "local" ? "AgentScript" : "Roblox"}`);
        reconnectDelay = RECONNECT_MIN;
        connect();
        broadcastStatus();
          // also push to all provider tabs so their bars / prompts flip instantly.
          // tabs.sendMessage returns a Promise in MV3 — orphaned content scripts
          // (tab not refreshed after reload) reject with "Receiving end does not
          // exist"; that's expected and harmless here, so swallow it.
          try {
            const tabs = await providerTabs();
            for (const t of tabs) chrome.tabs.sendMessage(t.id, { type: "rs-engine", engine }).catch(() => {});
          } catch {}
        sendResponse({ engine });
        break;
      case "rs-set-full": {
        // FULL PC ACCESS toggle for the AgentScript engine. The agent process
        // is the source of truth; mirror its answer into the status broadcast.
        const want = !!msg.enabled;
        try {
          const r = await fetch("http://127.0.0.1:3000/api/local-full", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ enabled: want }),
          });
          const j = await r.json().catch(() => ({}));
          localFull = j.local_full === true ? true : j.local_full === false ? false : want;
          try { chrome.storage.local.set({ "rs-local-full": localFull }); } catch {}
        } catch {
          localFull = want; // agent unreachable — optimistic, corrected on next poll
          try { chrome.storage.local.set({ "rs-local-full": localFull }); } catch {}
        }
        broadcastStatus();
        sendResponse({ ok: true, enabled: localFull });
        break;
      }
      case "rs-get-full":
        sendResponse({ enabled: localFull });
        break;
      case "status":
        // Self-heal after a worker wake-up - and do NOT answer "down" while that
        // dial is still in flight: a fresh worker has connected=false for a few
        // hundred ms, and answering immediately made every tab flash the red
        // "Bridge went down" banner on each wake-up (2.2.1).
        if (!connected && !manualStudioDisconnect) { connect(); await waitForConnection(STATUS_SETTLE_MS); }
        await figmaManualReady;
        sendResponse(statusObj());
        break;
      case "list_tools": {
        await figmaManualReady;
        if(!connected&&toolsCache.length===0){connect();const addonTools=mergeBlenderTools([]);sendResponse({ok:addonTools.length>0,tools:addonTools,studio:false,roblox_connected:false,servers:blenderServers(serversCache),errorCode:addonTools.length?undefined:"MCP_SERVER_UNAVAILABLE",error:addonTools.length?undefined:"MCP unavailable. Normal AI responses remain available."});break;}
        if(!msg.refresh&&toolsCache.length&&Date.now()-toolsCacheAt<MCP_CACHE_TTL_MS){sendResponse({ok:true,tools:mergeBlenderTools(toolsCache),studio:robloxEditorConnected===true,roblox_connected:robloxEditorConnected===true,servers:blenderServers(serversCache),cached:true,cacheAge:Date.now()-toolsCacheAt});break;}
        const discoveryStarted=Date.now();
        // Prefer a live refresh; fall back to cache so the loop never stalls.
        // Cached SCHEMAS are still useful while Studio is closed, but they are
        // not proof that an editor is attached. Preserve the strict probe bit in
        // this response so the content script cannot turn `tools.length > 0`
        // into a fake live Studio during bootstrap.
        const r = await send({ type: "list_tools" }, MCP_DISCOVERY_TIMEOUT_MS) || { ok: false, error: "bridge did not answer" };mcpTrace("tool_discovery",{duration:Date.now()-discoveryStarted,status:r.ok?"READY":"ERROR",errorCode:r.ok?null:"MCP_TOOL_DISCOVERY_FAILED"});
        if (r.ok && Array.isArray(r.tools)) toolsCache = r.tools;
        const tools = mergeBlenderTools(toolsCache);
        const isRobloxEngine = engine === "roblox" || engine === "anim";
        const liveStudio = isRobloxEngine
          ? (typeof r.studio === "boolean" ? r.studio : robloxEditorConnected)
          : false;
        if (isRobloxEngine) robloxEditorConnected = liveStudio === true;
        const ok = r.ok || tools.length > 0;
        sendResponse({
          ok, tools,
          studio: liveStudio === true,
          roblox_connected: liveStudio === true,
          servers: blenderServers(serversCache),
          error: r.ok ? undefined : r.error,
        });
        break;
      }
      case "studio_status": {
        // On-demand ground truth for bootstrap/list_commands. The periodic probe
        // can be a tick behind exactly when Studio was just closed or opened. If
        // that same probe is already in flight, wait for it instead of returning
        // the stale pre-probe bit.
        if (studioProbing) {
          const until = Date.now() + 12500;
          while (studioProbing && Date.now() < until) {
            await new Promise((resolve) => setTimeout(resolve, 100));
          }
        } else {
          await refreshStudioStatus();
        }
        const liveStudio = connected && robloxEditorConnected === true;
        sendResponse({
          ok: connected,
          studio: liveStudio,
          roblox_connected: liveStudio,
        });
        break;
      }
      case "mcp.healthCheck": {const t=performance.now();const live=connected&&ws&&ws.readyState===WebSocket.OPEN;const ping=live?await send({type:"ping"},2000):null;const healthy=!!(ping&&ping.ok);if(live&&!healthy)setMcpLifecycle("ERROR",{errorCode:ping?.errorCode||"MCP_TRANSPORT_ERROR"});sendResponse({success:true,connected:live&&healthy,state:mcpLifecycle,transport:"websocket",server:engineLabel(),latency:healthy?Math.round(performance.now()-t):null,capabilities:{tools:toolsCache.length},lastSuccessfulRequest:lastMessageAt||null,lastError:healthy?null:(ping?.errorCode||mcpDiagnostics.slice().reverse().find(x=>x.errorCode)||null),diagnostics:msg.debug?mcpDiagnostics.slice(-25):undefined});break;}
      case "mcp.reconnect":
        manualStudioDisconnect=false;reconnectAttempts=0;clearTimeout(reconnectTimer);try{ws&&ws.close();}catch{}ws=null;connected=false;connect();{const ok=await waitForConnection(MCP_CONNECT_TIMEOUT_MS);sendResponse(ok?{success:true,state:mcpLifecycle,connectionId}:{success:false,state:mcpLifecycle,error:{code:"MCP_CONNECTION_TIMEOUT",message:"MCP transport did not connect within the connection timeout"}});}break;
      case "mcp.refreshTools": {const r=await send({type:"list_tools"},MCP_DISCOVERY_TIMEOUT_MS);if(r?.ok&&Array.isArray(r.tools)){toolsCache=r.tools;toolsCacheAt=Date.now();setMcpLifecycle("READY");}sendResponse(r?.ok?{success:true,state:mcpLifecycle,tools:toolsCache.length}:{success:false,error:{code:"MCP_TOOL_DISCOVERY_FAILED",message:String(r?.error||"Tool discovery failed")}});break;}
      case "mcp.disconnect":
        manualStudioDisconnect=true;clearTimeout(reconnectTimer);try{ws&&ws.close();}catch{}ws=null;connected=false;setMcpLifecycle("CLOSED");sendResponse({success:true,state:"CLOSED"});break;
      case "studio.connect":
        manualStudioDisconnect=false;connect();await waitForConnection(12000);await refreshStudioStatus();sendResponse({success:connected&&robloxEditorConnected===true,state:connected&&robloxEditorConnected===true?"CONNECTED":connected?"CONNECTING":"DISCONNECTED",error:connected&&robloxEditorConnected===true?null:{code:"STUDIO_BRIDGE_OFFLINE",message:"Studio MCP is not reachable"}});break;
      case "studio.disconnect":
        manualStudioDisconnect=true;clearTimeout(reconnectTimer);try{ws&&ws.close();}catch{}ws=null;connected=false;robloxEditorConnected=false;studioConnected=false;failAllPending("Studio bridge disconnected by user");broadcastStatus();sendResponse({success:true,state:"DISCONNECTED"});break;
      case "studio.status":
      case "studio.healthCheck":
        if(!manualStudioDisconnect){connect();await waitForConnection(6000);await refreshStudioStatus();}sendResponse({success:connected&&robloxEditorConnected===true,state:manualStudioDisconnect||!connected?"DISCONNECTED":robloxEditorConnected===true?([...pending.values()].some(p=>p.type==="call_tool")?"BUSY":"CONNECTED"):"ERROR",bridge:connected,studio:robloxEditorConnected===true,protocolVersion:"1.0",error:connected&&robloxEditorConnected===true?null:{code:"STUDIO_BRIDGE_OFFLINE",message:"Studio MCP did not answer the health probe"}});break;
      case "call_tool": {
        const timeout = (msg.timeout || 120000) + 10000;
        // Figma Design plugin tools use total-core's token-paired port-3000
        // bridge, independent of both the active engine and Figma Desktop MCP.
        if (isFigmaPluginToolName(msg.name)) {
          if (!connected) { connect(); await waitForConnection(6000); }
          if (!connected) {
            sendResponse({ ok: false, kind: "disconnected", errorCode: "TOTAL_CORE_OFFLINE", error: "The TotalScript desktop bridge on port 3000 is not connected; no Figma operation was sent." });
            break;
          }
          const started = performance.now();
          const result = await send({ type: "call_tool", name: String(msg.name).split("/").pop(), arguments: msg.arguments || {}, timeout: msg.timeout, requestId: msg.requestId }, timeout);
          const elapsed = Math.round(performance.now() - started);
          const ok = !!(result && result.ok);
          const tool = String(msg.name).split("/").pop();
          pushActivity("figma_plugin", ok ? "ok" : "error", `${tool} ${ok ? "ok" : "failed"}`, { tool, ms: elapsed, code: result && result.errorCode });
          sendResponse(result || { ok: false, kind: "transport", errorCode: "FIGMA_PLUGIN_NO_RESPONSE", error: "total-core did not answer the Figma plugin tool call" });
          break;
        }
        // Figma Desktop MCP uses its own verified Streamable HTTP session; its
        // `figma_*` calls must never be folded into the Figma Design plugin.
        if (isFigmaToolName(msg.name)) {
          sendResponse(await dispatchFigmaTool(msg.name, msg.arguments, timeout, msg.requestId));
          break;
        }
        // 2.21.0: Blockbench commands go to total-core like any Roblox tool
        // (total-core hands them to the Blockbench plugin). They need the
        // bridge socket but NOT Studio: check the arguments locally first,
        // then skip the Studio gate below.
        const isBb = typeof TotalBlockbench !== "undefined" && TotalBlockbench.isCommand(msg.name);
        if (isBb) {
          const v = TotalBlockbench.validate(msg.name, msg.arguments);
          if (!v.ok) { sendResponse({ ok: false, kind: "validation", errorCode: "INVALID_ARGUMENT", error: v.error }); break; }
          if (engine !== "roblox" && engine !== "anim") {
            sendResponse({ ok: false, kind: "engine", errorCode: "ENGINE_MISMATCH", workerEngine: engine, error: "Blockbench commands travel through the Roblox bridge (total-core, ws 17613); switch the engine to Roblox." });
            break;
          }
          if (!connected) { connect(); await waitForConnection(6000); }
          if (!connected) { sendResponse({ ok: false, kind: "disconnected", errorCode: "STUDIO_BRIDGE_OFFLINE", error: "total-core is not running - start the TotalScript desktop app (it carries the Blockbench link)." }); break; }
          let bbState = bbStatusSnapshot();
          if (!bbState.known || !bbState.connected) {
            await bbRefresh();
            bbState = bbStatusSnapshot();
          }
          if (!bbState.known) {
            sendResponse({ ok: false, kind: "status-unknown", errorCode: "BLOCKBENCH_STATUS_UNKNOWN", error: "Could not verify the Blockbench plugin connection from total-core. Do not assume it is offline or connected; check the desktop app and retry. " + (bbState.error || ""), steps: TotalBlockbench.connectSteps(bbPluginFile) });
            break;
          }
          if (!bbState.connected) { sendResponse({ ok: false, kind: "disconnected", errorCode: "BLOCKBENCH_OFFLINE", error: TotalBlockbench.offlineMessage(bbPluginFile), steps: TotalBlockbench.connectSteps(bbPluginFile) }); break; }
          const bbStarted = performance.now();
          const br = await send({ type: "call_tool", name: v.name, arguments: msg.arguments || {}, timeout: msg.timeout, requestId: msg.requestId }, timeout);
          const bbMs = Math.round(performance.now() - bbStarted);
          // Rust bb_status represents offline as a successful tool result whose
          // text begins with this sentinel. Check it as well as transport errors.
          const statusText = /^\s*ERROR\s+BLOCKBENCH_(?:OFFLINE|STATUS_UNKNOWN|STATUS_MISMATCH)\b/i.test(String((br && br.text) || ""));
          const statusErrorReply = !!(br && (["BLOCKBENCH_OFFLINE", "BLOCKBENCH_STATUS_UNKNOWN", "BLOCKBENCH_STATUS_MISMATCH"].includes(br.errorCode) || /blockbench is not connected/i.test(String(br.error || "")) || statusText));
          const bbReplyOk = !!(br && br.ok && !statusErrorReply);
          const bbFailure = br && (br.error || (statusText ? br.text : "")) || "no response";
          if (bbReplyOk) pushActivity("blockbench", "ok", `${v.name} ok`, { tool: v.name, ms: bbMs }); // tool output stays out of the activity feed (the AI's result carries the export path)
          else pushActivity("blockbench", "error", `${v.name} failed: ${String(bbFailure).slice(0, 120)}`, { tool: v.name, ms: bbMs });
          if (bbReplyOk) {
            if (bbCallMismatch) { bbCallMismatch = ""; broadcastStatus(); }
          } else if (statusErrorReply) {
            // An offline / unknown status result may race the cached heartbeat. Re-read total-core
            // before changing state so neither the error nor an old green flag
            // masks a contradictory live result.
            await bbRefresh();
            const verified = bbStatusSnapshot();
            if (verified.known && !verified.connected) {
              bbCallMismatch = "";
              br.ok = false;
              br.errorCode = "BLOCKBENCH_OFFLINE";
              br.kind = "disconnected";
              br.error = TotalBlockbench.offlineMessage(bbPluginFile);
              br.steps = TotalBlockbench.connectSteps(bbPluginFile);
              delete br.text;
              delete br.images;
            } else if (verified.known && verified.connected) {
              bbCallMismatch = "A Blockbench command was rejected as offline, but a fresh total-core heartbeat reports the plugin connected. Check the plugin version/session before retrying.";
              br.ok = false;
              br.errorCode = "BLOCKBENCH_STATUS_MISMATCH";
              br.kind = "status-mismatch";
              br.error = bbCallMismatch;
              br.steps = TotalBlockbench.connectSteps(bbPluginFile);
              delete br.text;
              delete br.images;
            } else {
              bbCallMismatch = "A Blockbench command was rejected as offline, and total-core could not verify the connection afterward.";
              br.ok = false;
              br.errorCode = "BLOCKBENCH_STATUS_UNKNOWN";
              br.kind = "status-unknown";
              br.error = bbCallMismatch + (verified.error ? " " + verified.error : "");
              br.steps = TotalBlockbench.connectSteps(bbPluginFile);
              delete br.text;
              delete br.images;
            }
            broadcastStatus();
          }
          sendResponse(br || { ok: false, kind: "disconnected", error: "total-core returned no Blockbench result" });
          break;
        }
        // Blender is a separate transport, not a tool family of the selected
        // Studio / AgentScript engine. Route every Blender name here so a stale
        // or offline Blender flag can never send get_scene_info (or a write) to
        // the unrelated default MCP server.
        if (isBlenderToolName(msg.name)) {
          sendResponse(await dispatchBlenderTool(msg.name, msg.arguments, timeout));
          break;
        }
        // 1.81.0: the page states which engine it believes it is on. If the
        // worker's socket is bound to the OTHER engine (storage race, worker
        // restart, stale tab), refuse: a Roblox command must never travel down
        // the AgentScript socket (17615) and touch workspace files, nor the
        // reverse. Legacy callers that send no engine are routed as before.
        if (msg.engine && normalizeEngine(msg.engine) !== engine) {
          log(`call_tool refused: page on ${normalizeEngine(msg.engine)}, worker on ${engine} (${String(msg.name||"")})`);
          sendResponse({ok:false,kind:"engine",errorCode:"ENGINE_MISMATCH",workerEngine:engine,error:`this page is on the ${normalizeEngine(msg.engine)==="local"?"AgentScript":"Roblox"} engine but the extension worker is bound to ${engineLabel()} (ws ${engine==="local"?PORT_LOCAL:PORT_ROBLOX}).`});
          break;
        }
        if (engine === "roblox" || engine === "anim") {
          if (!connected || robloxEditorConnected !== true) await refreshStudioStatus();
          if (!connected || robloxEditorConnected !== true) {
            sendResponse({ok:false,kind:"disconnected",errorCode:"STUDIO_BRIDGE_OFFLINE",error:"Roblox Studio MCP is not reachable. Open Studio, enable its bridge, and retry."});
            break;
          }
        }
        const bareTool=String(msg.name||"").split("/").pop();
        const toolStarted=performance.now();let r = await send({ type:"call_tool",name:msg.name,arguments:msg.arguments,timeout:msg.timeout,requestId:msg.requestId },timeout);
        // A bridge restart can race one read-only command. Retry only safe,
        // idempotent commands once; never replay writes or Luau mutations.
        const bareForRetry=String(msg.name||"").split("/").pop();
        if (r && !r.ok && ["BRIDGE_COMMAND_ERROR","BRIDGE_COMMAND_FAILED","BRIDGE_PROTOCOL_ERROR","MCP_CONNECTION_CLOSED"].includes(r.errorCode) && IDEMPOTENT_STUDIO_TOOLS.has(bareForRetry)) {
          try { if(ws) ws.close(); } catch {} ws=null; connected=false; await waitForConnection(8000);
          const retry=await send({ type:"call_tool",name:msg.name,arguments:msg.arguments,timeout:msg.timeout,requestId:msg.requestId },timeout);
          if (retry) r=retry;
        }
        mcpTrace("tool_invocation",{requestId:r?.requestId||msg.requestId,duration:Math.round(performance.now()-toolStarted),status:r?.ok?"OK":"ERROR",errorCode:r?.mcpErrorCode||r?.errorCode});
        {
          const toolMs = Math.round(performance.now() - toolStarted);
          if (r && r.ok) pushActivity("tool", "ok", `${bareTool} ok`, { tool: msg.name, ms: toolMs });
          else pushActivity("tool", "error", `${bareTool} failed: ${String((r && r.error) || "no answer").slice(0, 160)}`, { tool: msg.name, ms: toolMs, code: (r && (r.errorCode || r.mcpErrorCode)) || (r && r.kind === "timeout" ? "MCP_REQUEST_TIMEOUT" : "MCP_SERVER_UNAVAILABLE") });
        }
        if (r && !r.ok && !r.errorCode) {
          const detail=String(r.error||"");
          r.mcpErrorCode = r.kind === "timeout" ? "MCP_REQUEST_TIMEOUT" : r.kind === "disconnected" ? "MCP_CONNECTION_CLOSED" : "MCP_PROTOCOL_ERROR";
          r.errorCode = r.kind === "timeout" ? "STUDIO_TIMEOUT" :
            r.kind === "disconnected" ? "STUDIO_BRIDGE_OFFLINE" :
            /not found|no instance/i.test(detail)?"SCRIPT_NOT_FOUND":
            /not a script|LuaSourceContainer|Source access|permission|denied/i.test(detail)?"SCRIPT_NOT_READABLE":"BRIDGE_PROTOCOL_ERROR";
        }
        if (bareTool==="script_read" && r && r.ok && String(r.text||"").trim().startsWith("{")) {
          try { const payload=JSON.parse(r.text);if(payload&&payload.success===false||payload&&payload.ok===false){const err=payload.error||{};sendResponse({ok:false,kind:"execution",errorCode:err.code||"BRIDGE_PROTOCOL_ERROR",error:err.message||String(payload.error||"script_read failed"),details:err.details});break;} } catch {}
        }
        if (bareTool==="script_read" && r && r.ok && !String(r.text||"").length) {
          sendResponse({ok:false,kind:"protocol",errorCode:"BRIDGE_PROTOCOL_ERROR",error:"script_read returned no serialized Source payload"});
          break;
        }
        sendResponse(r);
        break;
      }
      case "restart_mcp": {
        try { connect(); } catch {}
        await waitForConnection(12000);
        const r = await send({ type: "restart_mcp" }, 30000);
        if (r && r.ok) {
          const tools = await send({ type: "list_tools" }, 10000);
          if (tools && tools.ok && Array.isArray(tools.tools)) toolsCache = tools.tools;
          mcpAlive = true;
          pushActivity("server", "ok", `${engineLabel()} server restarted (${toolsCache.length} tools)`);
        } else pushActivity("server", "error", `Server restart failed: ${String((r && r.error) || "bridge offline").slice(0, 160)}`, { code: (r && r.errorCode) || "MCP_SERVER_UNAVAILABLE" });
        sendResponse(r);
        break;
      }
      case "local_read": {
        try {
          const text = await localReadAll(String(msg.path || ""));
          sendResponse({ ok: true, text });
        } catch (e) {
          sendResponse({ ok: false, error: String(e && e.message || e) });
        }
        break;
      }
      case "blender_connect": {
        const br = await connectBlender();
        pushActivity("blender", br && br.blender ? "ok" : "warn", br && br.blender ? "Blender addon linked (port 9876)" : `Blender did not answer: ${String((br && br.error) || "addon not running").slice(0, 120)}`);
        sendResponse(br);
        break;
      }
      case "blender_status": {
        sendResponse({ ok: blenderAddon, blender: blenderAddon, error: blenderError || undefined });
        break;
      }
      case "blender_disconnect": {
        setBlender(false, "");
        pushActivity("blender", "info", "Blender addon unlinked");
        broadcastStatus();
        sendResponse({ ok: true, blender: false });
        break;
      }
      case "figma_plugin_status": {
        sendResponse(await refreshFigmaPluginStatus());
        break;
      }
      case "figma_plugin_pair": {
        if (!trustedFigmaSettingsPopup(sender)) {
          sendResponse({ ok: false, error: "Figma pairing codes can only be generated from TotalScript Settings." });
          break;
        }
        const reply = await figmaPluginHttp("pair", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: "{}",
        }, 5000);
        if (!reply || typeof reply.pairing_token !== "string" || reply.ok !== true) {
          sendResponse({ ok: false, error: String((reply && reply.error) || "Could not generate a Figma pairing code. Start the TotalScript desktop app and retry.") });
          break;
        }
        const status = await refreshFigmaPluginStatus();
        // Pairing material is returned only to the trusted popup; it is never
        // persisted in chrome.storage, broadcast, logged, or sent to page scripts.
        sendResponse({ ...status, ok: true, pairing_token: reply.pairing_token, expires_at: reply.expires_at, expires_in: reply.expires_in, single_use: reply.single_use });
        break;
      }
      case "figma_plugin_revoke": {
        if (!trustedFigmaSettingsPopup(sender)) {
          sendResponse({ ok: false, error: "Figma pairing can only be revoked from TotalScript Settings." });
          break;
        }
        const reply = await figmaPluginHttp("revoke", { method: "POST" }, 5000);
        if (!reply || reply.ok !== true) {
          sendResponse({ ok: false, error: String((reply && reply.error) || "Could not revoke the Figma pairing. Start the TotalScript desktop app and retry.") });
          break;
        }
        const status = await refreshFigmaPluginStatus();
        sendResponse({ ...status, ok: true, revoked: true });
        break;
      }
      case "figma_connect": {
        await figmaRefresh(true, 6500);
        sendResponse(figmaStatusPayload());
        break;
      }
      case "figma_status": {
        await figmaManualReady;
        if (msg.refresh === true) await figmaRefresh(true, 6500);
        sendResponse(figmaStatusPayload());
        break;
      }
      case "figma_disconnect": {
        sendResponse(await figmaDisconnect());
        break;
      }
      case "figma_cancel": {
        const cancelled = !!(figmaClient && figmaClient.cancel(msg.requestId));
        sendResponse({ ok: true, cancelled });
        break;
      }
      case "blockbench_status": {
        // 2.21.0: there is nothing to connect from here - the plugin dials
        // total-core. refresh:true re-reads total-core right now ("Check again").
        if (msg.refresh !== false) await bbRefresh();
        sendResponse(bbStatusPayload());
        break;
      }
      case "add_server": {
        // Native bin/total-core.exe rejects generic custom MCP. Dedicated
        // providers are routed to their own verified transports.
        if (String(msg.server_id || "").toLowerCase() === "figma") {
          await figmaRefresh(true, 6500);
          sendResponse(figmaStatusPayload());
          break;
        }
        if (String(msg.server_id || "").toLowerCase() === "blender") {
          sendResponse(await connectBlender());
          break;
        }
        if (String(msg.server_id || "").toLowerCase() === "blockbench") {
          await bbRefresh();
          sendResponse(bbStatusPayload());
          break;
        }
        const r = await send({
          type: "add_server", server_id: msg.server_id,
          command: msg.command, args: msg.args, env: msg.env,
        }, 15000);
        pushActivity("server", r && r.ok ? "ok" : "error", r && r.ok ? `MCP server added: ${String(msg.server_id || "")}` : `Adding MCP server ${String(msg.server_id || "")} failed: ${String((r && r.error) || "no answer").slice(0, 120)}`);
        sendResponse(r);
        break;
      }
      case "remove_server": {
        if (String(msg.server_id || "").toLowerCase() === "figma") {
          sendResponse(await figmaDisconnect());
          break;
        }
        const r = await send({ type: "remove_server", server_id: msg.server_id }, 15000);
        pushActivity("server", r && r.ok ? "info" : "error", r && r.ok ? `MCP server removed: ${String(msg.server_id || "")}` : `Removing MCP server ${String(msg.server_id || "")} failed`);
        sendResponse(r);
        break;
      }
      case "reconnect":
        reconnectDelay = RECONNECT_MIN;
        if (!connected) pushActivity("conn", "info", "Reconnect requested");
        connect();
        sendResponse({ ok: true });
        break;
      case "activity_log": {
        const ring = await activityLoad();
        sendResponse({ ok: true, items: ring.slice(-ACTIVITY_MAX), max: ACTIVITY_MAX });
        break;
      }
      case "activity_clear": {
        await clearActivity();
        sendResponse({ ok: true });
        break;
      }
      // 2.21.0: a content-script note for the Activity Center (creation report
      // summary). Kind + level are whitelisted, text is a short derived summary
      // (counts and domain names - never the request or the reply).
      case "activity_note": {
        const kind = /^(creation|tool|server)$/.test(String(msg.kind || "")) ? String(msg.kind) : "creation";
        const level = /^(ok|info|warn|error)$/.test(String(msg.level || "")) ? String(msg.level) : "info";
        const text = String(msg.text || "").replace(/[\r\n]+/g, " ").slice(0, 200);
        if (text) pushActivity(kind, level, text, { code: msg.code != null ? String(msg.code).slice(0, 60) : undefined });
        sendResponse({ ok: !!text });
        break;
      }
      // ── ZeroScript Rust pipe — CORS bypass via background (content script → background → 127.0.0.1) ──
      case "rs-push":
      case "push_payload": {
        // Content script payload from AI chat (Gemini/ChatGPT/Claude) → local bridge
        // Must go through background to bypass chat site CORS on http://127.0.0.1
        try {
          const target = RUST_ROBLOX_HTTP;
          const res = await fetch(`${target}/api/push`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(msg.payload || msg),
          });
          const j = await res.json().catch(() => ({}));
          sendResponse({ ok: res.ok, ...j });
        } catch (e) {
          // Fallback to legacy WS if Rust HTTP not reachable
          const r = await send({ type: "call_tool", name: msg.name || "push_payload", arguments: msg.arguments || msg.payload || {} }, 10000);
          sendResponse(r);
        }
        break;
      }
      case "rs-poll": {
        try {
          const target = RUST_ROBLOX_HTTP;
          const res = await fetch(`${target}/api/poll?client_id=${encodeURIComponent(msg.client_id || engine)}`);
          const j = await res.json().catch(() => ({}));
          sendResponse(j);
        } catch (e) {
          sendResponse({ ok: false, error: String(e && e.message || e) });
        }
        break;
      }
      case "api_request":
      case "web_api": {
        try {
          let url = String(msg.url || "").trim();
          if (!url || !/^https?:\/\//i.test(url)) {
            sendResponse({ ok: false, error: "url must start with http:// or https://" });
            break;
          }
          { const why = privateNetworkReason(url); if (why) { sendResponse({ ok: false, error: "api_request refused: " + why + " (" + url + ")" }); break; } }
          const method = String(msg.method || "GET").toUpperCase();
          const maxChars = Math.max(500, Math.min(100000, Number(msg.max_chars) || 16000));
          let headers = {};
          if (typeof msg.headers === "object" && msg.headers !== null) {
            headers = { ...msg.headers };
          } else if (typeof msg.headers === "string" && msg.headers.trim()) {
            try { headers = JSON.parse(msg.headers); } catch {}
          }
          if (!headers["Content-Type"] && (method === "POST" || method === "PUT" || method === "PATCH")) {
            headers["Content-Type"] = "application/json";
          }
          if (!headers["Accept"]) {
            headers["Accept"] = "application/json, text/plain, */*";
          }
          let body = msg.body;
          if (body !== undefined && body !== null && typeof body === "object") {
            body = JSON.stringify(body);
          } else if (typeof body === "string" && body.trim()) {
            body = body.trim();
          } else {
            body = undefined;
          }

          const options = { method, headers, redirect: "follow" };
          if (body !== undefined && method !== "GET" && method !== "HEAD") {
            options.body = body;
          }

          const res = await fetch(url, options);
          const status = res.status;
          const statusText = res.statusText;
          const resCtype = (res.headers.get("content-type") || "").toLowerCase();
          let rawText = await res.text();
          let parsedData = null;
          let isJson = false;

          if (resCtype.includes("json") || /^\s*[\{\[]/.test(rawText)) {
            try {
              parsedData = JSON.parse(rawText);
              isJson = true;
            } catch {}
          }

          const origLen = rawText.length;
          const truncated = origLen > maxChars;
          const text = truncated ? rawText.slice(0, maxChars) + `\n…[truncated ${origLen - maxChars} chars]` : rawText;

          sendResponse({
            ok: res.ok,
            status,
            statusText,
            url,
            method,
            isJson,
            data: parsedData,
            text,
            truncated
          });
        } catch (e) {
          sendResponse({ ok: false, error: "Web API request failed: " + String(e && e.message || e) });
        }
        break;
      }
      case "web_fetch": {
        try {
          let url = String(msg.url || "").trim();
          const query = String(msg.query || "").trim();
          if (!url) {
            const q = String(msg.q || query).trim();
            if (/^https?:\/\//i.test(q)) url = q;
          }
          let searchNote = "";
          if (!url) {
            const q = query || String(msg.q || "").trim();
            if (!q) { sendResponse({ ok: false, error: "url or query is required" }); break; }
            const hits = await ddgSearch(q, 3);
            if (!hits.length) { sendResponse({ ok: false, error: "no search results for: " + q }); break; }
            url = hits[0].url;
            searchNote = "Searched \"" + q + "\". Top result: " + url + "\n" +
              hits.map((h, i) => (i+1) + ". " + h.title + " — " + h.url).join("\n") + "\n\n";
          }
          if (!/^https?:\/\//i.test(url)) { sendResponse({ ok: false, error: "url must start with http:// or https://" }); break; }
          { const why = privateNetworkReason(url); if (why) { sendResponse({ ok: false, error: "web_fetch refused: " + why + " (" + url + ")" }); break; } }
          const maxChars = Math.max(500, Math.min(50000, Number(msg.max_chars) || 12000));
          const fetchHeaders = { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36", "Accept": "text/html,application/xhtml+xml,application/xml,application/json,text/plain,*/*", "Accept-Language": "en-US,en;q=0.9" };
          let res = await fetch(url, { headers: fetchHeaders, redirect: "follow" });
          if (!res.ok) {
            try { res = await fetch(url, { redirect: "follow" }); } catch {}
          }
          if (!res || !res.ok) { sendResponse({ ok: false, error: "fetch failed HTTP " + ((res && res.status) || "?") + " for " + url }); break; }
          let text = await res.text();
          const ctype = (res.headers.get("content-type") || "").toLowerCase();
          const looksHtml = /html|xml/.test(ctype) || /^\s*</.test(text);
          if (looksHtml) text = htmlToText(text);
          const origLen = text.length;
          const truncated = origLen > maxChars;
          if (truncated) text = text.slice(0, maxChars) + `\n\n…[truncated ${origLen - maxChars} chars]`;
          sendResponse({ ok: true, text: searchNote + text, page_text: text, truncated, status: res.status, url, content_type: ctype });
        } catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      // ── Image Studio provider profiles ──
      // image_api_status / image_api_config / image_api use independent saved
      // provider credentials. The worker returns masked metadata only; raw keys
      // remain in extension storage and are sent only to that provider's API.
      // image_fetch: bytes of a picture URL (what a chat site drew), read with
      // the extension's host permissions so page CORS cannot block it.
      case "image_api_status": {
        try { sendResponse(imageApiPublicStatus(await readImageApiConfig())); }
        catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "image_api_config": {
        try {
          const current = await readImageApiConfig();
          const updated = updateImageApiConfig(current, msg);
          if (!updated.ok) { sendResponse(updated); break; }
          await chrome.storage.local.set({ rs_image_api: updated.config });
          sendResponse(imageApiPublicStatus(updated.config));
        } catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "image_api": {
        sendResponse(await imageApiGenerate(msg));
        break;
      }
      case "image_fetch": {
        try {
          const url = String(msg.url || "").trim();
          if (!/^https?:\/\//i.test(url)) { sendResponse({ ok: false, error: "url must start with http:// or https://" }); break; }
          { const why = privateNetworkReason(url); if (why) { sendResponse({ ok: false, error: "image_fetch refused: " + why }); break; } }
          const res = await fetch(url, { redirect: "follow" });
          if (!res.ok) { sendResponse({ ok: false, error: "HTTP " + res.status + " for the picture url" }); break; }
          const mime = (res.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
          const buf = new Uint8Array(await res.arrayBuffer());
          if (buf.length > 20 * 1024 * 1024) { sendResponse({ ok: false, error: "picture larger than 20 MB" }); break; }
          if (!/^image\//.test(mime) && !(buf[0] === 0x89 && buf[1] === 0x50) && !(buf[0] === 0xff && buf[1] === 0xd8) && !(buf[0] === 0x52 && buf[1] === 0x49)) { sendResponse({ ok: false, error: "the url did not return an image (" + (mime || "no content-type") + ")" }); break; }
          let bin = ""; const CH = 0x8000;
          for (let i = 0; i < buf.length; i += CH) bin += String.fromCharCode.apply(null, buf.subarray(i, i + CH));
          sendResponse({ ok: true, b64: btoa(bin), mime: /^image\//.test(mime) ? mime : (buf[0] === 0x89 ? "image/png" : buf[0] === 0xff ? "image/jpeg" : "image/webp"), bytes: buf.length });
        } catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "web_search": {
        try {
          const q = String(msg.query || msg.q || "").trim();
          if (!q) { sendResponse({ ok: false, error: "query is required" }); break; }
          const limit = Math.max(1, Math.min(8, Number(msg.limit) || 5));
          const results = await ddgSearch(q, limit);
          if (!results.length) {
            sendResponse({ ok: false, error: "no results for '" + q + "'. Try web_fetch with a full https URL." });
            break;
          }
          const txt = results.map((r, i) => (i + 1) + ". " + r.title + "\n   " + r.url + (r.snippet ? "\n   " + r.snippet : "")).join("\n\n");
          sendResponse({ ok: true, text: "Search results for \"" + q + "\":\n\n" + txt, results: results, query: q });
        } catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "resolve_universe": {
        try { sendResponse(await robloxResolveUniverse(msg)); }
        catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "create_dev_product": {
        try { sendResponse(await robloxCreateDevProduct(msg)); }
        catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "list_dev_products": {
        try { sendResponse(await robloxListDevProducts(msg)); }
        catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "update_dev_product": {
        try { sendResponse(await robloxUpdateDevProduct(msg)); }
        catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "publish_animation": {
        try { sendResponse(await robloxPublishAnimation(msg)); }
        catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "create_game_pass": {
        try { sendResponse(await robloxCreateGamePass(msg)); }
        catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "update_game_pass": {
        try { sendResponse(await robloxUpdateGamePass(msg)); }
        catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "list_game_passes": {
        try { sendResponse(await robloxListGamePasses(msg)); }
        catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "screenshot_capture":
      case "capture_tab": {
        try {
          const C = (typeof chrome !== "undefined" && chrome.runtime) ? chrome : (typeof browser !== "undefined" ? browser : null);
          if (!C || !C.tabs || !C.tabs.captureVisibleTab) {
            sendResponse({ ok: false, error: "this browser cannot capture tabs" });
            break;
          }
          const qtabs = (query) => new Promise((resolve) => {
            try {
              const ret = C.tabs.query(query, (tabs) => resolve(tabs || []));
              if (ret && typeof ret.then === "function") ret.then((tabs) => resolve(tabs || [])).catch(() => resolve([]));
            } catch { resolve([]); }
          });
          const snap = (wid, opts) => new Promise((resolve, reject) => {
            let settled = false;
            const done = (url) => {
              if (settled) return;
              const err = C.runtime && C.runtime.lastError && C.runtime.lastError.message;
              if (err) { settled = true; reject(new Error(err)); return; }
              if (!url) { settled = true; reject(new Error("empty capture")); return; }
              settled = true; resolve(url);
            };
            try {
              let ret;
              if (wid != null) ret = C.tabs.captureVisibleTab(wid, opts, done);
              else ret = C.tabs.captureVisibleTab(opts, done);
              if (ret && typeof ret.then === "function") ret.then((url) => done(url)).catch((e) => { if (!settled) { settled = true; reject(e); } });
            } catch (e) { reject(e); }
          });
          const tabId = sender && sender.tab && sender.tab.id;
          let windowId = (sender && sender.tab && sender.tab.windowId);
          if (windowId == null) {
            for (const query of [{ active: true, lastFocusedWindow: true }, { active: true, currentWindow: true }, { highlighted: true, lastFocusedWindow: true }]) {
              const tabs = await qtabs(query);
              if (tabs[0] && tabs[0].windowId != null) { windowId = tabs[0].windowId; break; }
            }
          }
          if (tabId && C.tabs.update) {
            await new Promise((resolve) => {
              try {
                const ret = C.tabs.update(tabId, { active: true }, () => resolve());
                if (ret && typeof ret.then === "function") ret.then(() => resolve()).catch(() => resolve());
              } catch { resolve(); }
            });
          }
          if (windowId != null && C.windows && C.windows.update) {
            await new Promise((resolve) => {
              try {
                const ret = C.windows.update(windowId, { focused: true }, () => resolve());
                if (ret && typeof ret.then === "function") ret.then(() => resolve()).catch(() => resolve());
              } catch { resolve(); }
            });
          }
          await new Promise((r) => setTimeout(r, 500));
          // The first capture after a focus change can come back empty on some
          // Chromium builds; retry with short pauses until we get a real frame.
          let dataUrl = "";
          let lastErr = "";
          const attempts = [
            [windowId, { format: "jpeg", quality: 85 }],
            [windowId, { format: "jpeg", quality: 85 }],
            [windowId, { format: "png" }],
            [undefined, { format: "jpeg", quality: 85 }],
            [undefined, { format: "png" }],
          ];
          for (let ai = 0; ai < attempts.length && !dataUrl; ai++) {
            const pair = attempts[ai];
            try {
              const shot = await snap(pair[0], pair[1]);
              // <150 base64 chars is an empty/blank frame, not a screenshot.
              if (shot && shot.length > 150) dataUrl = shot;
            } catch (e) { lastErr = String(e && e.message || e); }
            if (!dataUrl) await new Promise((r) => setTimeout(r, 260));
          }
          if (!dataUrl) throw new Error(lastErr || "captureVisibleTab returned an empty image");
          const m = String(dataUrl).match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
          if (!m) throw new Error("capture was not a data URL");
          let mime = m[1], data = m[2];
          try {
            if (typeof OffscreenCanvas !== "undefined" && typeof createImageBitmap === "function") {
              const raw = Uint8Array.from(atob(m[2]), (c) => c.charCodeAt(0));
              const bmp = await createImageBitmap(new Blob([raw], { type: m[1] }));
              const maxW = 1600;
              const scale = Math.min(1, maxW / Math.max(1, bmp.width));
              const w = Math.max(1, Math.round(bmp.width * scale));
              const h = Math.max(1, Math.round(bmp.height * scale));
              const canvas = new OffscreenCanvas(w, h);
              canvas.getContext("2d").drawImage(bmp, 0, 0, w, h);
              const out = await canvas.convertToBlob({ type: "image/jpeg", quality: 0.8 });
              const buf = new Uint8Array(await out.arrayBuffer());
              let bin = "";
              for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
              mime = "image/jpeg";
              data = btoa(bin);
            }
          } catch {}
          sendResponse({ ok: true, images: [{ mimeType: mime, data: data }] });
        } catch (e) {
          sendResponse({ ok: false, error: String(e && e.message || e) });
        }
        break;
      }
      default:
        sendResponse({ ok: false, kind:"unknown-message", error: `unknown message type: ${msg.type}` });
    }
  })().catch((e) => {
    const error=String(e&&e.message||e||"unknown background failure");
    log("message handler failed", msg&&msg.type, error);
    try { sendResponse({ok:false,kind:"background-error",error:`${msg&&msg.type||"unknown"}: ${error}`}); } catch {}
  });
  return true; // async sendResponse
});

// Proc and Blockbench status polls. Blockbench's dedicated HTTP heartbeat is
// the sole liveness authority; keep UI snapshots fresh and turn failed probes
// into UNKNOWN rather than leaving an old green flag visible.
refreshProcStatus();
setInterval(refreshProcStatus, 5000);
void bbRefresh();
setInterval(() => { void bbRefresh(); }, 5000);
setInterval(() => { if (figmaStatusSnapshot().connected) void figmaRefresh(true, 6500); }, 8000);

// Wake/keepalive hooks.
chrome.runtime.onStartup.addListener(connect);
try {
  chrome.alarms.create("total-keep", { periodInMinutes: 1 });
  chrome.alarms.onAlarm.addListener((a) => {
    if (a && a.name === "total-keep") { try { connect(); } catch {} }
  });
} catch {}
// 1.75.0 — hello page, exactly once: on a fresh install (reason "install" -
// not on updates or browser updates) and only if the rsHelloShown flag is not
// set yet. The flag is written BEFORE the tab opens so a reload / second
// onInstalled can never show it twice.
const HELLO_PAGE = "welcome.html";
async function maybeShowHello(details) {
  try {
    if (!details || details.reason !== "install") return false;
    const got = await chrome.storage.local.get("rsHelloShown");
    if (got && got.rsHelloShown) return false;
    await chrome.storage.local.set({ rsHelloShown: Date.now() });
    await chrome.tabs.create({ url: chrome.runtime.getURL(HELLO_PAGE) });
    return true;
  } catch (e) { return false; }
}
chrome.runtime.onInstalled.addListener((details) => { connect(); maybeShowHello(details); });
// After a reload with new files (manual update), one Activity line says so.
chrome.runtime.onInstalled.addListener((details) => {
  try {
    if (!details || details.reason !== "update") return;
    const cur = chrome.runtime.getManifest().version;
    const from = details.previousVersion || "";
    if (from && from !== cur) pushActivity("update", "ok", `TotalScript updated to ${cur} (from ${from}).`, { code: cur });
  } catch {}
});

connect();
