﻿// SPDX-License-Identifier: GPL-3.0-or-later
// src/core/animlib.js - RobloxScript animation tools (virtual commands).
//
// HOW IT WORKS: Roblox Studio's MCP server (StudioMCP) only advertises its own
// fixed tool list - we cannot add tools to it. But execute_luau can run
// ARBITRARY Lua in Studio, and Roblox's animation data model (KeyframeSequence
// -> Keyframe -> Pose tree, pose.CFrame per bone) is fully creatable and
// editable from an ordinary script. So every animation_* command is resolved
// HERE (in the extension) into a small execute_luau call that drives a shared
// Luau library kept in ServerStorage.RobloxScript.AnimLib. Animation state
// (rig + keyframe data) lives on Studio instances, so it survives across calls
// for the whole place session.
//
// All commands return a JSON string from Luau: {"ok":true,"data":...} or
// {"ok":false,"error":...}. Nothing is ever faked - unsupported operations
// fail loudly.

// The Luau library, embedded verbatim into every animation_* execute_luau call
// (the same self-contained source, so a stale copy in ServerStorage can never
// diverge). __ARGS_JSON__ is replaced by the specific call's arguments.
const ANIM_LIB_LUA = `local HttpService = game:GetService("HttpService")
local ServerStorage = game:GetService("ServerStorage")
local TweenService = game:GetService("TweenService")

local function jenc(x) return HttpService:JSONEncode(x) end
local function jdec(s) return HttpService:JSONDecode(s) end
local function fail(msg) return jenc({ ok = false, error = msg }) end
local function okdata(d, text) return jenc({ ok = true, data = d, text = text or "" }) end

-- AnimScript owns a distinct folder. Migrate a previous RobloxScript library in
-- place so existing animations and memory are retained rather than copied.
local RSROOT = ServerStorage:FindFirstChild("RobloxScript") or ServerStorage:FindFirstChild("AnimScript")
if not RSROOT then
	local legacy = ServerStorage:FindFirstChild("RobloxScript")
	if legacy then
		legacy.Name = "AnimScript"
		RSROOT = legacy
	else
		RSROOT = Instance.new("Folder"); RSROOT.Name = "RobloxScript"; RSROOT.Parent = ServerStorage
	end
end
local LIB = RSROOT:FindFirstChild("AnimLib")
if not LIB then LIB = Instance.new("Folder"); LIB.Name = "AnimLib"; LIB.Parent = RSROOT end
local ACTIVE = LIB:FindFirstChild("Active")
if not ACTIVE then ACTIVE = Instance.new("StringValue"); ACTIVE.Name = "Active"; ACTIVE.Parent = LIB end
local RIGREF = LIB:FindFirstChild("Rig")
if not RIGREF then RIGREF = Instance.new("StringValue"); RIGREF.Name = "Rig"; RIGREF.Parent = LIB end
local LENGTH = LIB:FindFirstChild("Length")
if not LENGTH then LENGTH = Instance.new("NumberValue"); LENGTH.Name = "Length"; LENGTH.Parent = LIB; LENGTH.Value = 1 end
-- Preview state has to outlive a single execute_luau call. A local flag is
-- recreated for every command, which made stop_preview unable to stop a run.
local PREVIEW_TOKEN = LIB:FindFirstChild("PreviewToken")
if not PREVIEW_TOKEN then PREVIEW_TOKEN = Instance.new("IntValue"); PREVIEW_TOKEN.Name = "PreviewToken"; PREVIEW_TOKEN.Parent = LIB end
local PREVIEW_RIG = LIB:FindFirstChild("PreviewRig")
if not PREVIEW_RIG then PREVIEW_RIG = Instance.new("StringValue"); PREVIEW_RIG.Name = "PreviewRig"; PREVIEW_RIG.Parent = LIB end
-- An intentional rig choice guides NEW animations. Pinned animations retain
-- their own rig, and automatic discovery is still fresh when this is empty.
local SELECTED_RIG = LIB:FindFirstChild("SelectedRig")
if not SELECTED_RIG then SELECTED_RIG = Instance.new("StringValue"); SELECTED_RIG.Name = "SelectedRig"; SELECTED_RIG.Parent = LIB end

local function resolvePath(p)
	if p == nil or p == "" then return nil end
	local node = game
	for _, s in ipairs(string.split(p, ".")) do
		node = node:FindFirstChild(s)
		if not node then return nil end
	end
	return node
end

local function pathOf(inst)
	local parts = {}
	local cur = inst
	while cur and cur ~= game do
		parts[#parts + 1] = cur.Name
		cur = cur.Parent
	end
	local rev = {}
	for i = 1, #parts do rev[i] = parts[#parts - i + 1] end
	return table.concat(rev, ".")
end

-- Rig discovery: ALWAYS scan the workspace fresh. No caching - a cached rig
-- path stored in ServerStorage survives across Studio sessions and can keep
-- pointing at an old R6 dummy forever, which is exactly how a stale "7-bone
-- rig" kept winning. The rig with the most joint-connected bones wins.
local function findRig()
	local selected = resolvePath(SELECTED_RIG.Value)
	if selected and selected:IsA("Model") and selected:FindFirstChildOfClass("Humanoid") and
		(selected:FindFirstChild("HumanoidRootPart") or selected.PrimaryPart or selected:FindFirstChild("Torso") or selected:FindFirstChild("UpperTorso")) then
		return selected
	end
	local best = nil
	local bestScore = -1
	for _, m in ipairs(workspace:GetDescendants()) do
		if m:IsA("Model") then
			local h = m:FindFirstChildOfClass("Humanoid")
			local root = m:FindFirstChild("HumanoidRootPart") or m.PrimaryPart
			if h and root and #m:GetDescendants() > 10 then
				local score = 0
				for _, d in ipairs(m:GetDescendants()) do
					if d:IsA("Motor6D") or d:IsA("AnimationConstraint") or d:IsA("BallSocketConstraint") then score = score + 1 end
				end
				if score > bestScore then bestScore = score; best = m end
			end
		end
	end
	return best
end

-- The rig an animation is PINNED to (stored as a path attribute on the
-- KeyframeSequence). When multiple rigs exist in the workspace - e.g. an R6
-- blocky dummy next to the real R15 Avatar-Joint-Upgrade character - the
-- pinned rig guarantees keyframes, preview and apply all drive the SAME rig
-- the animation was built on.
local function pinOf(anim)
	local p = anim and anim:GetAttribute("RS_RigPath")
	if typeof(p) ~= "string" or p == "" then return nil end
	local rig = resolvePath(p)
	if rig and rig:IsA("Model") and rig:FindFirstChildOfClass("Humanoid") then return rig end
	return nil
end

local function activeRig(anim)
	local pinned = pinOf(anim)
	if pinned then return pinned end
	return findRig()
end

local function rigRoot(rig)
	for _, p in ipairs(rig:GetDescendants()) do
		if p.Name == "HumanoidRootPart" and p:IsA("BasePart") then return p end
	end
	return rig.PrimaryPart or rig:FindFirstChild("Torso") or rig:FindFirstChild("UpperTorso")
end

-- All constraint-based joints that replace Motor6D: AnimationConstraint
-- (drives animation transforms) and BallSocketConstraint (rotational joint)
-- are used in Avatar Joint Upgrade rigs. Both expose Attachment0/Attachment1;
-- the bone parts are the ATTACHMENT PARENTS (Part0/Part1 aliases only exist
-- on AnimationConstraint).
local function collectConstraints(rig)
	local out = {}
	for _, d in ipairs(rig:GetDescendants()) do
		if (d:IsA("AnimationConstraint") or d:IsA("BallSocketConstraint")) and d.Attachment0 and d.Attachment1 then
			local a, b = d.Attachment0.Parent, d.Attachment1.Parent
			if a and b and a:IsA("BasePart") and b:IsA("BasePart") then
				out[#out + 1] = { a = a, b = b, path = pathOf(d), kind = d:IsA("AnimationConstraint") and "AnimationConstraint" or "BallSocketConstraint", j = d }
			end
		end
	end
	return out
end

-- Bones: every joint-connected part reachable from the root. Supports
-- Motor6D rigs (classic R6/R15) and constraint rigs (Avatar Joint Upgrade -
-- the default for new places since 2026). A joint's "bone" is its child
-- (Part1/B) part, e.g. LeftUpperArm. Each entry carries the joint offset
-- frames (C0/C1; for constraints the Attachment0/Attachment1 CFrames) so the
-- chain can be re-evaluated PURELY MATHEMATICALLY - constraint joints are
-- NOT evaluated by the Edit-mode viewport, so they must be posed by writing
-- the child part's CFrame directly:
--  childWorld = parentWorld * c0 * pose * c1:Inverse().
local function buildBones(rig, root)
	local joints = {}
	local visited = { [root] = true }
	local constraints = collectConstraints(rig)
	local function walk(part, parentIdx)
		for _, joint in ipairs(part:GetJoints()) do
			if joint:IsA("Motor6D") then
				local other = joint.Part0 == part and joint.Part1 or (joint.Part1 == part and joint.Part0)
				if other and not visited[other] then
					visited[other] = true
					joints[#joints + 1] = {
						index = #joints + 1, parentIdx = parentIdx, name = other.Name, part1 = other,
						jointPath = pathOf(joint), kind = "Motor6D", c0 = joint.C0, c1 = joint.C1, joint = joint,
					}
					walk(other, #joints)
				end
			end
		end
		for _, c in ipairs(constraints) do
			if c.a == part and not visited[c.b] then
				visited[c.b] = true
				joints[#joints + 1] = {
					index = #joints + 1, parentIdx = parentIdx, name = c.b.Name, part1 = c.b,
					jointPath = c.path, kind = c.kind, c0 = c.j.Attachment0.CFrame, c1 = c.j.Attachment1.CFrame, joint = c.j,
				}
				walk(c.b, #joints)
			end
		end
	end
	walk(root, 0)
	return joints
end

-- Build/merge the pose tree of a keyframe from the rig's bones. Existing
-- poses whose bone still exists are KEPT (CFrame values untouched - imported
-- animation data is never lost); poses that are not on the rig are removed;
-- missing bones are added as identity poses. Returns (rootPose, createdCount).
local function buildPoseTree(pkf, rig, root)
	local existing = {}
	local function collect(p)
		existing[p.Name] = p
		for _, sub in ipairs(p:GetSubPoses()) do collect(sub) end
	end
	for _, p in ipairs(pkf:GetPoses()) do collect(p) end
	local bones = buildBones(rig, root)
	local created = 0
	local function ensure(name)
		local p = existing[name]
		if p then existing[name] = nil; return p end
		created = created + 1
		p = Instance.new("Pose")
		p.Name = name
		return p
	end
	local rootPose = ensure(root.Name)
	local poseByIndex = { [0] = rootPose }
	for _, b in ipairs(bones) do
		local p = ensure(b.name)
		poseByIndex[b.index] = p
		if not p.Parent and poseByIndex[b.parentIdx] then poseByIndex[b.parentIdx]:AddSubPose(p) end
	end
	for _, leftover in pairs(existing) do leftover:Destroy() end
	if not rootPose.Parent then pkf:AddPose(rootPose) end
	return rootPose, created
end

local function getAnims()
	return LIB:GetChildren()
end

local function findAnim(name)
	for _, child in ipairs(getAnims()) do
		if child:IsA("KeyframeSequence") and child.Name == name then return child end
	end
	return nil
end

local function activeAnim()
	if ACTIVE.Value == "" then return nil end
	return findAnim(ACTIVE.Value)
end

local function sortedKeyframes(anim)
	local list = {}
	for _, kf in ipairs(anim:GetKeyframes()) do
		list[#list + 1] = kf
	end
	table.sort(list, function(a, b) return a.Time < b.Time end)
	return list
end

local function findKeyframe(anim, t)
	local best = nil
	for _, kf in ipairs(anim:GetKeyframes()) do
		if math.abs(kf.Time - t) < 0.01 then best = kf end
	end
	return best
end

local function findPose(pkf, boneName)
	local found = nil
	local function scan(p)
		if p.Name == boneName then found = p; return end
		for _, sub in ipairs(p:GetSubPoses()) do scan(sub) end
	end
	for _, p in ipairs(pkf:GetPoses()) do scan(p) end
	return found
end

local function newKeyframe(anim, t)
	local kf = Instance.new("Keyframe")
	kf.Time = t
	kf.Parent = anim
	return kf
end

local function poseToTable(pose)
	local sx, sy, sz = pose.CFrame:ToEulerAnglesYXZ()
	local p = pose.CFrame.Position
	return {
		pos = { math.round(p.X * 100) / 100, math.round(p.Y * 100) / 100, math.round(p.Z * 100) / 100 },
		rot = { math.round(math.deg(sx) * 100) / 100, math.round(math.deg(sy) * 100) / 100, math.round(math.deg(sz) * 100) / 100 },
		easingStyle = pose.EasingStyle.Name,
		easingDirection = pose.EasingDirection.Name,
	}
end

local function inspectAnim(anim)
	local kfs = sortedKeyframes(anim)
	local bones = {}
	if #kfs > 0 then
		for _, p in ipairs(kfs[1]:GetPoses()) do
			local function collect(p)
				bones[#bones + 1] = p.Name
				for _, sub in ipairs(p:GetSubPoses()) do collect(sub) end
			end
			collect(p)
		end
		table.sort(bones)
	end
	local out = {}
	local shown = math.min(#kfs, 40)
	for i = 1, shown do
		local kf = kfs[i]
		local bonesOut = {}
		local markersOut = {}
		local function collect(p)
			bonesOut[p.Name] = poseToTable(p)
			for _, sub in ipairs(p:GetSubPoses()) do collect(sub) end
		end
		for _, p in ipairs(kf:GetPoses()) do collect(p) end
		for _, marker in ipairs(kf:GetMarkers()) do markersOut[#markersOut + 1] = { name = marker.Name, value = marker.Value } end
		out[#out + 1] = { t = math.round(kf.Time * 1000) / 1000, bones = bonesOut, markers = markersOut }
	end
	return {
		name = anim.Name,
		duration = math.max(LENGTH.Value, kfs[#kfs] and kfs[#kfs].Time or 0),
		loop = anim.Loop,
		priority = anim.Priority.Name,
		bones = bones,
		keyframeCount = #kfs,
		keyframes = out,
		truncated = #kfs > shown,
		rig = pinOf(anim) and pinOf(anim).Name or "auto",
	}
end

-- Pose easing applies from this keyframe toward the next. Pose easing names
-- are reversed relative to TweenService direction names, so map explicitly.
local function easedAlpha(pose, alpha)
	if not pose or pose.EasingStyle == Enum.PoseEasingStyle.Linear then return alpha end
	if pose.EasingStyle == Enum.PoseEasingStyle.Constant then return alpha >= 0.999999 and 1 or 0 end
	local styleMap = {
		[Enum.PoseEasingStyle.Elastic] = Enum.EasingStyle.Elastic,
		[Enum.PoseEasingStyle.Cubic] = Enum.EasingStyle.Cubic,
		[Enum.PoseEasingStyle.CubicV2] = Enum.EasingStyle.Cubic,
		[Enum.PoseEasingStyle.Bounce] = Enum.EasingStyle.Bounce,
	}
	local directionMap = {
		[Enum.PoseEasingDirection.In] = Enum.EasingDirection.Out,
		[Enum.PoseEasingDirection.Out] = Enum.EasingDirection.In,
		[Enum.PoseEasingDirection.InOut] = Enum.EasingDirection.InOut,
	}
	local style, direction = styleMap[pose.EasingStyle], directionMap[pose.EasingDirection]
	if not style or not direction then return alpha end
	local ok, value = pcall(TweenService.GetValue, TweenService, alpha, style, direction)
	return ok and value or alpha
end

-- Sample the active animation's local pose CFrame for one bone at time t.
local function samplePoseLocal(anim, t, boneName)
	local kfs = sortedKeyframes(anim)
	if #kfs == 0 then return CFrame.new() end
	local before, after = kfs[1], kfs[#kfs]
	local alpha = 0
	if t < kfs[1].Time - 0.001 then
		before, after = kfs[1], kfs[1]
	elseif t > kfs[#kfs].Time + 0.001 then
		before, after = kfs[#kfs], kfs[#kfs]
	else
		for i = 1, #kfs - 1 do
			if t >= kfs[i].Time - 0.001 and t <= kfs[i + 1].Time + 0.001 then
				before, after = kfs[i], kfs[i + 1]
				local span = after.Time - before.Time
				alpha = span > 0 and (t - before.Time) / span or 0
				break
			end
		end
	end
	local pA = findPose(before, boneName)
	local pB = findPose(after, boneName)
	local cA = pA and pA.CFrame or CFrame.new()
	local cB = pB and pB.CFrame or CFrame.new()
	return cA:Lerp(cB, easedAlpha(pA, alpha))
end

-- Re-evaluate the whole joint chain from the root to WORLD CFrames for every
-- bone at time t, purely mathematically (no reliance on the engine evaluating
-- joint transforms - AnimationConstraint joints do NOT evaluate in Studio's
-- Edit viewport). childWorld = parentWorld * c0 * poseLocal * c1:Inverse().
local function computeWorldPoses(rig, root, anim, t)
	local rootCF = root.CFrame
	local bones = buildBones(rig, root)
	local map = {}
	for _, b in ipairs(bones) do
		local pose = anim and samplePoseLocal(anim, t, b.name) or CFrame.new()
		local parentWorld = (b.parentIdx == 0) and rootCF or map[b.parentIdx]
		map[b.index] = parentWorld * b.c0 * pose * b.c1:Inverse()
	end
	return bones, map
end

-- 1.56: one sampler per preview run. The old per-frame path re-sorted the keyframes and re-scanned the pose tree for
-- EVERY bone on EVERY frame (twice) and resolved joints by string path - with 15 bones x 60 baked keys that was a slide
-- show, and because t advanced by a fixed 1/30 regardless of the real frame time the clip also played in slow motion.
-- The sampler reads the KeyframeSequence once (times + per-bone CFrame tracks + easing poses), binary-searches the
-- segment and writes Transform / child CFrames directly on the cached joint instances.
local function buildSampler(anim, rig, root)
	local kfs = sortedKeyframes(anim)
	local bones = buildBones(rig, root)
	local times, tracks = {}, {}
	for i, kf in ipairs(kfs) do times[i] = kf.Time end
	local maps = {}
	for i, kf in ipairs(kfs) do
		local m = {}
		local function scan(p) m[p.Name] = p; for _, sub in ipairs(p:GetSubPoses()) do scan(sub) end end
		for _, p in ipairs(kf:GetPoses()) do scan(p) end
		maps[i] = m
	end
	for _, b in ipairs(bones) do
		local cfs, poses = {}, {}
		for i = 1, #kfs do
			local p = maps[i][b.name]
			cfs[i] = p and p.CFrame or CFrame.new()
			poses[i] = p
		end
		tracks[b.name] = { cfs = cfs, poses = poses }
	end
	local n = #times
	local function segment(t)
		if n == 0 then return 1, 1, 0 end
		if t <= times[1] then return 1, 1, 0 end
		if t >= times[n] then return n, n, 0 end
		local lo, hi = 1, n
		while hi - lo > 1 do
			local mid = math.floor((lo + hi) / 2)
			if times[mid] <= t then lo = mid else hi = mid end
		end
		local span = times[hi] - times[lo]
		return lo, hi, span > 0 and (t - times[lo]) / span or 0
	end
	local sampler = { bones = bones, times = times, count = n }
	function sampler.localPose(name, t)
		local tr = tracks[name]
		if not tr or n == 0 then return CFrame.new() end
		local i, j, alpha = segment(t)
		if i == j then return tr.cfs[i] end
		return tr.cfs[i]:Lerp(tr.cfs[j], easedAlpha(tr.poses[i], alpha))
	end
	function sampler.apply(t)
		local rootCF = root.CFrame
		local map = {}
		for _, b in ipairs(bones) do
			local pose = sampler.localPose(b.name, t)
			local parentWorld = (b.parentIdx == 0) and rootCF or map[b.parentIdx]
			map[b.index] = parentWorld * b.c0 * pose * b.c1:Inverse()
			local joint = b.joint
			if joint and joint.Parent then
				if b.kind == "Motor6D" or b.kind == "AnimationConstraint" then joint.Transform = pose end
				if b.kind ~= "Motor6D" then b.part1.CFrame = map[b.index] end
			end
		end
		return map
	end
	return sampler
end

local function applyPoseAt(t)
	local anim = activeAnim()
	if not anim then return fail("no active animation - create or open one first") end
	local rig = activeRig(anim)
	if not rig then return fail("no rig found in workspace (need a Model with a Humanoid + roots)") end
	local root = rigRoot(rig)
	if not root then return fail("no root part found on the rig") end
	local sampler = buildSampler(anim, rig, root)
	if #sampler.bones == 0 then return fail("no joints found on the rig") end
	sampler.apply(t)
	return nil
end

local function resetTransforms(rig, root)
	-- Motor6D rigs: zero the joint transforms. Constraint rigs: write the
	-- rest-pose world CFrame (pose = identity) straight onto the child parts.
	local bones, map = computeWorldPoses(rig, root, nil, 0)
	for _, b in ipairs(bones) do
		local joint = resolvePath(b.jointPath)
		if joint then
			joint.Transform = CFrame.new()
			if b.kind ~= "Motor6D" then b.part1.CFrame = map[b.index] end
		end
	end
end

local function stopPreview(restore)
	PREVIEW_TOKEN.Value = PREVIEW_TOKEN.Value + 1
	local oldRig = resolvePath(PREVIEW_RIG.Value)
	PREVIEW_RIG.Value = ""
	if restore and oldRig then
		local oldRoot = rigRoot(oldRig)
		if oldRoot then resetTransforms(oldRig, oldRoot) end
	end
end

-- Forward declaration: create/select use this after it is assigned below.
local rigEvidence
local api = {}

function api.select_rig(a)
	local path = tostring(a.path or "")
	if path == "" then return fail("path is required (for example 'Workspace.R15')") end
	local rig = resolvePath(path)
	if not rig or not rig:IsA("Model") then return fail(("'%s' is not a Model"):format(path)) end
	if not rig:FindFirstChildOfClass("Humanoid") then return fail(("'%s' has no Humanoid and is not an animation rig"):format(path)) end
	local root = rigRoot(rig)
	if not root then return fail(("'%s' has no HumanoidRootPart, PrimaryPart, Torso, or UpperTorso"):format(path)) end
	if #buildBones(rig, root) == 0 then return fail(("'%s' has no connected Motor6D or supported constraint joints"):format(path)) end
	SELECTED_RIG.Value = pathOf(rig)
	local anim = activeAnim()
	if anim then anim:SetAttribute("RS_RigPath", SELECTED_RIG.Value) end
	RIGREF.Value = SELECTED_RIG.Value
	return okdata(rigEvidence(rig), ("selected rig '%s' for new animations%s"):format(rig.Name, anim and " and pinned the active animation to it" or ""))
end

function api.clear_rig_selection()
	SELECTED_RIG.Value = ""
	return okdata({}, "cleared explicit rig selection; new animations will auto-detect the best rig")
end

function api.create(a)
	local rig = findRig()
	if not rig then return fail("no rig found in workspace (need a Model with a Humanoid + roots)") end
	local root = rigRoot(rig)
	if not root then return fail("the rig was found but no root part (HumanoidRootPart/Torso/UpperTorso) - the model may not be a valid character") end
	local name = tostring(a.name or "")
	if name == "" then return fail("animation name is required") end
	local existing = findAnim(name)
	if existing and not a.overwrite then return fail(("an animation named '%s' ALREADY EXISTS - nothing was changed. Pass overwrite=true to replace it, or pick another name"):format(name)) end
	if existing then existing:Destroy() end
	local anim = Instance.new("KeyframeSequence")
	anim.Name = name
	anim.Loop = false
	anim.Priority = Enum.AnimationPriority.Action
	local t0 = Instance.new("NumberValue")
	t0.Name = "Duration"
	t0.Value = tonumber(a.duration) or 1
	t0.Parent = anim
	anim.Parent = LIB
	local kf = newKeyframe(anim, 0)
	buildPoseTree(kf, rig, root)
	anim:SetAttribute("RS_RigPath", pathOf(rig))
	RIGREF.Value = pathOf(rig)
	ACTIVE.Value = name
	LENGTH.Value = tonumber(a.duration) or 1
	local d = inspectAnim(anim)
	local ev = rigEvidence(rig)
	return okdata(d, ("created animation '%s' (%d bones, keyframe at t=0 default pose, pinned to rig '%s' with %d Motor6D + %d constraint joints)"):format(name, #d.bones, rig.Name, ev.motorJoints, ev.constraintJoints))
end

function api.open(a)
	local name = tostring(a.name or "")
	if name == "" then return fail("animation name is required") end
	local anim = findAnim(name)
	if not anim then
		local names = {}
		for _, c in ipairs(getAnims()) do if c:IsA("KeyframeSequence") then names[#names + 1] = c.Name end end
		return fail(("no animation named '%s' - existing: %s"):format(name, #names > 0 and table.concat(names, ", ") or "(none)"))
	end
	ACTIVE.Value = name
	local pinned = pinOf(anim)
	if not pinned then
		pinned = findRig()
		if pinned then
			anim:SetAttribute("RS_RigPath", pathOf(pinned))
			RIGREF.Value = pathOf(pinned)
		end
	end
	if pinned then RIGREF.Value = pathOf(pinned) end
	local lenV = anim:FindFirstChild("Duration")
	if lenV then LENGTH.Value = tonumber(lenV.Value) or LENGTH.Value end
	-- SELF-HEAL: if the animation's stored pose tree does not match the pinned
	-- rig's bones (e.g. an old animation authored on an R6 rig whose tree still
	-- says "Torso/Left Arm/..."), rebuild the tree onto the rig automatically.
	-- Matching bones keep their values; the reply reports what happened.
	local healed = false
	local healNote = ""
	if pinned then
		local root = rigRoot(pinned)
		local kfs = sortedKeyframes(anim)
		if root and #kfs > 0 then
			local treeNames = {}
			local function collect(p)
				treeNames[p.Name] = true
				for _, sub in ipairs(p:GetSubPoses()) do collect(sub) end
			end
			for _, p in ipairs(kfs[1]:GetPoses()) do collect(p) end
			local bones = buildBones(pinned, root)
			local boneNames = {}
			for _, b in ipairs(bones) do boneNames[b.name] = true end
			local missing = 0
			for name in pairs(treeNames) do if not boneNames[name] then missing = missing + 1 end end
			if missing > 0 and missing > #boneNames / 2 then
				local created = 0
				for _, kf in ipairs(kfs) do
					local _, n = buildPoseTree(kf, pinned, root)
					created = created + n
				end
				healed = true
				healNote = (" pose tree did not match rig '%s' (%d bone(s) mismatched) - auto-rebuilt onto the rig (%d bone pose(s) added, keyframe times preserved)"):format(pinned.Name, missing, created)
			end
		end
	end
	local d = inspectAnim(anim)
	return okdata(d, ("opened animation '%s'%s%s"):format(name, pinned and (" (pinned to rig '%s')"):format(pinned.Name) or "", healNote))
end

-- Hard evidence about which rig the tools see and how its joints are wired:
-- used in animation_test / animation_list replies so the conversation can
-- never pretend an "internal 7-bone rig" exists - the reply names the exact
-- Model in the workspace and counts its actual joints.
rigEvidence = function(rig)
	local motor, constraint = 0, 0
	for _, d in ipairs(rig:GetDescendants()) do
		if d:IsA("Motor6D") then motor = motor + 1 elseif d:IsA("AnimationConstraint") or d:IsA("BallSocketConstraint") then constraint = constraint + 1 end
	end
	return { name = rig.Name, path = pathOf(rig), motorJoints = motor, constraintJoints = constraint }
end

function api.list()
	local names = {}
	for _, c in ipairs(getAnims()) do if c:IsA("KeyframeSequence") then names[#names + 1] = c.Name end end
	local active = activeAnim()
	return okdata({ active = ACTIVE.Value, animations = names, rig = active and (pinOf(active) and rigEvidence(pinOf(active)) or nil) or nil },
		("%d animation(s) in the library"):format(#names) .. (active and pinOf(active) and (" - active animation '%s' is pinned to rig '%s' (%d motor / %d constraint joints)"):format(active.Name, pinOf(active).Name, rigEvidence(pinOf(active)).motorJoints, rigEvidence(pinOf(active)).constraintJoints) or ""))
end

function api.set_length(a)
	local anim = activeAnim()
	if not anim then return fail("no active animation - create or open one first") end
	local dur = tonumber(a.duration)
	if not dur or dur <= 0 then return fail("duration must be a positive number of seconds") end
	LENGTH.Value = dur
	local lenV = anim:FindFirstChild("Duration")
	if not lenV then lenV = NumberValue.new("Duration", dur); lenV.Parent = anim else lenV.Value = dur end
	return okdata(inspectAnim(anim), ("animation '%s' length set to %.2fs"):format(anim.Name, dur))
end

function api.set_settings(a)
	local anim = activeAnim()
	if not anim then return fail("no active animation - create or open one first") end
	local changed = {}
	if a.loop ~= nil then
		if type(a.loop) ~= "boolean" then return fail("loop must be true or false") end
		anim.Loop = a.loop
		changed[#changed + 1] = "loop=" .. tostring(a.loop)
	end
	if a.priority ~= nil then
		local name = tostring(a.priority)
		local priority = Enum.AnimationPriority[name]
		if not priority then return fail("unknown priority '" .. name .. "' (use Core, Idle, Movement, Action, Action2, Action3, or Action4)") end
		anim.Priority = priority
		changed[#changed + 1] = "priority=" .. name
	end
	if #changed == 0 then return fail("provide loop and/or priority") end
	return okdata(inspectAnim(anim), ("animation settings updated: %s"):format(table.concat(changed, ", ")))
end

function api.keyframe(a, upsert)
	local anim = activeAnim()
	if not anim then return fail("no active animation - create or open one first") end
	local rig = activeRig(anim)
	if not rig then return fail("no rig found in workspace") end
	local t = tonumber(a.t)
	if not t or t < 0 then return fail("t (seconds) is required and must be >= 0") end
	upsert = upsert or (a.upsert == true)
	local kf = findKeyframe(anim, t)
	local created = false
	if not kf then
		if upsert then kf = newKeyframe(anim, t); created = true else return fail(("no keyframe at t=%s - create it first with animation_add_keyframe"):format(tostring(t))) end
	end
	local poses = a.poses
	if not poses then poses = {} end
	if #kf:GetPoses() == 0 then
		local root = rigRoot(rig)
		buildPoseTree(kf, rig, root)
	end
	for _, entry in ipairs(poses) do
		local bone = tostring(entry.bone or "")
		local pose = findPose(kf, bone)
		if not pose then return fail(("unknown bone '%s' - inspect the animation to see valid bone names"):format(bone)) end
		local pos = entry.pos
		local rot = entry.rot
		if (not pos) and (not rot) then return fail(("pose for '%s' needs pos and/or rot"):format(bone)) end
		local c = pose.CFrame
		if rot then
			local rx, ry, rz = tonumber(rot[1]) or 0, tonumber(rot[2]) or 0, tonumber(rot[3]) or 0
			c = CFrame.fromEulerAnglesYXZ(math.rad(ry), math.rad(rx), math.rad(rz))
		end
		if pos then c = CFrame.new(Vector3.new(tonumber(pos[1]) or 0, tonumber(pos[2]) or 0, tonumber(pos[3]) or 0)) * c end
		pose.CFrame = c
	end
	return okdata(inspectAnim(anim), ("keyframe at t=%.3fs %s"):format(t, created and "created" or "updated"))
end

function api.delete_keyframe(a)
	local anim = activeAnim()
	if not anim then return fail("no active animation - create or open one first") end
	local t = tonumber(a.t)
	if not t then return fail("t (seconds) is required") end
	local kf = findKeyframe(anim, t)
	if not kf then return fail(("no keyframe at t=%s"):format(tostring(t))) end
	kf:Destroy()
	return okdata(inspectAnim(anim), ("deleted keyframe at t=%.3fs"):format(t))
end

function api.move_keyframe(a)
	local anim = activeAnim()
	if not anim then return fail("no active animation - create or open one first") end
	local fromT, toT = tonumber(a.from_t), tonumber(a.to_t)
	if not fromT or not toT then return fail("from_t and to_t (seconds) are required") end
	if toT < 0 then return fail("to_t must be >= 0") end
	local kf = findKeyframe(anim, fromT)
	if not kf then return fail(("no keyframe at from_t=%s"):format(tostring(fromT))) end
	local clash = findKeyframe(anim, toT)
	if clash and clash ~= kf then return fail(("a keyframe already exists at to_t=%s - delete or move it first"):format(tostring(toT))) end
	kf.Time = toT
	return okdata(inspectAnim(anim), ("moved keyframe from t=%.3fs to t=%.3fs"):format(fromT, toT))
end

function api.clone_keyframe(a)
	local anim = activeAnim()
	if not anim then return fail("no active animation - create or open one first") end
	local fromT, toT = tonumber(a.from_t), tonumber(a.to_t)
	if not fromT or not toT or fromT < 0 or toT < 0 then return fail("from_t and to_t must be seconds >= 0") end
	local source = findKeyframe(anim, fromT)
	if not source then return fail(("no keyframe at from_t=%s"):format(tostring(fromT))) end
	if findKeyframe(anim, toT) then return fail(("a keyframe already exists at to_t=%s"):format(tostring(toT))) end
	local copy = source:Clone()
	copy.Time = toT
	copy.Parent = anim
	return okdata(inspectAnim(anim), ("duplicated keyframe from t=%.3fs to t=%.3fs"):format(fromT, toT))
end

function api.set_marker(a)
	local anim = activeAnim()
	if not anim then return fail("no active animation - create or open one first") end
	local t, name = tonumber(a.t), tostring(a.name or "")
	if not t or t < 0 then return fail("t must be seconds >= 0") end
	if name == "" then return fail("marker name is required") end
	local kf = findKeyframe(anim, t)
	if not kf then return fail(("no keyframe at t=%s - create it before adding a marker"):format(tostring(t))) end
	for _, marker in ipairs(kf:GetMarkers()) do
		if marker.Name == name then marker.Value = tostring(a.value or ""); return okdata(inspectAnim(anim), ("updated marker '%s' at t=%.3fs"):format(name, t)) end
	end
	local marker = Instance.new("KeyframeMarker")
	marker.Name = name
	marker.Value = tostring(a.value or "")
	marker.Parent = kf
	return okdata(inspectAnim(anim), ("added marker '%s' at t=%.3fs"):format(name, t))
end

function api.delete_marker(a)
	local anim = activeAnim()
	if not anim then return fail("no active animation - create or open one first") end
	local t, name = tonumber(a.t), tostring(a.name or "")
	if not t or t < 0 then return fail("t must be seconds >= 0") end
	if name == "" then return fail("marker name is required") end
	local kf = findKeyframe(anim, t)
	if not kf then return fail(("no keyframe at t=%s"):format(tostring(t))) end
	for _, marker in ipairs(kf:GetMarkers()) do
		if marker.Name == name then marker:Destroy(); return okdata(inspectAnim(anim), ("deleted marker '%s' at t=%.3fs"):format(name, t)) end
	end
	return fail(("no marker named '%s' at t=%.3fs"):format(name, t))
end

function api.set_easing(a)
	local anim = activeAnim()
	if not anim then return fail("no active animation - create or open one first") end
	local t = tonumber(a.t)
	if not t or t < 0 then return fail("t must be seconds >= 0") end
	local kf = findKeyframe(anim, t)
	if not kf then return fail(("no keyframe at t=%s"):format(tostring(t))) end
	local styleName, directionName = tostring(a.style or ""), tostring(a.direction or "Out")
	local style, direction = Enum.PoseEasingStyle[styleName], Enum.PoseEasingDirection[directionName]
	if not style then return fail("unknown easing style '" .. styleName .. "' (use Linear, Constant, Elastic, CubicV2, or Bounce)") end
	if not direction then return fail("unknown easing direction '" .. directionName .. "' (use In, Out, or InOut)") end
	local wanted = {}
	for _, name in ipairs(a.bones or {}) do wanted[tostring(name)] = true end
	local all, changed = next(wanted) == nil, 0
	local function visit(p)
		if all or wanted[p.Name] then p.EasingStyle = style; p.EasingDirection = direction; changed = changed + 1 end
		for _, sub in ipairs(p:GetSubPoses()) do visit(sub) end
	end
	for _, pose in ipairs(kf:GetPoses()) do visit(pose) end
	if changed == 0 then return fail("none of the requested bones exist at this keyframe") end
	return okdata(inspectAnim(anim), ("set %s/%s easing on %d pose(s) at t=%.3fs"):format(styleName, directionName, changed, t))
end

function api.inspect()
	local anim = activeAnim()
	if not anim then return fail("no active animation - create or open one first") end
	return okdata(inspectAnim(anim), ("%d keyframe(s) in '%s'"):format(#sortedKeyframes(anim), anim.Name))
end

function api.resets()
	stopPreview(true)
	return okdata({}, "preview stopped, rig returned to rest pose")
end

-- Rebuild the active animation's pose trees onto its pinned rig: keyframe
-- times are preserved, existing poses are kept when the bone still exists on
-- the rig, poses that are not on the rig are removed, missing bones are added
-- as identity poses. Use this to convert an R6-authored animation to the R15
-- rig (or vice versa) when the bone names do not match.
function api.rebuild()
	local anim = activeAnim()
	if not anim then return fail("no active animation - create or open one first") end
	local rig = activeRig(anim)
	if not rig then return fail("no rig found in workspace") end
	local root = rigRoot(rig)
	if not root then return fail("no root part found on the rig") end
	local kfs = sortedKeyframes(anim)
	if #kfs == 0 then return fail("animation has no keyframes") end
	local created = 0
	for _, kf in ipairs(kfs) do
		local _, n = buildPoseTree(kf, rig, root)
		created = created + n
	end
	anim:SetAttribute("RS_RigPath", pathOf(rig))
	local d = inspectAnim(anim)
	return okdata(d, ("pose tree rebuilt onto rig '%s': %d bone pose(s) added across %d keyframe(s); kept poses preserved, poses not on the rig removed"):format(rig.Name, created, #kfs))
end

-- Copy any existing KeyframeSequence from anywhere in the DataModel (e.g. a
-- real R15 animation saved under Workspace.X.AnimSaves.Run) into the library
-- and open it. The copied animation is pinned to the current rig.
function api.import(a)
	local path = tostring(a.path or "")
	if path == "" then return fail("path is required (e.g. 'Workspace.R15.AnimSaves.Run')") end
	local src = resolvePath(path)
	if not src then return fail(("nothing found at path '%s'"):format(path)) end
	if not src:IsA("KeyframeSequence") then return fail(("'%s' is a %s, not a KeyframeSequence"):format(path, src.ClassName)) end
	local name = tostring(a.name or "")
	if name == "" then name = src.Name end
	local existing = findAnim(name)
	if existing and not a.overwrite then return fail(("an animation named '%s' ALREADY EXISTS in the library - nothing was changed. Pass overwrite=true to replace it, or pick another name"):format(name)) end
	if existing then existing:Destroy() end
	local copy = src:Clone()
	copy.Name = name
	copy.Parent = LIB
	ACTIVE.Value = name
	local lenV = copy:FindFirstChild("Duration")
	if lenV then LENGTH.Value = tonumber(lenV.Value) or LENGTH.Value end
	local rig = findRig()
	if rig then
		copy:SetAttribute("RS_RigPath", pathOf(rig))
		RIGREF.Value = pathOf(rig)
	end
	local d = inspectAnim(copy)
	return okdata(d, ("imported '%s' as '%s' (%d keyframes, %d bones%s)"):format(path, name, d.keyframeCount, #d.bones, rig and (" - pinned to rig '%s'"):format(rig.Name) or ""))
end

function api.apply(a)
	local t = tonumber(a.t)
	if not t then return fail("t (seconds) is required") end
	local err = applyPoseAt(t)
	if err then return err end
	return okdata({ t = t }, ("posed rig at t=%.3fs (middle of blend between neighbours)"):format(t))
end

-- NUMERIC SIMULATION: sample the animation at EXACTLY time t through the
-- joint chain (pure math - identical to what the preview writes), pose the
-- rig in Studio at that moment, and report where EVERY bone lands in WORLD
-- space (position + orientation) plus quality metrics (root height, hand
-- mirror-symmetry deviation in studs, hand/foot/head positions). This gives
-- the agent eyes without screenshots: simulate at t=0, the middle and the
-- last keyframe to judge spacing, arcs, symmetry and ground contact, then
-- fix poses and re-simulate until the frames read clean.
-- Highest solid surface below the rig (within radius) = the "ground".
-- Parts count if the top face is within 30 studs horizontally of the root.
-- Terrain (if present) is sampled straight under the root. Feet clearances
-- are measured against it so walk cycles can be QA'd: clearance ~0 =
-- planted, >0 = floating, <0 = clipping through the floor.
local function findGroundY(rig, root)
	local rp = root.CFrame.Position
	local best = nil
	for _, p in ipairs(workspace:GetDescendants()) do
		if p:IsA("BasePart") and rig:IsAncestorOf(p) == false and p ~= root then
			local pp = p.CFrame.Position
			local d = ((pp.X - rp.X) * (pp.X - rp.X) + (pp.Z - rp.Z) * (pp.Z - rp.Z))
			if d <= 900 and pp.Y < rp.Y then
				local top = pp.Y + math.abs(p.Size.Y) / 2
				if not best or top > best then best = top end
			end
		end
	end
	local terrain = workspace:FindFirstChildOfClass("Terrain")
	if terrain and terrain:GetMaterial(rp, Vector3.new(4, 4, 4)) ~= Enum.Material.Air then
		local ty = rp.Y
		while ty > -2000 do
			local mat = terrain:GetMaterial(Vector3.new(rp.X, ty, rp.Z), Vector3.new(4, 4, 4))
			if mat ~= Enum.Material.Air then
				if not best or ty > best then best = ty end
				break
			end
			ty = ty - 4
		end
	end
	return best
end

function api.simulate(a)
	local anim = activeAnim()
	if not anim then return fail("no active animation - create or open one first") end
	local rig = activeRig(anim)
	if not rig then return fail("no rig found in workspace") end
	local root = rigRoot(rig)
	if not root then return fail("no root part found on the rig") end
	local groundY = findGroundY(rig, root)
	local bonesBase, _ = computeWorldPoses(rig, root, anim, 0)
	if #bonesBase == 0 then return fail("no joints found on the rig") end
	local function findBone2(names)
		for _, n in ipairs(names) do
			for _, b in ipairs(bonesBase) do if b.name == n then return b end end
		end
		return nil
	end
	local lhB, rhB = findBone2({ "LeftHand", "Left Arm", "LeftArm" }), findBone2({ "RightHand", "Right Arm", "RightArm" })
	local lfB, rfB = findBone2({ "LeftFoot", "Left Leg", "LeftLeg" }), findBone2({ "RightFoot", "Right Leg", "RightLeg" })
	local headB = findBone2({ "Head" })
	local rootCF = root.CFrame

	-- FULL-SEQUENCE QA SWEEP: one call checks EVERY keyframe (start, middle,
	-- end, and all in between) and returns a verdict flagging any frame with
	-- floating feet, clipping through the floor or asymmetric hands - so a bad
	-- animation is caught and fixed BEFORE it is offered to the user.
	if a.all == true then
		local kfs = sortedKeyframes(anim)
		if #kfs == 0 then return fail("animation has no keyframes to sweep") end
		stopPreview(true)
		local frames = {}
		local issues = {}
		local function clearanceOf(b, t)
			local _, m = computeWorldPoses(rig, root, anim, t)
			return groundY and m[b.index].Position.Y - groundY or nil
		end
		local function symAt(t)
			if not (lhB and rhB) then return nil end
			local _, m = computeWorldPoses(rig, root, anim, t)
			local ls = rootCF:PointToObjectSpace(m[lhB.index].Position)
			local rs = rootCF:PointToObjectSpace(m[rhB.index].Position)
			return (ls - Vector3.new(-rs.X, rs.Y, rs.Z)).Magnitude
		end
		for _, kf in ipairs(kfs) do
			local t = kf.Time
			local f = { t = math.round(t * 1000) / 1000 }
			local issuesHere = {}
			if groundY then
				if lfB then
					local c = clearanceOf(lfB, t)
					f.lFootClearance = math.round(c * 100) / 100
					if c > 0.06 then issuesHere[#issuesHere + 1] = "left foot FLOATING +" .. string.format("%.2f", c) .. " studs"
					elseif c < -0.03 then issuesHere[#issuesHere + 1] = "left foot CLIPPING " .. string.format("%.2f", c) .. " studs" end
				end
				if rfB then
					local c = clearanceOf(rfB, t)
					f.rFootClearance = math.round(c * 100) / 100
					if c > 0.06 then issuesHere[#issuesHere + 1] = "right foot FLOATING +" .. string.format("%.2f", c) .. " studs"
					elseif c < -0.03 then issuesHere[#issuesHere + 1] = "right foot CLIPPING " .. string.format("%.2f", c) .. " studs" end
				end
			end
			local s = symAt(t)
			if s then
				f.symmetryDeviation = math.round(s * 100) / 100
				if s > 0.06 then issuesHere[#issuesHere + 1] = "asymmetric hands (deviation " .. string.format("%.2f", s) .. " studs)" end
			end
			f.issues = issuesHere
			frames[#frames + 1] = f
			for _, i in ipairs(issuesHere) do
				issues[#issues + 1] = ("t=%.2fs: %s"):format(t, i)
			end
		end
		if #kfs > 1 then
			local lastT = kfs[#kfs].Time
			applyPoseAt(lastT)
		end
		local verdict
		if #issues == 0 then
			verdict = "ALL %d frame(s) CLEAN - feet planted, hands symmetric: safe to preview"
		else
			verdict = "%d frame(s) flag(s) - FIX before preview"
		end
		verdict = verdict:format(#issues)
		return okdata({ sweep = true, frames = frames, issues = issues, groundY = groundY and math.round(groundY * 100) / 100 or nil },
			("QA SWEEP of all %d keyframes (t=0 to t=%.2fs): %s%s%s"):format(#kfs, kfs[#kfs].Time, verdict,
				#issues > 0 and (" - issues: " .. table.concat(issues, "; ")) or "",
				not groundY and (lfB or rfB) and " | NO GROUND DETECTED below the rig (no floor or terrain within 30 studs) - foot checks skipped; add a floor part or move the rig above the ground" or ""))
	end

	local t = tonumber(a.t)
	if not t or t < 0 then return fail("t (seconds) is required and must be >= 0 (or use all=true for the full-sequence QA sweep)") end
	local bones, map = computeWorldPoses(rig, root, anim, t)
	if #bones == 0 then return fail("no joints found on the rig") end
	stopPreview(true)
	local posErr = applyPoseAt(t)
	if posErr then return posErr end
	local world = {}
	for _, b in ipairs(bones) do
		local cf = map[b.index]
		local sx, sy, sz = cf:ToEulerAnglesYXZ()
		world[b.name] = {
			pos = { math.round(cf.Position.X * 100) / 100, math.round(cf.Position.Y * 100) / 100, math.round(cf.Position.Z * 100) / 100 },
			rot = { math.round(math.deg(sy) * 100) / 100, math.round(math.deg(sx) * 100) / 100, math.round(math.deg(sz) * 100) / 100 },
		}
	end
	local function findBone(names)
		for _, n in ipairs(names) do
			for _, b in ipairs(bones) do if b.name == n then return b end end
		end
		return nil
	end
	local lh, rh = findBone({ "LeftHand", "Left Arm", "LeftArm" }), findBone({ "RightHand", "Right Arm", "RightArm" })
	local lf, rf = findBone({ "LeftFoot", "Left Leg", "LeftLeg" }), findBone({ "RightFoot", "Right Leg", "RightLeg" })
	local head = findBone({ "Head" })
	local symDev = nil
	if lh and rh then
		local ls = rootCF:PointToObjectSpace(map[lh.index].Position)
		local rs = rootCF:PointToObjectSpace(map[rh.index].Position)
		symDev = math.round((ls - Vector3.new(-rs.X, rs.Y, rs.Z)).Magnitude * 100) / 100
	end
	local data = { t = math.round(t * 1000) / 1000, rootY = math.round(rootCF.Position.Y * 100) / 100, symmetryDeviation = symDev, groundY = groundY and math.round(groundY * 100) / 100 or nil, bones = world }
	local parts = { ("simulation at t=%.2fs (rig posed in Studio): root y=%.2f"):format(t, data.rootY) }
	if symDev then parts[#parts + 1] = ("hand mirror-symmetry deviation: %.2f studs (0 = perfectly mirrored)"):format(symDev) end
	local function line(label, b, foot)
		if not b then return end
		local cf = map[b.index]
		if foot and groundY then
			local clearance = math.round((cf.Position.Y - groundY) * 100) / 100
			parts[#parts + 1] = ("%s y=%.2f (ground y=%.2f -> clearance %+.2f studs: %s)"):format(label, cf.Position.Y, groundY, clearance,
				clearance <= 0.03 and clearance >= -0.03 and "planted" or (clearance > 0 and "FLOATING" or "CLIPPING THROUGH FLOOR"))
		else
			parts[#parts + 1] = ("%s at (%.2f, %.2f, %.2f)"):format(label, cf.Position.X, cf.Position.Y, cf.Position.Z)
		end
	end
	line("left hand", lh); line("right hand", rh)
	line("left foot", lf, true); line("right foot", rf, true)
	line("head", head)
	if not groundY and (lf or rf) then parts[#parts + 1] = "NO GROUND DETECTED below the rig (no floor or terrain within 30 studs) - foot clearances unavailable; add a floor part or move the rig above the ground and re-simulate" end
	return okdata(data, table.concat(parts, "; "))
end

function api.preview(a)
	local anim = activeAnim()
	if not anim then return fail("no active animation - create or open one first") end
	local dur = tonumber(a.duration) or LENGTH.Value
	if not dur or dur <= 0 then return fail("duration must be positive") end
	local rig = activeRig(anim)
	if not rig then return fail("no rig found in workspace") end
	local root = rigRoot(rig)
	if not root then return fail("no root part found on the rig") end
	-- A new token invalidates any async preview launched by a previous call.
	stopPreview(true)
	local token = PREVIEW_TOKEN.Value + 1
	PREVIEW_TOKEN.Value = token
	PREVIEW_RIG.Value = pathOf(rig)
	if #sortedKeyframes(anim) < 2 then
		local err = applyPoseAt(0)
		PREVIEW_TOKEN.Value = PREVIEW_TOKEN.Value + 1
		PREVIEW_RIG.Value = ""
		if err then return err end
		return okdata({}, "only one keyframe - posed at t=0 (add more keyframes for a moving preview)")
	end
	local speed = tonumber(a.speed) or 1
	if speed <= 0 then speed = 1 end
	local loops = a.loop
	if loops == nil then loops = anim.Loop end
	local cycles = loops and math.max(1, math.min(20, math.floor(tonumber(a.cycles) or 3))) or 1
	local total = dur * cycles
	local sampler = buildSampler(anim, rig, root)
	if #sampler.bones == 0 then return fail("no joints found on the rig") end
	task.spawn(function()
		-- real elapsed time drives the clip (Studio's frame time varies - a fixed step played slow motion)
		local t0 = os.clock()
		local frames = 0
		while PREVIEW_TOKEN.Value == token do
			local el = (os.clock() - t0) * speed
			if el >= total then break end
			local t = el - dur * math.floor(el / dur)
			sampler.apply(t)
			frames = frames + 1
			task.wait()
		end
		if PREVIEW_TOKEN.Value == token then
			sampler.apply(loops and 0 or dur)
			PREVIEW_TOKEN.Value = token + 1
			PREVIEW_RIG.Value = ""
			task.wait(0.35)
			resetTransforms(rig, root)
		end
	end)
	return okdata({ duration = dur, cycles = cycles, speed = speed, keyframes = sampler.count, bones = #sampler.bones },
		("preview playing %.2fs%s at %.2fx, real-time (frame-rate independent, %d keyframes on %d bones); stops automatically - animation_stop_preview stops early"):format(dur, cycles > 1 and (" x " .. cycles .. " loops") or "", speed, sampler.count, #sampler.bones))
end

-- Probe the rig's rotation-sign convention PURELY MATHEMATICALLY: apply +95
-- roll to the right arm in the joint chain and compute where the arm would
-- move, without touching the rig (works for Motor6D AND AnimationConstraint
-- rigs, in or out of Edit mode). Standard convention = up and out; mirrored
-- rigs would move it down/in.
local function probeDirection(rig, root)
	local bones = buildBones(rig, root)
	local target = nil
	for _, b in ipairs(bones) do
		if b.name == "RightUpperArm" or b.name == "Right Arm" or b.name == "RightArm" then target = b break end
	end
	if not target then
		local names = {}
		for _, b in ipairs(bones) do names[#names + 1] = b.name end
		return { measured = false, note = "no right-arm bone found (bones: " .. (#names > 0 and table.concat(names, ", ") or "none") .. ")" }
	end
	local rootCF = root.CFrame
	local map0, map95 = {}, {}
	for _, b in ipairs(bones) do
		local pose = b == target and CFrame.fromEulerAnglesYXZ(0, 0, math.rad(95)) or CFrame.new()
		local p0w, p95w = CFrame.new(), CFrame.new()
		local parent0 = (b.parentIdx == 0) and rootCF or map0[b.parentIdx]
		local parent95 = (b.parentIdx == 0) and rootCF or map95[b.parentIdx]
		map0[b.index] = parent0 * b.c0 * b.c1:Inverse()
		map95[b.index] = parent95 * b.c0 * pose * b.c1:Inverse()
	end
	local p0 = rootCF:PointToObjectSpace(map0[target.index].Position)
	local p1 = rootCF:PointToObjectSpace(map95[target.index].Position)
	local d = { x = p1.X - p0.X, y = p1.Y - p0.Y, z = p1.Z - p0.Z }
	local up = d.y > 0
	local out = d.x > 0
	return { measured = true, d = d, up = up, out = out, convention = (up and out) and "standard" or "mirrored" }
end

function api.test()
	local rig = findRig()
	if not rig then return fail("no rig found in workspace") end
	if findAnim("RS_Test_Idle") then findAnim("RS_Test_Idle"):Destroy() end
	local anim = Instance.new("KeyframeSequence")
	anim.Name = "RS_Test_Idle"
	anim.Parent = LIB
	local root = rigRoot(rig)
	local kf0 = newKeyframe(anim, 0)
	buildPoseTree(kf0, rig, root)
	local kf1 = newKeyframe(anim, 0.5)
	buildPoseTree(kf1, rig, root)
	local kf2 = newKeyframe(anim, 1)
	buildPoseTree(kf2, rig, root)
	local armL, armR = findPose(kf1, "LeftUpperArm"), findPose(kf1, "RightUpperArm")
	if not (armL or armR) then armL, armR = findPose(kf1, "Left Arm"), findPose(kf1, "Right Arm") end
	if not (armL or armR) then armL, armR = findPose(kf1, "LeftArm"), findPose(kf1, "RightArm") end
	if armL then armL.CFrame = CFrame.fromEulerAnglesYXZ(0, 0, math.rad(-95)) end
	if armR then armR.CFrame = CFrame.fromEulerAnglesYXZ(0, 0, math.rad(95)) end
	ACTIVE.Value = anim.Name
	anim:SetAttribute("RS_RigPath", pathOf(rig))
	RIGREF.Value = pathOf(rig)
	LENGTH.Value = 1
	local probe = probeDirection(rig, root)
	local verdict = "unknown"
	if probe.measured then
		verdict = probe.convention == "standard" and "standard - use rot values as given" or "MIRRORED - flip the sign of every rot value you send on this rig"
	end
	local evidence = rigEvidence(rig)
	return okdata({ inspect = inspectAnim(anim), probe = probe, rig = evidence },
		"test animation 'RS_Test_Idle' created on rig '" .. rig.Name .. "' (" .. evidence.motorJoints .. " Motor6D + " .. evidence.constraintJoints .. " constraint joints; id " .. pathOf(rig) .. "). " ..
		"idle at t=0, arms raised AT SIDES at t=0.5, idle at t=1, 1s. " ..
		"Direction probe (right arm +95 roll -> d=[x " .. (probe.d and string.format("%.2f", probe.d.x) or "?") .. ", y " ..
		(probe.d and string.format("%.2f", probe.d.y) or "?") .. ", z " .. (probe.d and string.format("%.2f", probe.d.z) or "?") .. "]): " ..
		(probe.measured and ("up=" .. tostring(probe.up) .. " out=" .. tostring(probe.out) .. " => " .. verdict) or probe.note))
end

-- PER-JOINT AXIS MAP: stop guessing which local rotation axis moves a limb.
-- For every joint (or a.filter list) this rotates the joint +angle around its
-- own X, Y and Z axes ONE AT A TIME, computes the child part's resulting
-- WORLD-space displacement through the exact same chain math the preview uses
-- (pure math - the rig is never touched), and classifies each local axis into
-- the world direction it actually swings: forward/back, up/down or left/right
-- (root frame). The reply is a per-joint "axis card" so a walk can be authored
-- by rotating the correct axis instead of guessing.
local function classifyAxis(d)
	local ax, ay, az = math.abs(d.x), math.abs(d.y), math.abs(d.z)
	if az >= ax and az >= ay then
		return "forward/back", d.z >= 0 and "+rot=forward, -rot=back" or "+rot=back, -rot=forward"
	elseif ax >= ay then
		return "left/right", d.x >= 0 and "+rot=LEFT, -rot=right" or "+rot=right, -rot=LEFT"
	end
	return "up/down", d.y >= 0 and "+rot=up, -rot=down" or "+rot=down, -rot=up"
end

function api.map_axes(a)
	local rig = activeAnim() and activeRig(activeAnim()) or findRig()
	if not rig then return fail("no rig found in workspace (need a Model with a Humanoid + joints)") end
	local root = rigRoot(rig)
	if not root then return fail("no root part found on the rig") end
	local bones = buildBones(rig, root)
	if #bones == 0 then return fail("no joints found on the rig") end
	local filter = {}
	if a.filter then
		for _, n in ipairs(a.filter) do filter[tostring(n)] = true end
	end
	local angle = math.rad(tonumber(a.angle) or 30)
	local rootCF = root.CFrame
	local trials = {
		{ "X", CFrame.Angles(angle, 0, 0) },
		{ "Y", CFrame.Angles(0, angle, 0) },
		{ "Z", CFrame.Angles(0, 0, angle) },
	}
	local cards = {}
	local summaries = {}
	for _, bone in ipairs(bones) do
		if #bones <= 24 or filter[bone.name] then
			local card = {}
			local bits = {}
			for _, trial in ipairs(trials) do
				local map0, map1 = {}, {}
				for _, b in ipairs(bones) do
					local pose = (b == bone) and trial[2] or CFrame.new()
					map0[b.index] = ((b.parentIdx == 0) and rootCF or map0[b.parentIdx]) * b.c0 * b.c1:Inverse()
					map1[b.index] = ((b.parentIdx == 0) and rootCF or map1[b.parentIdx]) * b.c0 * pose * b.c1:Inverse()
				end
				local p0 = rootCF:PointToObjectSpace(map0[bone.index].Position)
				local p1 = rootCF:PointToObjectSpace(map1[bone.index].Position)
				local d = { x = p1.X - p0.X, y = p1.Y - p0.Y, z = p1.Z - p0.Z }
				local kind, sign = classifyAxis(d)
				card[trial[1]] = ("%s (%s; dx=%+.2f dy=%+.2f dz=%+.2f)"):format(kind, sign, d.x, d.y, d.z)
				bits[#bits + 1] = ("%s=%s"):format(trial[1], kind)
			end
			cards[bone.name] = card
			summaries[#summaries + 1] = ("%s: X=%s, Y=%s, Z=%s"):format(bone.name, bits[1], bits[2], bits[3])
		end
	end
	if next(cards) == nil then
		local names = {}
		for _, b in ipairs(bones) do names[#names + 1] = b.name end
		return fail(("no joints matched the filter - valid bones: %s"):format(table.concat(names, ", ")))
	end
	local ev = rigEvidence(rig)
	return okdata({ rig = ev, angleDeg = math.deg(angle), axes = cards },
		("AXIS MAP of %d/%d joints on rig '%s' (+%.0f deg per axis; root frame X=left/right Y=up/down Z=forward/back, WORLD-measured): %s"):format(#cards, #bones, ev.name, math.deg(angle), table.concat(summaries, " | ")))
end

-- ───────── 1.52.0 ANIMATION ENGINE ops ─────────
-- rig_info: what the engine needs to map its semantic skeleton onto THIS rig
-- (rig type, bone names + parents, stored engine attributes of a clip).
function api.rig_info(a)
	local rig = findRig()
	if not rig then return fail("no rig found in workspace (need a Model with a Humanoid + HumanoidRootPart; use animation_select_rig {path} to pick one)") end
	local root = rigRoot(rig)
	if not root then return fail("the rig has no root part (HumanoidRootPart/Torso/UpperTorso)") end
	local bones = buildBones(rig, root)
	if #bones == 0 then return fail(("rig '%s' has no connected Motor6D or supported constraint joints"):format(rig.Name)) end
	local hum = rig:FindFirstChildOfClass("Humanoid")
	local rigType = "Custom"
	if hum then
		local okT, rt = pcall(function() return hum.RigType end)
		if okT and rt and rt.Name then rigType = rt.Name end
	end
	local list = {}
	for _, b in ipairs(bones) do
		local parent = b.parentIdx == 0 and root.Name or bones[b.parentIdx].name
		list[#list + 1] = { name = b.name, parent = parent, kind = b.kind }
	end
	local names = {}
	local stored = nil
	for _, c in ipairs(getAnims()) do
		if c:IsA("KeyframeSequence") then
			names[#names + 1] = c.Name
			if (a.name and c.Name == tostring(a.name)) or ((not a.name) and ACTIVE.Value == c.Name) then
				local lenV = c:FindFirstChild("Duration")
				stored = {
					name = c.Name, prompt = c:GetAttribute("Total_Prompt"), quality = c:GetAttribute("Total_Quality"),
					params = c:GetAttribute("Total_Params"), engine = c:GetAttribute("Total_Engine"), fps = c:GetAttribute("Total_Fps"),
					loop = c.Loop, priority = c.Priority.Name, duration = lenV and lenV.Value or nil, keyframes = #sortedKeyframes(c),
				}
			end
		end
	end
	return okdata({ rigType = rigType, path = pathOf(rig), name = rig.Name, root = root.Name, bones = list, clip = stored, animations = names },
		("rig '%s' (%s, %d bones) root %s"):format(rig.Name, rigType, #bones, root.Name))
end

-- build: write a whole engine clip into a KeyframeSequence in ONE call.
-- a.bones = ordered bone names; a.keys = { {t=, e={style,dir}, m={{name,value}}, p={ {rx,ry,rz[,px,py,pz]}, ... } } }
-- Rotations are DEGREES in the PARENT (torso-frame) convention Ry*Rx*Rz; the
-- real joint-local transform is C0rot^-1 * R * C0rot, which is exact for R15
-- (identity C0 rotations), R6 (rotated shoulder/hip frames) and custom rigs.
function api.build(a)
	local name = tostring(a.name or "")
	if name == "" then return fail("animation name is required") end
	local rig = findRig()
	if not rig then return fail("no rig found in workspace (need a Model with a Humanoid + HumanoidRootPart)") end
	local root = rigRoot(rig)
	if not root then return fail("the rig has no root part (HumanoidRootPart/Torso/UpperTorso)") end
	local bones = buildBones(rig, root)
	if #bones == 0 then return fail(("rig '%s' has no connected Motor6D or supported constraint joints"):format(rig.Name)) end
	local byName = {}
	for _, b in ipairs(bones) do byName[b.name] = b end
	local names = a.bones or {}
	local missing, present = {}, 0
	for _, n in ipairs(names) do if byName[n] then present = present + 1 else missing[#missing + 1] = n end end
	if present == 0 or present * 2 < #names then
		local have = {}
		for _, b in ipairs(bones) do have[#have + 1] = b.name end
		return fail(("only %d of the clip's %d bones exist on rig '%s' (wrong rig type?) - clip bones: %s; rig bones: %s"):format(present, #names, rig.Name, table.concat(names, ", "), table.concat(have, ", ")))
	end
	local keys = a.keys or {}
	if #keys == 0 then return fail("the clip has no keyframes") end
	local duration = tonumber(a.duration) or 0
	if duration <= 0 then return fail("duration must be > 0") end
	local existing = findAnim(name)
	local anim
	if a.append then
		-- 1.54: long (spline-baked) clips arrive in several chunks; chunks 2..n append to the sequence chunk 1 created
		if not existing then return fail(("append: no animation named '%s' to append to - send the first chunk without append"):format(name)) end
		if existing:GetAttribute("Total_Chunked") ~= true then return fail(("append: '%s' is not an open chunked build (it was finished or built in one call)"):format(name)) end
		anim = existing
	else
		if existing and not a.overwrite then return fail(("an animation named '%s' ALREADY EXISTS - nothing was changed. Pass overwrite=true to replace it, or pick another name"):format(name)) end
		if existing then existing:Destroy() end
		anim = Instance.new("KeyframeSequence")
		anim.Name = name
		anim.Loop = a.loop == true
		anim.Priority = Enum.AnimationPriority[tostring(a.priority or "Action")] or Enum.AnimationPriority.Action
		local durV = Instance.new("NumberValue")
		durV.Name = "Duration"
		durV.Value = duration
		durV.Parent = anim
		anim.Parent = LIB
		anim:SetAttribute("RS_RigPath", pathOf(rig))
		anim:SetAttribute("Total_Prompt", tostring(a.prompt or ""))
		anim:SetAttribute("Total_Quality", tostring(a.quality or "balanced"))
		anim:SetAttribute("Total_Params", tostring(a.params or "{}"))
		anim:SetAttribute("Total_Engine", tostring(a.engine or ""))
		anim:SetAttribute("Total_Fps", tonumber(a.fps) or 30)
	end
	local written, markers = 0, 0
	for _, key in ipairs(keys) do
		local t = tonumber(key.t) or 0
		local kf = newKeyframe(anim, t)
		buildPoseTree(kf, rig, root)
		local style = Enum.PoseEasingStyle[tostring(key.e and key.e[1] or "CubicV2")] or Enum.PoseEasingStyle.CubicV2
		local dir = Enum.PoseEasingDirection[tostring(key.e and key.e[2] or "Out")] or Enum.PoseEasingDirection.Out
		local function visit(p)
			p.EasingStyle = style
			p.EasingDirection = dir
			for _, sub in ipairs(p:GetSubPoses()) do visit(sub) end
		end
		for _, pose in ipairs(kf:GetPoses()) do visit(pose) end
		for i, n in ipairs(names) do
			local b, v = byName[n], key.p and key.p[i]
			if b and v then
				local pose = findPose(kf, n)
				if pose then
					local R = CFrame.fromEulerAnglesYXZ(math.rad(tonumber(v[1]) or 0), math.rad(tonumber(v[2]) or 0), math.rad(tonumber(v[3]) or 0))
					local M = b.c0.Rotation
					local T = M:Inverse() * R * M
					local pos = Vector3.new(tonumber(v[4]) or 0, tonumber(v[5]) or 0, tonumber(v[6]) or 0)
					pose.CFrame = CFrame.new(M:VectorToObjectSpace(pos)) * T
					written = written + 1
				end
			end
		end
		for _, m in ipairs(key.m or {}) do
			local marker = Instance.new("KeyframeMarker")
			marker.Name = tostring(m[1] or "marker")
			marker.Value = tostring(m[2] or "")
			marker.Parent = kf
			markers = markers + 1
		end
	end
	local total = #anim:GetKeyframes()
	if a.more then
		anim:SetAttribute("Total_Chunked", true)
		return okdata({ name = name, keyframes = #keys, total = total, posesWritten = written, markers = markers, chunk = true },
			("chunk written: %d keyframes (%d so far) - more to come"):format(#keys, total))
	end
	anim:SetAttribute("Total_Chunked", nil)
	ACTIVE.Value = name
	LENGTH.Value = duration
	RIGREF.Value = pathOf(rig)
	local savedPath = nil
	if a.anim_saves ~= false then
		local okS, errS = pcall(function()
			local folder = rig:FindFirstChild("AnimSaves")
			if not folder then folder = Instance.new("Folder"); folder.Name = "AnimSaves"; folder.Parent = rig end
			local old = folder:FindFirstChild(name)
			if old then old:Destroy() end
			local copy = anim:Clone()
			copy.Parent = folder
			savedPath = pathOf(copy)
		end)
		if not okS then savedPath = nil end
	end
	local d = inspectAnim(anim)
	return okdata({ name = name, keyframes = total, posesWritten = written, markers = markers, bones = present, missingBones = missing, rig = rigEvidence(rig), animSaves = savedPath, inspect = d },
		("built '%s': %d keyframes, %d poses on %d/%d bones%s, %.2fs%s, pinned to rig '%s'%s"):format(
			name, total, written, present, #names, #missing > 0 and (" (not on this rig: " .. table.concat(missing, ", ") .. ")") or "", duration,
			anim.Loop and " looping" or "", rig.Name, savedPath and (" - also saved to " .. savedPath .. " for the Animation Editor") or ""))
end

-- ── 2.4.0 retarget: R15 <-> R6 with a canonical joint map ──────────────
-- R15 -> R6 composes the chain poses that collapse into one R6 limb
-- (UpperArm * LowerArm -> "Left Arm"; LowerTorso * UpperTorso -> Torso; the
-- hand / foot poses are dropped and reported). R6 -> R15 gives the R6 pose to
-- the upper joint of the chain and leaves the lower joints at identity. Pose
-- positions are scaled by the rig height ratio (or scale_positions).
local R15_CHAINS = {
	{ r6 = "Torso", r15 = { "LowerTorso", "UpperTorso" } },
	{ r6 = "Head", r15 = { "Head" } },
	{ r6 = "Left Arm", r15 = { "LeftUpperArm", "LeftLowerArm", "LeftHand" } },
	{ r6 = "Right Arm", r15 = { "RightUpperArm", "RightLowerArm", "RightHand" } },
	{ r6 = "Left Leg", r15 = { "LeftUpperLeg", "LeftLowerLeg", "LeftFoot" } },
	{ r6 = "Right Leg", r15 = { "RightUpperLeg", "RightLowerLeg", "RightFoot" } },
}
local CANON_TREE = {
	R6 = { HumanoidRootPart = { Torso = { Head = {}, ["Left Arm"] = {}, ["Right Arm"] = {}, ["Left Leg"] = {}, ["Right Leg"] = {} } } },
	R15 = { HumanoidRootPart = { LowerTorso = {
		UpperTorso = { Head = {}, LeftUpperArm = { LeftLowerArm = { LeftHand = {} } }, RightUpperArm = { RightLowerArm = { RightHand = {} } } },
		LeftUpperLeg = { LeftLowerLeg = { LeftFoot = {} } }, RightUpperLeg = { RightLowerLeg = { RightFoot = {} } },
	} } },
}
local function rigTypeOf(rig)
	if not rig then return nil end
	local h = rig:FindFirstChildOfClass("Humanoid")
	local okT, t = pcall(function() return h.RigType.Name end)
	if okT and (t == "R6" or t == "R15") then return t end
	if rig:FindFirstChild("UpperTorso") then return "R15" end
	if rig:FindFirstChild("Torso") then return "R6" end
	return nil
end
local function clipRigType(anim)
	local pinned = pinOf(anim)
	local t = rigTypeOf(pinned)
	if t then return t, pinned end
	local kfs = sortedKeyframes(anim)
	if #kfs == 0 then return nil, nil end
	if findPose(kfs[1], "UpperTorso") or findPose(kfs[1], "LeftUpperArm") then return "R15", nil end
	if findPose(kfs[1], "Torso") or findPose(kfs[1], "Left Arm") then return "R6", nil end
	return nil, nil
end
local function findRigOfType(t, path)
	if path and path ~= "" then
		local r = resolvePath(path)
		if not r or not r:IsA("Model") or not r:FindFirstChildOfClass("Humanoid") then error("rig_path '" .. tostring(path) .. "' is not a Model with a Humanoid") end
		if rigTypeOf(r) ~= t then error("rig_path '" .. tostring(path) .. "' is " .. tostring(rigTypeOf(r)) .. ", not " .. t) end
		return r
	end
	local best, bestScore = nil, -1
	for _, m in ipairs(workspace:GetDescendants()) do
		if m:IsA("Model") and m:FindFirstChildOfClass("Humanoid") and rigTypeOf(m) == t and rigRoot(m) then
			local score = 0
			for _, d in ipairs(m:GetDescendants()) do if d:IsA("Motor6D") then score = score + 1 end end
			if score > bestScore then bestScore = score; best = m end
		end
	end
	return best
end
local function rigHeight(rig)
	if not rig then return nil end
	local okE, size = pcall(function() return rig:GetExtentsSize() end)
	if okE and size and size.Y > 0 then return size.Y end
	return nil
end
local function scaledPose(cf, scale)
	if scale == 1 then return cf end
	local rot = cf - cf.Position
	return CFrame.new(cf.Position * scale) * rot
end

function api.retarget(a)
	local name = tostring(a.name or "")
	local src
	if name ~= "" then src = findAnim(name) else src = activeAnim() end
	if not src then return fail(name ~= "" and ("no animation named '" .. name .. "' in the library") or "no animation open - pass name or animation_open first") end
	local to = tostring(a.to or a.to_rig or ""):upper()
	if to ~= "R6" and to ~= "R15" then return fail("to must be R6 or R15") end
	local from, srcRig = clipRigType(src)
	if not from then return fail("cannot tell whether '" .. src.Name .. "' is R6 or R15 (no pinned rig and no recognisable bones)") end
	if from == to then return fail(("'%s' is already an %s animation - nothing to retarget"):format(src.Name, to)) end
	local target = findRigOfType(to, a.rig_path)
	local newName = tostring(a.save_as or "")
	if newName == "" then newName = src.Name .. "_" .. to end
	local existing = findAnim(newName)
	if existing and not a.overwrite then return fail(("an animation named '%s' ALREADY EXISTS - pass overwrite=true or another save_as"):format(newName)) end
	local scale = tonumber(a.scale_positions)
	local hs, ht = rigHeight(srcRig), rigHeight(target)
	if not scale then scale = (hs and ht and hs > 0) and (ht / hs) or 1 end
	scale = math.floor(scale * 1000 + 0.5) / 1000
	-- the bone map (optional overrides: {R15Bone = "R6 bone"} / {R6Bone = {"UpperArm",...}})
	local chains = {}
	for _, c in ipairs(R15_CHAINS) do chains[#chains + 1] = { r6 = c.r6, r15 = c.r15 } end
	if type(a.bone_map) == "table" then
		for k, v in pairs(a.bone_map) do
			if type(v) == "table" then chains[#chains + 1] = { r6 = tostring(k), r15 = v }
			else
				local placed = false
				for _, c in ipairs(chains) do if c.r6 == tostring(v) then c.r15[#c.r15 + 1] = tostring(k) placed = true end end
				if not placed then chains[#chains + 1] = { r6 = tostring(v), r15 = { tostring(k) } } end
			end
		end
	end
	local kfs = sortedKeyframes(src)
	if #kfs == 0 then return fail("'" .. src.Name .. "' has no keyframes") end
	if existing then existing:Destroy() end
	local dst = Instance.new("KeyframeSequence")
	dst.Name = newName
	dst.Loop = src.Loop
	dst.Priority = src.Priority
	local durV = src:FindFirstChild("Duration")
	local d0 = Instance.new("NumberValue") d0.Name = "Duration" d0.Value = durV and durV.Value or (kfs[#kfs].Time) d0.Parent = dst
	local mapped, unmapped, approx = {}, {}, {}
	local seenUnmapped = {}
	local function note(list, seen, v) if not seen[v] then seen[v] = true list[#list + 1] = v end end
	local seenMapped, seenApprox = {}, {}
	local function buildTree(parentPose, spec, lookup)
		for boneName, kids in pairs(spec) do
			local p = Instance.new("Pose")
			p.Name = boneName
			local cf, es, ed = lookup(boneName)
			if cf then p.CFrame = cf end
			if es then p.EasingStyle = es end
			if ed then p.EasingDirection = ed end
			if parentPose then parentPose:AddSubPose(p) end
			buildTree(p, kids, lookup)
			if not parentPose then return p end
		end
	end
	for _, kf in ipairs(kfs) do
		local nk = Instance.new("Keyframe")
		nk.Time = kf.Time
		nk.Name = kf.Name
		local srcPoses = {}
		local function collect(p) srcPoses[p.Name] = p for _, sub in ipairs(p:GetSubPoses()) do collect(sub) end end
		for _, p in ipairs(kf:GetPoses()) do collect(p) end
		local lookup
		if to == "R6" then
			lookup = function(bone)
				if bone == "HumanoidRootPart" then local sp = srcPoses.HumanoidRootPart if sp then note(mapped, seenMapped, "HumanoidRootPart -> HumanoidRootPart") return scaledPose(sp.CFrame, scale), sp.EasingStyle, sp.EasingDirection end return nil end
				for _, c in ipairs(chains) do
					if c.r6 == bone then
						local cf, es, ed, used = CFrame.new(), nil, nil, 0
						for i, r15b in ipairs(c.r15) do
							local sp = srcPoses[r15b]
							if sp then
								if i <= 2 then cf = cf * sp.CFrame used = used + 1 if not es then es, ed = sp.EasingStyle, sp.EasingDirection end
								elseif sp.CFrame ~= CFrame.new() then note(approx, seenApprox, r15b .. " pose dropped (R6 has no " .. r15b .. ")") end
							end
						end
						if used > 0 then
							note(mapped, seenMapped, table.concat(c.r15, "*", 1, math.min(2, #c.r15)) .. " -> " .. bone)
							if #c.r15 >= 2 then note(approx, seenApprox, bone .. " = " .. c.r15[1] .. " * " .. c.r15[2] .. " (composed)") end
							return scaledPose(cf, scale), es, ed
						end
						return nil
					end
				end
				return nil
			end
			for srcName in pairs(srcPoses) do
				local known = srcName == "HumanoidRootPart"
				for _, c in ipairs(chains) do for _, b in ipairs(c.r15) do if b == srcName then known = true end end end
				if not known then note(unmapped, seenUnmapped, srcName) end
			end
		else
			lookup = function(bone)
				if bone == "HumanoidRootPart" then local sp = srcPoses.HumanoidRootPart if sp then note(mapped, seenMapped, "HumanoidRootPart -> HumanoidRootPart") return scaledPose(sp.CFrame, scale), sp.EasingStyle, sp.EasingDirection end return nil end
				for _, c in ipairs(chains) do
					local sp = srcPoses[c.r6]
					if sp then
						if c.r15[1] == bone then
							note(mapped, seenMapped, c.r6 .. " -> " .. bone)
							if #c.r15 > 1 then note(approx, seenApprox, c.r6 .. " drives " .. bone .. " only (" .. table.concat(c.r15, ", ", 2) .. " stay identity)") end
							return scaledPose(sp.CFrame, scale), sp.EasingStyle, sp.EasingDirection
						end
						for i = 2, #c.r15 do if c.r15[i] == bone then return CFrame.new(), sp.EasingStyle, sp.EasingDirection end end
					end
				end
				return nil
			end
			for srcName in pairs(srcPoses) do
				local known = srcName == "HumanoidRootPart"
				for _, c in ipairs(chains) do if c.r6 == srcName then known = true end end
				if not known then note(unmapped, seenUnmapped, srcName) end
			end
		end
		local rootPose = buildTree(nil, CANON_TREE[to], lookup)
		nk:AddPose(rootPose)
		for _, m in ipairs(kf:GetMarkers()) do local mk = Instance.new("KeyframeMarker") mk.Name = m.Name mk.Value = m.Value mk.Parent = nk end
		nk.Parent = dst
	end
	dst:SetAttribute("Total_Retarget", from .. "->" .. to)
	dst:SetAttribute("Total_Source", src.Name)
	dst:SetAttribute("Total_Time", os.time())
	if target then dst:SetAttribute("RS_RigPath", pathOf(target)) end
	dst.Parent = LIB
	ACTIVE.Value = newName
	LENGTH.Value = d0.Value
	if target then RIGREF.Value = pathOf(target) end
	table.sort(mapped) table.sort(unmapped) table.sort(approx)
	local d = inspectAnim(dst)
	return okdata({ name = newName, source = src.Name, from = from, to = to, keyframes = #kfs, mapped = mapped, unmapped = unmapped, approximations = approx, scale_positions = scale, rig = target and target.Name or nil, pinned = target ~= nil, inspect = d },
		("retargeted '%s' (%s) -> '%s' (%s): %d keyframes, %d joint map(s), %d unmapped%s, positions x%s%s. %s. Now open: animation_preview to check it%s."):format(
			src.Name, from, newName, to, #kfs, #mapped, #unmapped, #unmapped > 0 and (" (" .. table.concat(unmapped, ", ") .. ")") or "", tostring(scale),
			#approx > 0 and (". Approximations: " .. table.concat(approx, "; ")) or "",
			target and ("Pinned to rig '" .. target.Name .. "'") or ("No " .. to .. " rig in Workspace - not pinned; add one (rig_build / animation_select_rig) before previewing"),
			to == "R6" and " - composed limbs lose the elbow / knee bend, retouch with animation_set_pose if needed" or ""))
end

-- ── 2.4.0 clip library: tags, notes, search, export, rename, delete ──────
local function clipMeta(c)
	local kfs = sortedKeyframes(c)
	local durV = c:FindFirstChild("Duration")
	local bones = 0
	if kfs[1] then local function cnt(p) bones = bones + 1 for _, s in ipairs(p:GetSubPoses()) do cnt(s) end end for _, p in ipairs(kfs[1]:GetPoses()) do cnt(p) end end
	local pinned = pinOf(c)
	local tags = {}
	for t in tostring(c:GetAttribute("Total_Tags") or ""):gmatch("[^,]+") do tags[#tags + 1] = t end
	return {
		name = c.Name, keyframes = #kfs, duration = math.max(durV and durV.Value or 0, kfs[#kfs] and kfs[#kfs].Time or 0), loop = c.Loop, priority = c.Priority.Name,
		bones = bones, rig = pinned and pinned.Name or nil, rig_type = clipRigType(c), tags = tags, notes = c:GetAttribute("Total_Notes"),
		retarget = c:GetAttribute("Total_Retarget"), source = c:GetAttribute("Total_Source"), updated = c:GetAttribute("Total_Time"), active = ACTIVE.Value == c.Name,
	}
end
function api.library(a)
	local op = tostring(a.lop or "list")
	local name = tostring(a.name or "")
	local function need()
		local c
		if name ~= "" then c = findAnim(name) else c = activeAnim() end
		if not c then error(name ~= "" and ("no animation named '" .. name .. "' in the library") or "name is required (or open an animation first)") end
		return c
	end
	if op == "list" or op == "search" then
		local q = tostring(a.query or ""):lower()
		local rigF = tostring(a.rig or ""):upper()
		local tagF = tostring(a.tag or ""):lower()
		local out = {}
		for _, c in ipairs(getAnims()) do
			if c:IsA("KeyframeSequence") then
				local m = clipMeta(c)
				local hay = (m.name .. " " .. table.concat(m.tags, " ") .. " " .. tostring(m.notes or "")):lower()
				local hit = (q == "" or hay:find(q, 1, true) ~= nil) and (rigF == "" or m.rig_type == rigF)
				if hit and tagF ~= "" then hit = false for _, t in ipairs(m.tags) do if t:lower() == tagF then hit = true end end end
				if hit then out[#out + 1] = m end
			end
		end
		table.sort(out, function(x, y) return x.name < y.name end)
		local lines = {}
		for _, m in ipairs(out) do lines[#lines + 1] = ("%s%s (%s, %d kf, %.2fs%s%s%s)"):format(m.name, m.active and "*" or "", m.rig_type or "?", m.keyframes, m.duration, m.loop and ", loop" or "", #m.tags > 0 and (", tags: " .. table.concat(m.tags, ",")) or "", m.rig and (", rig " .. m.rig) or "") end
		return okdata({ op = op, clips = out, count = #out, query = q ~= "" and q or nil }, ("%d clip(s)%s%s: %s"):format(#out, q ~= "" and (" matching '" .. q .. "'") or "", rigF ~= "" and (" for " .. rigF) or "", #out > 0 and table.concat(lines, "; ") or "library is empty - animation_generate or animation_create first"))
	elseif op == "tag" then
		local c = need()
		if a.tags ~= nil then
			local list = {}
			if type(a.tags) == "table" then for _, t in ipairs(a.tags) do if tostring(t) ~= "" then list[#list + 1] = tostring(t) end end
			else for t in tostring(a.tags):gmatch("[^,]+") do list[#list + 1] = (t:gsub("^%s+", ""):gsub("%s+$", "")) end end
			c:SetAttribute("Total_Tags", table.concat(list, ","))
		end
		if a.notes ~= nil then c:SetAttribute("Total_Notes", tostring(a.notes)) end
		c:SetAttribute("Total_Time", os.time())
		local m = clipMeta(c)
		return okdata(m, ("tagged '%s': [%s]%s"):format(c.Name, table.concat(m.tags, ", "), m.notes and (" - " .. m.notes) or ""))
	elseif op == "export" then
		local c = need()
		local full = inspectAnim(c)
		local allKfs = {}
		for _, kf in ipairs(sortedKeyframes(c)) do
			local bonesOut = {}
			local function collect(p) bonesOut[p.Name] = poseToTable(p) for _, sub in ipairs(p:GetSubPoses()) do collect(sub) end end
			for _, p in ipairs(kf:GetPoses()) do collect(p) end
			local markersOut = {}
			for _, mk in ipairs(kf:GetMarkers()) do markersOut[#markersOut + 1] = { name = mk.Name, value = mk.Value } end
			allKfs[#allKfs + 1] = { t = kf.Time, bones = bonesOut, markers = markersOut }
		end
		full.keyframes = allKfs full.truncated = false
		full.meta = clipMeta(c)
		return okdata(full, ("exported '%s': %d keyframes x %d bones as JSON (degrees YXZ, positions in studs) - feed it to animation_build / keep it in a skill; animation_export_rbxmx for a Studio-importable file"):format(c.Name, #allKfs, #full.bones))
	elseif op == "rename" then
		local c = need()
		local newName = tostring(a.new_name or "")
		if newName == "" then return fail("new_name is required") end
		if findAnim(newName) then return fail(("an animation named '%s' already exists"):format(newName)) end
		local old = c.Name
		c.Name = newName
		if ACTIVE.Value == old then ACTIVE.Value = newName end
		c:SetAttribute("Total_Time", os.time())
		return okdata(clipMeta(c), ("renamed '%s' -> '%s'"):format(old, newName))
	elseif op == "delete" then
		local c = need()
		local old = c.Name
		if ACTIVE.Value == old then stopPreview(true) ACTIVE.Value = "" end
		c:Destroy()
		return okdata({ deleted = old }, ("deleted '%s' from the library (Ctrl+Z restores it)"):format(old))
	end
	return fail("unknown library op '" .. op .. "' - use list, search, tag, export, rename or delete")
end

local dispatch = {
	select_rig = api.select_rig, clear_rig_selection = api.clear_rig_selection,
	create = api.create, open = api.open, list = api.list,
	import = api.import, rebuild = api.rebuild,
	set_length = api.set_length, set_settings = api.set_settings,
	set_pose = function(a) return api.keyframe(a, true) end,
	add_keyframe = function(a) return api.keyframe(a, true) end,
	update_keyframe = function(a) return api.keyframe(a, false) end,
	delete_keyframe = api.delete_keyframe, move_keyframe = api.move_keyframe,
	clone_keyframe = api.clone_keyframe, set_easing = api.set_easing,
	set_marker = api.set_marker, delete_marker = api.delete_marker, inspect = api.inspect,
	reset = api.resets, stop_preview = api.resets, close = api.resets, apply = api.apply,
	preview = api.preview, simulate = api.simulate, test = api.test,
	map_axes = api.map_axes,
	rig_info = api.rig_info, build = api.build,
	retarget = api.retarget, library = api.library,
}

local args = jdec([==[__ARGS_JSON__]==])
if not args then return fail("bad args") end
local ok2, res = pcall(function()
	local fn = dispatch[args.op]
	if not fn then return fail("unknown animation op: " .. tostring(args.op)) end
	return fn(args)
end)
if not ok2 then return fail("animation error: " .. tostring(res)) end
return res
`;

// Virtual animation command definitions shown to the model via list_commands.
const ANIM_COMMANDS = [
  // ── 1.52.0 ANIMATION ENGINE (src/core/animengine.js): prompt → validated clip → built in ONE call ──
  {
    name: "animation_generate",
    description: "FASTEST PATH for any animation: describe the motion in words and the engine plans the stages (anticipation → action → follow-through → recovery), authors every keyframe on the real rig (R6 / R15 / custom Motor6D rigs detected in Studio), applies arcs, impact holds, secondary motion, weight and loop closure, validates joint limits / discontinuities / loop seams, BUILDS the KeyframeSequence in ServerStorage.RobloxScript.AnimLib (also copied to rig.AnimSaves for the Animation Editor) and returns a quality report. Idle / walk / run / swim / climb / jump / land / crouch / sit, sword / punch / kick / thrust combos with spins and finishers, dodge, block, spell cast, transformation, emotes (wave, cheer, dance, point, clap, laugh, bow). Then animation_preview; adjust with animation_refine.",
    params: {
      prompt: { type: "string", req: true, desc: "the motion in words - any motion (1.55): 'drink a potion', 'open a heavy door', 'dig', 'play guitar', 'tired old man walk', 'wave while walking', 'salute then bow then sit', 'raise the left arm', 'knock 3 times', moods (drunk, proud, scared), plus the classics ('extremely fluid anime sword combo with anticipation, rapid strikes, a spinning finisher and a dramatic landing'); style, intensity, duration, loop, 'R6' all understood" },
      name: { type: "string", req: false, desc: "clip name (default derived from the prompt)" },
      quality: { type: "string", req: false, desc: "fast | balanced (default) | high | cinematic - key density, breakdowns, follow-through, fps" },
      duration: { type: "number", req: false, desc: "seconds (default chosen from the motion)" },
      loop: { type: "boolean", req: false, desc: "force looping on/off (cycles and idles loop by default)" },
      fps: { type: "number", req: false, desc: "key grid (24 / 30 / 60; default from quality)" },
      variations: { type: "number", req: false, desc: "1-6: generate that many DISTINCT takes (_v1.._vN) of the same prompt - different persona (lead side, fidget, arm rest, easing, tempo) and choreography; each is fingerprinted so none repeats" },
      mirror: { type: "boolean", req: false, desc: "swap left/right (left-handed version); 'mirror' / 'left-handed' in the prompt does the same" },
      root_motion: { type: "boolean", req: false, desc: "let the HumanoidRootPart travel inside the clip (walk/run/dash/slide) - 'with root motion' in the prompt does the same" },
    },
  },
  {
    name: "animation_refine",
    description: "Adjust the last generated clip (or {name}) from plain feedback and rebuild it: 'make it slow' / 'make it fast', 'a bit slower', 'much faster', 'half speed', '2x', '30% slower', 'too fast', 'slow motion', 'fluent' (smoother + longer blends between chained parts), 'faster attacks', 'more / less anticipation', 'heavier / lighter landing', 'exaggerate', 'subtle', 'smoother', 'longer', 'shorter', 'loop', 'new take' / 'variation', 'mirror' / 'left-handed', 'root motion' / 'in place', 'snappier' / 'softer' / 'mechanical' / 'bouncy' / 'elastic' / 'organic' easing, 'more follow-through' (1.64 overlap: elbows / wrists / head / knees / ankles trail by N frames), 'hold the impact 4 frames' (moving holds), 'add a spin', 'add a landing', '2.5 seconds'. Returns before → after numbers and the new validation.",
    params: { feedback: { type: "string", req: true, desc: "what to change, in words" }, name: { type: "string", req: false, desc: "clip to refine (default: the last generated)" } },
  },
  {
    name: "animation_sequence",
    description: "Multi-stage combat / cinematic sequences: one combined clip with stage markers PLUS one clip per stage (ready, each strike, spin, air, landing...) retimed to start at 0, all built in Studio, with blend / cancel-window guidance for a combat controller. Use for '8 stage sword combo' style requests.",
    params: { prompt: { type: "string", req: true, desc: "the whole sequence in words" }, name: { type: "string", req: false }, quality: { type: "string", req: false, desc: "fast | balanced | high | cinematic" }, duration: { type: "number", req: false } },
  },
  {
    name: "animation_validate",
    description: "Objective checks on a generated clip without touching Studio: joint limits, abrupt transitions, root speed, timing gaps, loop seam, invalid numbers - with a 0-100 score. Not a visual review: still animation_preview / animation_simulate {all:true}.",
    params: { name: { type: "string", req: false, desc: "clip (default: the last generated)" } },
  },
  {
    name: "animation_export_rbxmx",
    description: "Save a generated clip as a Roblox .rbxmx file (KeyframeSequence + nested Pose tree, exact CFrames) to the user's downloads - works WITHOUT Studio. For a Studio-side export of any KeyframeSequence use animation_export; publishing is animation_publish (asks the user).",
    params: { name: { type: "string", req: false, desc: "clip (default: the last generated)" } },
  },
  {
    name: "animation_polish",
    description: "1.54 post passes on an existing clip WITHOUT regenerating (manual edits survive): smooth:true (switches the clip to C1 spline curves + relaxes the keys, impacts/holds kept; spline clips reach Studio baked per frame), plant_feet:true (lowest foot on the ground at every key, soles flattened - fixes floating / sliding), simplify:true (drop redundant keys), reverse:true, bake:true (one key per frame), cycle_offset:<s> (move a loop's start). Rebuilds in Studio.",
    params: { name: { type: "string", req: false, desc: "clip (default: the last generated)" }, smooth: { type: "boolean", req: false }, plant_feet: { type: "boolean", req: false }, simplify: { type: "boolean", req: false }, reverse: { type: "boolean", req: false }, bake: { type: "boolean", req: false }, cycle_offset: { type: "number", req: false, desc: "seconds" } },
  },
  {
    name: "animation_set",
    description: "1.56 SEVERAL DIFFERENT animations in one go (idle + walk + run + jump + attack + death...) as SEPARATE KeyframeSequences that belong to ONE character: shared persona (lead side, arm rest, tempo, easing), same rig / fps / quality, idle on priority Idle, cycles on Movement, actions on Action, plus a compatibility report (stance distance between clips, root pops, loop flags) and a blend plan (fade time per transition). NEVER merge different animations into one clip - use this (or one animation_generate per animation; the session keeps the same character automatically). animation_sequence is only for ONE chained move (combo, 'A then B').",
    params: { prompts: { type: "array", req: false, desc: "one entry per animation, e.g. [\"idle\", \"walk\", \"run\", \"jump\"] (each may carry style / mood words)" }, prompt: { type: "string", req: false, desc: "alternative: 'idle, walk, run and jump animations for my zombie npc' (split automatically; a trailing 'for my X' becomes the name prefix and style)" }, prefix: { type: "string", req: false, desc: "name prefix, e.g. Knight" }, quality: { type: "string", req: false, desc: "fast | balanced | high | cinematic" }, new_character: { type: "boolean", req: false, desc: "true = do not reuse the session's character seed" } },
  },
  {
    name: "animation_compatibility",
    description: "1.56 check how the session's clips fit together as one character: shared persona, rig, fps, priorities, loop flags, stance distance + root height pop between the idle and every other clip, with the AnimationTrack:Play(fade) to use per transition. Run after refining clips of a set.",
    params: { names: { type: "array", req: false, desc: "clip names (default: every clip of this session)" } },
  },
  {
    name: "animation_layer",
    description: "1.54 NLA-style layering: legs + root from {base} (default: last clip), upper body (waist, head, arms) from {upper} - walk + wave, run + aim, idle + talk. fit default 'auto' keeps BOTH tempos (a looping base is tiled under a longer upper clip, a one-shot base holds its last pose - nothing speeds up); 'stretch' retimes the upper clip to the base duration (changes its speed), 'loop' repeats it at its own period, 'hold' plays it once; weight 0-1 blends. Both clips must exist in this session (animation_generate each first). Builds the combined clip in Studio.",
    params: { upper: { type: "string", req: true, desc: "clip name whose upper body goes on top" }, base: { type: "string", req: false, desc: "clip name for legs + root (default: last)" }, fit: { type: "string", req: false, desc: "auto (keep tempo, default) | stretch | loop | hold" }, weight: { type: "number", req: false, desc: "0-1, default 1" }, name: { type: "string", req: false } },
  },
  {
    name: "animation_select_rig",
    description: "Explicitly choose the rig that new animations should use. Use this in places with multiple dummies or characters; it also pins an already-open animation to the selected rig.",
    params: { path: { type: "string", req: true, desc: "dotted Model path, e.g. Workspace.R15" } }
  },
  {
    name: "animation_clear_rig_selection",
    description: "Clear the explicit rig choice so future animations use fresh automatic rig detection.",
    params: {}
  },
  {
    name: "animation_create",
    description: "Create a new Roblox animation (editable keyframe data) from the rig found in the place. R6 and R15 supported, joints via Motor6D or AnimationConstraint (Avatar Joint Upgrade) chains. FAILS if the name is already in the library unless overwrite=true is passed (protects existing animations from being wiped by accident).",
    params: {
      name: { type: "string", req: true, desc: "animation name, e.g. \"wave\"" },
      duration: { type: "number", req: false, desc: "total length in seconds (default 1)" },
      overwrite: { type: "boolean", req: false, desc: "default false - set true to replace an existing animation with this name" }
    }
  },
  {
    name: "animation_open",
    description: "Open (make active) an animation and return its keyframes + bone list. Pins the animation to the rig with the most joints if it was not pinned; if the stored pose tree does not match the rig's bones (e.g. old R6 names on an R15 rig) the tree is auto-rebuilt - check the reply and the 'rig' field.",
    params: { name: { type: "string", req: true, desc: "animation name" } }
  },
  {
    name: "animation_import",
    description: "Copy an existing KeyframeSequence from anywhere in the DataModel (e.g. 'Workspace.R15.AnimSaves.Run') into the library and open it, so it can be inspected, edited and previewed like a tool-created animation. Pinned to the current rig.",
    params: {
      path: { type: "string", req: true, desc: "dotted path of the KeyframeSequence, e.g. Workspace.R15.AnimSaves.Run" },
      name: { type: "string", req: false, desc: "library name (default = the sequence's own name)" },
      overwrite: { type: "boolean", req: false, desc: "default false - set true to replace an existing library animation with this name" }
    }
  },
  {
    name: "animation_rebuild",
    description: "Rebuild the active animation's pose trees onto its pinned rig: keyframe times kept, poses preserved for bones that still exist, poses not on the rig removed, missing bones added as rest poses. Use when the bone names do not match the rig (e.g. an R6 animation rebuilt for the R15 rig).",
    params: {}
  },
  {
    name: "animation_set_length",
    description: "Change the total duration of the active animation in seconds.",
    params: { duration: { type: "number", req: true, desc: "length in seconds (> 0)" } }
  },
  {
    name: "animation_set_settings",
    description: "Set native Roblox animation settings on the active KeyframeSequence. The settings are retained by Studio's Animation Editor.",
    params: {
      loop: { type: "boolean", req: false, desc: "whether playback loops" },
      priority: { type: "string", req: false, desc: "Core, Idle, Movement, Action, Action2, Action3, or Action4" }
    }
  },
  {
    name: "animation_inspect",
    description: "Return the full keyframe data of the active animation as JSON: every keyframe time plus each bone's position (studs) and rotation (degrees). Use this to reason about poses, spacing, arcs and symmetry without capture.",
    params: {}
  },
  {
    name: "animation_set_pose",
    description: "Set the pose of one or more bones at an EXACT keyframe timestamp. Creates the keyframe if it does not exist yet.",
    params: {
      t: { type: "number", req: true, desc: "keyframe timestamp in seconds" },
      poses: { type: "array", req: true, desc: "each item: {bone:\"<name>\", pos:[x,y,z]?, rot:[x,y,z]?} - rotation in DEGREES (YXZ convention), position in studs" }
    }
  },
  {
    name: "animation_add_keyframe",
    description: "Insert a new keyframe (default/rest pose) at timestamp t.",
    params: { t: { type: "number", req: true, desc: "timestamp in seconds" } }
  },
  {
    name: "animation_update_keyframe",
    description: "Update the pose of existing keyframe(s) at timestamp t (fails if no keyframe exists there).",
    params: {
      t: { type: "number", req: true, desc: "existing keyframe timestamp" },
      poses: { type: "array", req: true, desc: "same format as animation_set_pose" }
    }
  },
  {
    name: "animation_delete_keyframe",
    description: "Delete the keyframe at timestamp t.",
    params: { t: { type: "number", req: true, desc: "timestamp in seconds" } }
  },
  {
    name: "animation_move_keyframe",
    description: "Move a keyframe from from_t to to_t (no timestamps collide).",
    params: {
      from_t: { type: "number", req: true, desc: "current timestamp" },
      to_t: { type: "number", req: true, desc: "new timestamp" }
    }
  },
  {
    name: "animation_clone_keyframe",
    description: "Duplicate a complete keyframe, including every pose, easing choice, and marker, to a new timestamp.",
    params: {
      from_t: { type: "number", req: true, desc: "source keyframe timestamp" },
      to_t: { type: "number", req: true, desc: "new keyframe timestamp" }
    }
  },
  {
    name: "animation_set_easing",
    description: "Set native Roblox pose easing for the transition from this keyframe to the next. Omitting bones applies it to every pose in the keyframe; the viewport preview uses the same setting.",
    params: {
      t: { type: "number", req: true, desc: "keyframe timestamp" },
      style: { type: "string", req: true, desc: "Linear, Constant, Elastic, CubicV2, or Bounce" },
      direction: { type: "string", req: false, desc: "In, Out, or InOut (default Out)" },
      bones: { type: "array", req: false, desc: "optional list of exact bone names" }
    }
  },
  {
    name: "animation_set_marker",
    description: "Add or update a named KeyframeMarker. Markers are stored in the actual KeyframeSequence and can drive AnimationTrack marker signals after publishing.",
    params: {
      t: { type: "number", req: true, desc: "existing keyframe timestamp" },
      name: { type: "string", req: true, desc: "marker name" },
      value: { type: "string", req: false, desc: "optional marker payload" }
    }
  },
  {
    name: "animation_delete_marker",
    description: "Remove a named KeyframeMarker from an existing keyframe.",
    params: {
      t: { type: "number", req: true, desc: "existing keyframe timestamp" },
      name: { type: "string", req: true, desc: "marker name" }
    }
  },
  {
    name: "animation_preview",
    description: "Play the active animation directly on its pinned rig in the Studio viewport (Motor6D rigs via joint transforms; AnimationConstraint/BallSocketConstraint rigs by writing the joint chain onto the parts). Real-time and frame-rate independent (1.56), honours native pose easing, looping clips play 3 cycles by default; stops automatically.",
    params: { duration: { type: "number", req: false, desc: "clip length in seconds (default = animation length)" }, loop: { type: "boolean", req: false, desc: "repeat (default = the clip's Loop flag)" }, cycles: { type: "number", req: false, desc: "how many loops to play when looping (default 3, max 20)" }, speed: { type: "number", req: false, desc: "playback speed multiplier (default 1)" } }
  },
  {
    name: "animation_simulate",
    description:
      "Simulate the active animation AT EXACTLY time t (seconds): poses the rig in Studio at that moment and returns the WORLD position + rotation of every bone plus metrics (root height, hand mirror-symmetry deviation in studs, ground height, foot clearances: planted/FLOATING/CLIPPING THROUGH FLOOR). " +
      "Alternatively pass all=true for the QA SWEEP: every keyframe (start, middle, end, all in between) is checked in ONE call and the verdict lists every frame with floating feet, floor clipping or asymmetric hands - FIX all flagged frames and re-run until the verdict says CLEAN, BEFORE previewing. " +
      "Walking QA: each foot must read PLANTED in its stance frames, arms swing opposite to the legs, rootY bobs smoothly. Never declare an animation done after a non-CLEAN sweep.",
    params: {
      t: { type: "number", req: false, desc: "timestamp to simulate, e.g. 0, 0.5 (omit when using all=true)" },
      all: { type: "boolean", req: false, desc: "true = QA sweep over ALL keyframes (start/mid/end), return verdict" }
    }
  },
  {
    name: "animation_map_axes",
    description:
      "MEASURE the rig's real axis behavior before authoring directional motion (walks, runs, jumps). For every joint it rotates the joint on its local X, Y and Z axes one at a time (PURE MATH - rig untouched, works for Motor6D and AnimationConstraint rigs in or out of Edit mode) and measures the WORLD direction the limb actually swings, in the root's own frame: forward/back, up/down or left/right, including which SIGN (+/-) of each rotation goes which way. Walk prerequisite: run this FIRST, read each limb's axis card (e.g. LeftUpperLeg X=forward/back), then author the walk by rotating the LEG'S forward/back axis for the step and the ARM'S forward/back axis for the counter-swing - never guess an axis.",
    params: {
      filter: { type: "array", req: false, desc: "optional list of bone names to map, e.g. [\"LeftUpperLeg\",\"RightUpperLeg\"] (default: all joints)" },
      angle: { type: "number", req: false, desc: "probe angle in degrees per axis (default 30)" }
    }
  },
  {
    name: "animation_test",
    description:
      "Create a 1s 'RS_Test_Idle' test animation (idle, arms raised at the sides at t=0.5, idle) AND automatically MEASURE the rig's " +
      "rotation-sign convention: it applies +95 roll to the right arm and reads which way the arm really moved. The reply reports " +
      "'standard' (use rot values as given) or 'MIRRORED' (flip the sign of EVERY rot value you send on this rig). Run this once per rig, " +
      "before the first real poses. If it says it could not measure, verify directions with preview + user feedback instead.",
    params: {},
  },
  {
    name: "animation_stop_preview",
    description: "Stop the preview loop and reset the rig to its rest pose.",
    params: {}
  },
  {
    name: "animation_close",
    description: "Close the session: stop any preview loop and reset the rig to its rest pose. Use this for cleanup when you are done with an animation.",
    params: {}
  },
  {
    name: "animation_retarget",
    description: "2.4.0: convert a library clip between R15 and R6 with the canonical joint map (R15->R6 composes UpperArm*LowerArm into 'Left Arm', LowerTorso*UpperTorso into Torso and drops hand / foot poses; R6->R15 drives the upper joint of each chain and leaves the lower ones at identity). Copies easing, markers, Loop and Priority, scales positions by the rig height ratio, pins the new clip to the best matching rig in Workspace and opens it. Reports mapped / unmapped joints and every approximation.",
    params: {
      to: { type: "string", req: true, desc: "target rig: R6 or R15" },
      name: { type: "string", req: false, desc: "source clip (default: the open animation)" },
      save_as: { type: "string", req: false, desc: "new clip name (default <name>_<to>)" },
      rig_path: { type: "string", req: false, desc: "pin to this rig Model instead of auto-detecting one of the target type" },
      scale_positions: { type: "number", req: false, desc: "position multiplier (default: target height / source height)" },
      bone_map: { type: "object", req: false, desc: "extra joints, e.g. {\"Tail\":\"Torso\"} (R15 bone -> R6 bone) or {\"Torso\":[\"LowerTorso\",\"UpperTorso\"]}" },
      overwrite: { type: "boolean", req: false, desc: "replace an existing clip of the same name" }
    }
  },
  {
    name: "animation_library",
    description: "2.4.0: manage the clip library in ServerStorage: list every KeyframeSequence with rig type, keyframes, duration, loop, tags and pinned rig; search by name / tag / notes / rig; tag {name, tags, notes}; export {name} as portable JSON (all keyframes, degrees YXZ); rename {name, new_name}; delete {name}. Tags and notes live on the clip as attributes, so they survive save / reopen.",
    params: {
      op: { type: "string", req: false, desc: "list | search | tag | export | rename | delete (default list)" },
      name: { type: "string", req: false, desc: "clip name (default: the open animation for tag / export)" },
      query: { type: "string", req: false, desc: "search text (name, tags, notes)" },
      rig: { type: "string", req: false, desc: "filter: R6 or R15" },
      tag: { type: "string", req: false, desc: "filter: exact tag" },
      tags: { type: "array", req: false, desc: "tag op: tags to set (replaces)" },
      notes: { type: "string", req: false, desc: "tag op: free-text notes" },
      new_name: { type: "string", req: false, desc: "rename op" }
    }
  }
];

// Normalize the model's poses argument into [{bone,pos,rot}] for Luau.
function normalizePoses(arg) {
  if (!arg) return { poses: null };
  const out = [];
  const push = (bone, p) => {
    if (bone === undefined) return;
    const e = { bone: String(bone) };
    const vector = (v) => Array.isArray(v) && v.length === 3
      ? v.map(Number).every(Number.isFinite) ? v.map(Number) : null
      : null;
    const pos = vector(p.pos);
    const rot = vector(p.rot);
    if (pos) e.pos = pos;
    if (rot) e.rot = rot;
    if (!pos && !rot) return;
    out.push(e);
  };
  if (Array.isArray(arg)) {
    for (const item of arg) push(item.bone, item);
  } else if (arg && typeof arg === "object") {
    if (arg.bone !== undefined) push(arg.bone, arg);
    const bones = arg.bones;
    if (bones && typeof bones === "object") {
      if (Array.isArray(bones)) {
        for (const item of bones) push(item.bone, item);
      } else {
        for (const [bone, p] of Object.entries(bones)) push(bone, p || {});
      }
    }
  }
  return out.length ? { poses: out } : { poses: null };
}

function buildLuau(op, args) {
  args = args || {};
  const base = { op };
  const nonNegativeTime = (value) => Number.isFinite(Number(value)) && Number(value) >= 0;
  const positiveTime = (value) => Number.isFinite(Number(value)) && Number(value) > 0;
  // animation_create passes duration; keep everything else explicit.
  if (op === "select_rig") {
    if (!args.path || !String(args.path).trim()) return { err: "ERROR calling 'animation_select_rig': the rig Model path is required." };
    base.path = String(args.path).trim();
  } else if (op === "create") {
    if (!args.name || !String(args.name).trim()) return { err: "ERROR calling 'animation_create': the 'name' parameter is required. Call list_commands to see the parameters." };
    base.name = String(args.name).trim();
    const dur = Number(args.duration);
    if (args.duration !== undefined && !positiveTime(args.duration)) return { err: "ERROR calling 'animation_create': 'duration' must be a positive finite number of seconds." };
    if (dur > 0) base.duration = dur;
    if (args.overwrite === true) base.overwrite = true;
  } else if (op === "open") {
    if (!args.name || !String(args.name).trim()) return { err: "ERROR calling 'animation_open': the 'name' parameter is required." };
    base.name = String(args.name).trim();
  } else if (op === "set_length") {
    const dur = Number(args.duration);
    if (!positiveTime(args.duration)) return { err: "ERROR calling 'animation_set_length': 'duration' must be a positive finite number of seconds." };
    base.duration = dur;
  } else if (op === "set_settings") {
    if (args.loop === undefined && args.priority === undefined) return { err: "ERROR calling 'animation_set_settings': provide 'loop' and/or 'priority'." };
    if (args.loop !== undefined) {
      if (typeof args.loop !== "boolean") return { err: "ERROR calling 'animation_set_settings': 'loop' must be true or false." };
      base.loop = args.loop;
    }
    if (args.priority !== undefined) {
      const priority = String(args.priority);
      if (!new Set(["Core", "Idle", "Movement", "Action", "Action2", "Action3", "Action4"]).has(priority)) {
        return { err: "ERROR calling 'animation_set_settings': use a valid priority (Core, Idle, Movement, Action, Action2, Action3, or Action4)." };
      }
      base.priority = priority;
    }
  } else if (op === "set_pose" || op === "update_keyframe") {
    const t = Number(args.t);
    if (args.t === undefined || !nonNegativeTime(args.t)) return { err: `ERROR calling 'animation_${op}': 't' (seconds) is required and must be a finite value >= 0.` };
    const poses = normalizePoses(args.poses !== undefined ? args.poses : args.pose);
    if (!poses.poses) return { err: `ERROR calling 'animation_${op}': provide 'poses' as [{bone:\"...\", pos:[x,y,z], rot:[x,y,z]}] (deg) - inspect an animation first for the exact bone names.` };
    base.t = t;
    base.poses = poses.poses;
    if (op === "set_pose" || op === "add_keyframe") base.upsert = true;
  } else if (op === "add_keyframe") {
    const t = Number(args.t);
    if (args.t === undefined || !nonNegativeTime(args.t)) return { err: "ERROR calling 'animation_add_keyframe': 't' (seconds) is required and must be a finite value >= 0." };
    base.t = t;
    base.upsert = true;
  } else if (op === "import") {
    if (!args.path || !String(args.path).trim()) return { err: "ERROR calling 'animation_import': the 'path' parameter is required (e.g. Workspace.R15.AnimSaves.Run)." };
    base.path = String(args.path).trim();
    if (args.name && String(args.name).trim()) base.name = String(args.name).trim();
    if (args.overwrite === true) base.overwrite = true;
  } else if (op === "simulate") {
    const t = Number(args.t);
    if (args.t !== undefined && !nonNegativeTime(args.t)) return { err: "ERROR calling 'animation_simulate': 't' must be a finite value >= 0 seconds." };
    if (t >= 0) base.t = t;
    if (args.all === true) base.all = true;
  } else if (op === "delete_keyframe") {
    const t = Number(args.t);
    if (args.t === undefined || !nonNegativeTime(args.t)) return { err: "ERROR calling 'animation_delete_keyframe': 't' (seconds) is required and must be a finite value >= 0." };
    base.t = t;
  } else if (op === "move_keyframe") {
    const f = Number(args.from_t);
    const to = Number(args.to_t);
    if (args.from_t === undefined || !nonNegativeTime(args.from_t) || args.to_t === undefined || !nonNegativeTime(args.to_t)) {
      return { err: "ERROR calling 'animation_move_keyframe': 'from_t' and 'to_t' must be finite seconds >= 0." };
    }
    base.from_t = f;
    base.to_t = to;
  } else if (op === "preview") {
    const dur = Number(args.duration);
    if (args.duration !== undefined && !positiveTime(args.duration)) return { err: "ERROR calling 'animation_preview': 'duration' must be a positive finite number." };
    if (dur > 0) base.duration = dur;
    if (typeof args.loop === "boolean") base.loop = args.loop;
    if (Number(args.cycles) > 0) base.cycles = Math.floor(Number(args.cycles));
    if (Number(args.speed) > 0) base.speed = Number(args.speed);
  } else if (op === "apply") {
    const t = Number(args.t);
    if (args.t === undefined || !nonNegativeTime(args.t)) return { err: "ERROR: 't' (seconds) is required and must be a finite value >= 0." };
    base.t = t;
  } else if (op === "clone_keyframe") {
    if (!nonNegativeTime(args.from_t) || !nonNegativeTime(args.to_t)) return { err: "ERROR calling 'animation_clone_keyframe': 'from_t' and 'to_t' must be finite seconds >= 0." };
    base.from_t = Number(args.from_t);
    base.to_t = Number(args.to_t);
  } else if (op === "set_easing") {
    if (!nonNegativeTime(args.t)) return { err: "ERROR calling 'animation_set_easing': 't' must be finite seconds >= 0." };
    const style = String(args.style || "");
    const direction = String(args.direction || "Out");
    if (!new Set(["Linear", "Constant", "Elastic", "CubicV2", "Bounce"]).has(style)) return { err: "ERROR calling 'animation_set_easing': style must be Linear, Constant, Elastic, CubicV2, or Bounce." };
    if (!new Set(["In", "Out", "InOut"]).has(direction)) return { err: "ERROR calling 'animation_set_easing': direction must be In, Out, or InOut." };
    if (args.bones !== undefined && (!Array.isArray(args.bones) || args.bones.some((bone) => !String(bone).trim()))) return { err: "ERROR calling 'animation_set_easing': 'bones' must be an array of non-empty bone names." };
    base.t = Number(args.t);
    base.style = style;
    base.direction = direction;
    if (Array.isArray(args.bones)) base.bones = args.bones.map((bone) => String(bone).trim());
  } else if (op === "set_marker" || op === "delete_marker") {
    if (!nonNegativeTime(args.t)) return { err: `ERROR calling 'animation_${op}': 't' must be finite seconds >= 0.` };
    if (!args.name || !String(args.name).trim()) return { err: `ERROR calling 'animation_${op}': marker 'name' is required.` };
    base.t = Number(args.t);
    base.name = String(args.name).trim();
    if (op === "set_marker" && args.value !== undefined) base.value = String(args.value);
  } else if (op === "rig_info" || op === "build") {
    // 1.52.0 engine ops: the JS engine already validated the payload.
    for (const k of Object.keys(args)) if (!/^_total/.test(k) && k !== "op") base[k] = args[k];
    if (op === "build") {
      if (!base.name || !String(base.name).trim()) return { err: "ERROR calling 'animation_build': 'name' is required." };
      if (!Array.isArray(base.keys) || !base.keys.length) return { err: "ERROR calling 'animation_build': the clip has no keyframes." };
      if (!Array.isArray(base.bones) || !base.bones.length) return { err: "ERROR calling 'animation_build': no bones to write." };
    }
  } else if (op === "retarget") {
    const to = String(args.to || args.to_rig || "").toUpperCase();
    if (to !== "R6" && to !== "R15") return { err: "ERROR calling 'animation_retarget': 'to' must be R6 or R15." };
    base.to = to;
    if (args.name !== undefined && String(args.name).trim()) base.name = String(args.name).trim();
    if (args.save_as !== undefined && String(args.save_as).trim()) base.save_as = String(args.save_as).trim();
    if (args.rig_path !== undefined && String(args.rig_path).trim()) base.rig_path = String(args.rig_path).trim();
    if (args.scale_positions !== undefined) {
      const sc = Number(args.scale_positions);
      if (!(Number.isFinite(sc) && sc > 0)) return { err: "ERROR calling 'animation_retarget': 'scale_positions' must be a positive number (1 = keep positions)." };
      base.scale_positions = sc;
    }
    if (args.bone_map !== undefined) {
      if (!args.bone_map || typeof args.bone_map !== "object" || Array.isArray(args.bone_map)) return { err: "ERROR calling 'animation_retarget': 'bone_map' must be an object {R15Bone: 'R6 bone'}." };
      base.bone_map = args.bone_map;
    }
    if (args.overwrite === true) base.overwrite = true;
  } else if (op === "library") {
    const lop = String(args.op || "list");
    if (!new Set(["list", "search", "tag", "export", "rename", "delete"]).has(lop)) return { err: "ERROR calling 'animation_library': op must be list, search, tag, export, rename or delete." };
    base.op = "library";
    base.lop = lop;
    if (args.name !== undefined && String(args.name).trim()) base.name = String(args.name).trim();
    if ((lop === "rename" || lop === "delete") && !base.name) return { err: `ERROR calling 'animation_library': 'name' is required for ${lop}.` };
    if (lop === "rename") {
      if (!args.new_name || !String(args.new_name).trim()) return { err: "ERROR calling 'animation_library': 'new_name' is required for rename." };
      base.new_name = String(args.new_name).trim();
    }
    if (lop === "tag") {
      if (args.tags === undefined && args.notes === undefined) return { err: "ERROR calling 'animation_library': tag needs 'tags' (array or comma list) and/or 'notes'." };
      if (args.tags !== undefined) base.tags = Array.isArray(args.tags) ? args.tags.map(String) : String(args.tags);
      if (args.notes !== undefined) base.notes = String(args.notes);
    }
    for (const k of ["query", "rig", "tag"]) if (args[k] !== undefined && String(args[k]).trim()) base[k] = String(args[k]).trim();
  } else if (op === "map_axes") {
    if (args.filter) {
      const list = Array.isArray(args.filter) ? args.filter : [args.filter];
      base.filter = list.map(String);
    }
    const angle = Number(args.angle);
    if (args.angle !== undefined && !(Number.isFinite(angle) && angle > 0 && angle < 90)) return { err: "ERROR calling 'animation_map_axes': 'angle' must be a finite number between 0 and 90 degrees." };
    if (angle > 0) base.angle = angle;
  }
  try {
    const json = JSON.stringify(base);
    if (json.includes("]==]")) return { err: "ERROR: internal serialization conflict." };
    const code = ANIM_LIB_LUA.replace("__ARGS_JSON__", json);
    // {code, lib, body}: the 1.51.2 library cache ships the 50 KB library once per
    // session and each command only carries its own args + dispatch.
    const cut = code.indexOf("\nlocal args = jdec(");
    if (cut > 0) return { code, lib: code.slice(0, cut + 1), body: code.slice(cut + 1) };
    return { code };
  } catch (e) {
    return { err: `ERROR building animation command: ${e}` };
  }
}

// Format the virtual command catalogue the same way main.js formats real tools.
function describeCommands() {
  const lines = [];
  lines.push(
    "— RobloxScript animation tools: build REAL Roblox animation keyframe data (KeyframeSequence/Pose) in Studio and " +
    "review it visually. FIRST CHOICE (1.52 engine): animation_generate {prompt} authors, validates and builds a whole clip from words " +
    "(animation_sequence for multi-stage combos, animation_refine {feedback} to adjust; 1.53: {variations:N} for N distinct takes, {mirror:true} for left-handed, 'new take' / 'mirror' / 'root motion' feedback; 1.54: animation_polish {smooth, plant_feet, simplify, reverse, bake, cycle_offset} on the existing keys, animation_layer {base, upper} for walk+wave style upper-body layering, 'smoother' / 'plant the feet' feedback; 1.55: ANY prompt works - 70+ everyday / sport / work / social acts, 'A then B then C' chains, 'X while walking' layering, 'raise the left arm' pose grammar, moods (tired, drunk, proud, scared, old, injured…) also as feedback ('make it drunk', 'then bow'); 1.56: SEVERAL animations (idle + walk + jump…) = animation_set {prompts:[...]} → separate clips of ONE character + compatibility + blend plan - never one merged clip; the session reuses one character seed so later animation_generate calls match; animation_compatibility re-checks; animation_preview is real-time now (loop/cycles/speed); 1.58: tempo is kept when combining - 'A then B' chains blend at a calm rate, layering never speeds a clip up, a duration YOU pick never rushes a clip below 75% of its natural length ('in 2s' in the prompt pins it); speed feedback: 'make it slow / fast', 'a bit slower', 'much faster', 'half speed', '2x', '30% slower', 'fluent'; " +
    "idles, walks, runs, sneak, strafe, crawl, swim, climb, fly, sleep, hit reactions, knockback, death, dash, slide, flips, throws, shooting, archery, pickups and 20+ emotes all have their own choreography and a per-prompt persona, so no two prompts move alike); hand-key only what the engine cannot express. " +
    "Manual flow: animation_create → animation_open → animation_set_pose + animation_add_keyframe / " +
    "animation_update_keyframe per keyframe time → animation_preview to check → refine. " +
    "All rotations are DEGREES, order YXZ; bones are the character's joint-connected part names (e.g. RootJoint or HumanoidRootPart, LeftUpperArm, " +
    "RightLowerLeg); both Motor6D (R6/R15) and AnimationConstraint (Avatar Joint Upgrade) rigs are supported; times in seconds from 0 to duration. " +
    "Every call that touches the active animation ignores its name " +
    "parameter in favor of the animation currently open (see animation_open) — pass the name only to create/switch. " +
    "DIRECTIONS: rotations are local per-joint. Run animation_test FIRST - it measures the rig's convention and reports 'standard' or " +
    "'MIRRORED'; if mirrored, flip the sign of every rot value you send. When not measurable, verify with preview + user feedback. —"
  );
  for (const c of ANIM_COMMANDS) {
    const compact = [];
    const detailed = [];
    for (const [k, v] of Object.entries(c.params)) {
      const mark = v.req ? "" : "?";
      if (v.desc && v.desc.length > 45) {
        detailed.push(`    ${k}${mark}: ${v.type} - ${v.desc}`);
      } else {
        compact.push(`${k}${mark}:${v.type}${v.desc ? ` "${v.desc}"` : ""}`);
      }
    }
    const paramLines = [compact.length ? `    ${compact.join(", ")}` : "", ...detailed].filter(Boolean).join("\n");
    lines.push(`${c.name}: ${c.description}${paramLines ? "\n" + paramLines : ""}`);
  }
  return lines;
}

const RSAnim = {
  ANIM_LIB_LUA,
  ANIM_COMMANDS,
  ANIM_OPS: ANIM_COMMANDS.map((c) => c.name.slice("animation_".length)),
  buildLuau,
  describeCommands,
};
