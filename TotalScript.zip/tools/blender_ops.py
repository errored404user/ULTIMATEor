# Sent to Blender as execute_code. Tokens CMD / ARGS / OUT / MESH are filled by TotalScript.
import bpy
import json
import math
import os
import traceback
from mathutils import Vector

CMD = """__TOTAL_CMD__"""
ARGS = json.loads(r"""__TOTAL_ARGS__""")
if not isinstance(ARGS, dict):
    ARGS = {}
OUT = __TOTAL_OUT__
MESH = __TOTAL_MESH__
if not OUT:
    OUT = "total_status.json"
if not MESH:
    MESH = "total_mesh.json"
result = None


# TotalScript reads the result from this script's stdout (the blender-mcp addon returns
# captured stdout as execute_code's result). The status / mesh files are only a
# fallback: Blender's working directory is usually not writable (Program Files)
# and never the total-core workspace, so nothing may depend on them.
INLINE_LIMIT = 3000000
WRAP = 3000


def write_wrapped(path, text):
    """Write ASCII JSON as <= WRAP-char lines: total-core's read_file clips one
    read at 40k characters, so TotalScript reads these files 8 short lines at a time."""
    if not path:
        return ""
    try:
        folder = os.path.dirname(path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(text[i:i + WRAP] for i in range(0, len(text), WRAP)))
        return path
    except Exception:
        return ""


def emit(payload):
    global result
    result = payload
    try:
        full = json.dumps(payload, ensure_ascii=True, separators=(",", ":"))
    except Exception:
        full = None
    if full is not None and len(full) <= INLINE_LIMIT:
        print("TOTAL_MESH_JSON:" + full, flush=True)
    else:
        try:
            slim = dict(payload)
            slim.pop("meshes", None)
            slim["inline"] = False
            print("TOTAL_MESH_JSON:" + json.dumps(slim, ensure_ascii=True, separators=(",", ":")), flush=True)
        except Exception:
            print("TOTAL_MESH_JSON:{\"ok\":false}", flush=True)
    try:
        slim = dict(payload)
        slim.pop("meshes", None)
        write_wrapped(OUT, json.dumps(slim, ensure_ascii=True, separators=(",", ":")))
    except Exception:
        pass
    return payload


def blender_version():
    try:
        return ".".join(str(x) for x in bpy.app.version)
    except Exception:
        return ""


def classify_exception(exc, cmd=""):
    """Turn a bpy exception into a structured, actionable error (1.84.0).

    Mirrors TotalCommandContract.classify on the extension side so the model sees
    the SAME categories whether the failure was caught before or inside Blender.
    """
    import re as _re
    msg = str(exc) or exc.__class__.__name__
    out = {"ok": False, "error": msg[:700], "error_class": "runtime_error", "command": str(cmd), "blender": blender_version(), "deterministic": False}
    m = _re.search(r'enum "([^"]*)" not found in \(([^)]*)\)', msg)
    if m:
        allowed = [a.strip().strip("'") for a in m.group(2).split(",") if a.strip()]
        out.update({"error_class": "invalid_enum", "deterministic": True, "value": m.group(1), "allowed": allowed,
                    "hint": "'" + m.group(1) + "' is not a valid choice here - use one of: " + ", ".join(allowed)})
        return out
    if isinstance(exc, TypeError) and "unexpected keyword" in msg:
        m = _re.search(r"keyword argument '([^']+)'", msg)
        out.update({"error_class": "unknown_parameter", "deterministic": True, "parameter": m.group(1) if m else "",
                    "hint": "this Blender version does not accept that argument - drop it or use blender_introspect to see what exists"})
        return out
    if isinstance(exc, AttributeError):
        m = _re.search(r"has no attribute '([^']+)'", msg)
        out.update({"error_class": "api_incompatibility", "deterministic": True, "attribute": m.group(1) if m else "",
                    "hint": "the property/operator does not exist in Blender " + (blender_version() or "?") + " - check blender_introspect before setting it"})
        return out
    if "context is incorrect" in msg or "poll() failed" in msg:
        out.update({"error_class": "invalid_context", "deterministic": False,
                    "hint": "the operator needs a different mode/selection - select the objects (blender_select) and make sure they are visible and in Object mode"})
        return out
    if isinstance(exc, KeyError):
        out.update({"error_class": "resource_missing", "deterministic": False, "hint": "the named datablock does not exist - list objects/materials first and use the exact name"})
        return out
    if isinstance(exc, (ValueError, IndexError)):
        out.update({"error_class": "invalid_parameter", "deterministic": True, "hint": "a parameter has the wrong shape or value - check the schema and the error text"})
        return out
    if isinstance(exc, (OSError, IOError)):
        out.update({"error_class": "io_error", "deterministic": False, "hint": "file/path problem - make sure the folder exists and is writable"})
        return out
    out["trace"] = traceback.format_exc()[-600:]
    return out


def view_override():
    wm = bpy.context.window_manager
    if not wm:
        return {}
    for win in wm.windows:
        screen = getattr(win, "screen", None)
        if not screen:
            continue
        for area in screen.areas:
            if area.type != "VIEW_3D":
                continue
            for region in area.regions:
                if region.type == "WINDOW":
                    return {"window": win, "screen": screen, "area": area, "region": region, "scene": bpy.context.scene}
    return {}


def run_op(op, **kwargs):
    ov = view_override()
    if ov:
        try:
            with bpy.context.temp_override(**ov):
                return op(**kwargs)
        except TypeError:
            pass
        except Exception:
            pass
    return op(**kwargs)


def ensure_object_mode():
    try:
        obj = bpy.context.view_layer.objects.active
        if obj is not None and getattr(obj, "mode", "OBJECT") != "OBJECT":
            run_op(bpy.ops.object.mode_set, mode="OBJECT")
    except Exception:
        try:
            bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass


def in_edit(objs, fn):
    select_only(objs)
    run_op(bpy.ops.object.mode_set, mode="EDIT")
    try:
        run_op(bpy.ops.mesh.select_all, action="SELECT")
        fn()
    finally:
        try:
            run_op(bpy.ops.object.mode_set, mode="OBJECT")
        except Exception:
            pass


def enable_io():
    for mod in (
        "io_scene_fbx",
        "bl_ext.blender_org.io_scene_fbx",
        "bl_ext.blender_org.fbx",
        "io_scene_obj",
        "bl_ext.blender_org.io_scene_obj",
    ):
        try:
            bpy.ops.preferences.addon_enable(module=mod)
        except Exception:
            pass


def default_dir():
    folder = os.path.join(os.path.expanduser("~"), "Documents", "TotalScript")
    os.makedirs(folder, exist_ok=True)
    return folder


def as_list(v):
    if v is None:
        return None
    if isinstance(v, (list, tuple)):
        return [x for x in v if x is not None and str(x) != ""]
    return [v]


def resolve_objects(names):
    names = as_list(names)
    if names:
        out = []
        for n in names:
            o = bpy.data.objects.get(str(n))
            if o:
                out.append(o)
        return out
    sel = [o for o in bpy.context.selected_objects if o]
    if sel:
        return sel
    return [o for o in bpy.data.objects if o.type == "MESH"]


def named_or_sel():
    return resolve_objects(ARGS.get("objects") or ([ARGS.get("name")] if ARGS.get("name") else None))


def select_only(objs):
    ensure_object_mode()
    try:
        run_op(bpy.ops.object.select_all, action="DESELECT")
    except Exception:
        for o in bpy.data.objects:
            try:
                o.select_set(False)
            except Exception:
                pass
    count = 0
    for o in objs:
        try:
            o.select_set(True)
            count += 1
        except Exception:
            pass
    if objs:
        try:
            bpy.context.view_layer.objects.active = objs[0]
        except Exception:
            pass
    return count


def vec3(key, default=(0.0, 0.0, 0.0)):
    v = ARGS.get(key)
    if v is None:
        return tuple(default)
    if isinstance(v, (int, float)):
        return (float(v), float(v), float(v))
    if isinstance(v, (list, tuple)) and len(v) >= 3:
        return (float(v[0]), float(v[1]), float(v[2]))
    if isinstance(v, (list, tuple)) and len(v) == 1:
        f = float(v[0])
        return (f, f, f)
    return tuple(default)


def set_name(obj, name):
    if obj is not None and name:
        obj.name = str(name)
        if getattr(obj, "data", None) is not None and hasattr(obj.data, "name"):
            try:
                obj.data.name = str(name)
            except Exception:
                pass
    return obj.name if obj else None


def active():
    return bpy.context.view_layer.objects.active


def add_primitive(op_name, name, extra=None):
    ensure_object_mode()
    loc = vec3("location", (0, 0, 0))
    kw = {"location": loc}
    if extra:
        kw.update(extra)
    op = getattr(bpy.ops.mesh, op_name)
    run_op(op, **kw)
    obj = active()
    set_name(obj, name or ARGS.get("name"))
    rot = ARGS.get("rotation_deg") or ARGS.get("rotation")
    if rot is not None and obj:
        if ARGS.get("rotation_deg") is not None:
            obj.rotation_euler = [math.radians(float(x)) for x in vec3("rotation_deg")]
        else:
            obj.rotation_euler = vec3("rotation")
    return emit({"ok": True, "name": obj.name if obj else name, "type": "MESH", "location": list(loc)})


# Studio import budgets. EditableMesh refuses more than 20,000 triangles per
# mesh; the whole dump must also stay well inside total-core's 2 MB request limit
# (TotalScript splits it into several execute_luau calls, but one mesh is never split).
MAX_MESHES = 32
MAX_TRIS_PER_MESH = 20000
MAX_TOTAL_TRIS = 40000
MAX_TOTAL_VERTS = 40000


def mesh_color(obj):
    """Base colour of the object's first material (Principled Base Color, else
    the viewport diffuse colour) as [r, g, b] in 0..1, or None."""
    try:
        mat = obj.active_material
        if mat is None:
            for slot in obj.material_slots:
                if slot.material:
                    mat = slot.material
                    break
        if mat is None:
            return None
        if mat.use_nodes and mat.node_tree:
            for node in mat.node_tree.nodes:
                if node.type == "BSDF_PRINCIPLED":
                    inp = node.inputs.get("Base Color")
                    if inp is not None:
                        c = inp.default_value
                        return [round(float(c[0]), 3), round(float(c[1]), 3), round(float(c[2]), 3)]
        c = mat.diffuse_color
        return [round(float(c[0]), 3), round(float(c[1]), 3), round(float(c[2]), 3)]
    except Exception:
        return None


def material_pbr(mat):
    """Principled BSDF parameters of a material as plain numbers plus the
    Roblox material hint stored by blender_asset.py (mat["total_roblox"]).
    Roblox cannot reproduce a node tree - the importer maps these values to
    Enum.Material / Color / Reflectance / Transparency and says so."""
    if mat is None:
        return None
    out = {"name": str(getattr(mat, "name", "Material")), "color": None, "metallic": 0.0, "roughness": 0.5, "alpha": 1.0, "emission": None, "emission_strength": 0.0}
    try:
        bsdf = None
        if mat.use_nodes and mat.node_tree:
            for node in mat.node_tree.nodes:
                if node.type == "BSDF_PRINCIPLED":
                    bsdf = node
                    break
        if bsdf is not None:
            def val(key, default):
                inp = bsdf.inputs.get(key)
                if inp is None:
                    return default
                v = inp.default_value
                try:
                    return [round(float(x), 3) for x in v][:4]
                except TypeError:
                    return round(float(v), 3)
            c = val("Base Color", None)
            out["color"] = c[:3] if c else None
            out["metallic"] = val("Metallic", 0.0)
            out["roughness"] = val("Roughness", 0.5)
            out["alpha"] = val("Alpha", 1.0)
            em = val("Emission Color", None) or val("Emission", None)
            strength = val("Emission Strength", 0.0)
            if em and strength and strength > 0 and max(em[:3]) > 0.01:
                out["emission"] = em[:3]
                out["emission_strength"] = strength
            tex = []
            for node in mat.node_tree.nodes:
                if node.type == "TEX_IMAGE" and node.image is not None:
                    fp = ""
                    try:
                        fp = bpy.path.abspath(node.image.filepath) if node.image.filepath else ""
                    except Exception:
                        fp = ""
                    tex.append({"image": node.image.name, "filepath": fp, "exists": bool(fp and os.path.exists(fp)), "packed": bool(getattr(node.image, "packed_file", None))})
            if tex:
                out["textures"] = tex
        if out["color"] is None:
            c = mat.diffuse_color
            out["color"] = [round(float(c[0]), 3), round(float(c[1]), 3), round(float(c[2]), 3)]
        try:
            if mat.get("total_roblox"):
                out["roblox"] = str(mat["total_roblox"])
        except Exception:
            pass
        try:
            if mat.blend_method in ("BLEND", "HASHED") and out["alpha"] >= 1.0:
                out["alpha"] = 0.999
        except Exception:
            pass
    except Exception:
        pass
    return out


def total_props(obj):
    """Custom properties written by blender_asset.py (total_role, total_collision ...)."""
    props = {}
    try:
        for k in obj.keys():
            if str(k).startswith("total_"):
                v = obj[k]
                if isinstance(v, (int, float, str, bool)):
                    props[str(k)[6:]] = v
    except Exception:
        pass
    return props


def dump_attachments(root_names=None):
    """Empties named ATT_* (or flagged total_attachment) -> Roblox attachments,
    positions converted to Y-up like the vertices."""
    out = []
    for o in bpy.data.objects:
        if o.type != "EMPTY":
            continue
        is_att = str(o.name).startswith("ATT_")
        try:
            is_att = is_att or bool(o.get("total_attachment"))
        except Exception:
            pass
        if not is_att:
            continue
        c = o.matrix_world.translation
        parent = o.parent.name if o.parent is not None else None
        if root_names and parent not in root_names and o.name not in root_names:
            continue
        name = str(o.name)[4:] if str(o.name).startswith("ATT_") else str(o.name)
        try:
            if o.get("total_attachment_name"):
                name = str(o.get("total_attachment_name"))
        except Exception:
            pass
        out.append({"name": name, "pos": [round(float(c.x), 4), round(float(c.z), 4), round(float(-c.y), 4)], "parent": parent, "asset": str(o.get("total_asset") or "") if hasattr(o, "get") else ""})
    return out


def mesh_triangles(mesh):
    """Triangle corner indices (flat, 0-based) using Blender's own
    triangulation when available (handles concave n-gons), else a fan."""
    tris = []
    try:
        if hasattr(mesh, "calc_loop_triangles"):
            mesh.calc_loop_triangles()
        lt = getattr(mesh, "loop_triangles", None)
        if lt is not None and len(lt) > 0:
            for t in lt:
                a, b, c = t.vertices
                tris.extend((int(a), int(b), int(c)))
            return tris
    except Exception:
        tris = []
    for p in mesh.polygons:
        ids = [int(i) for i in p.vertices]
        if len(ids) == 3:
            tris.extend(ids)
        elif len(ids) > 3:
            for i in range(1, len(ids) - 1):
                tris.extend((ids[0], ids[i], ids[i + 1]))
    return tris


def dump_meshes(names, skipped=None):
    meshes = []
    total_v = 0
    total_t = 0
    objs = [o for o in resolve_objects(names) if o.type == "MESH" and o.data]
    if not objs:
        objs = [o for o in bpy.data.objects if o.type == "MESH" and o.data]
    want_normals = ARGS.get("normals") is not False
    want_uvs = ARGS.get("uvs") is not False
    depsgraph = bpy.context.evaluated_depsgraph_get()
    for obj in objs:
        if len(meshes) >= MAX_MESHES:
            if skipped is not None:
                skipped.append({"name": obj.name, "reason": "more than %d meshes - send the rest in a second blender_send_to_studio {objects:[...]}" % MAX_MESHES})
            continue
        mesh = None
        eval_obj = None
        try:
            eval_obj = obj.evaluated_get(depsgraph)
            mesh = eval_obj.to_mesh()
        except Exception:
            mesh = obj.data
            eval_obj = None
        if mesh is None or len(mesh.vertices) == 0:
            if eval_obj is not None:
                try:
                    eval_obj.to_mesh_clear()
                except Exception:
                    pass
            continue
        tris = mesh_triangles(mesh)
        tri_count = len(tris) // 3
        vert_count = len(mesh.vertices)
        reason = None
        if tri_count == 0:
            reason = "no faces (curve / empty mesh) - convert or fill it first"
        elif tri_count > MAX_TRIS_PER_MESH:
            reason = "%d triangles - Studio's EditableMesh limit is %d; run blender_decimate {objects:[\"%s\"], ratio:%.2f} first" % (tri_count, MAX_TRIS_PER_MESH, obj.name, max(0.05, min(0.95, (MAX_TRIS_PER_MESH * 0.9) / float(tri_count))))
        elif total_t + tri_count > MAX_TOTAL_TRIS or total_v + vert_count > MAX_TOTAL_VERTS:
            reason = "dump budget reached (%d triangles / %d vertices per send) - send it in a second blender_send_to_studio {objects:[\"%s\"]}" % (MAX_TOTAL_TRIS, MAX_TOTAL_VERTS, obj.name)
        if reason:
            if eval_obj is not None:
                try:
                    eval_obj.to_mesh_clear()
                except Exception:
                    pass
            if skipped is not None:
                skipped.append({"name": obj.name, "tris": tri_count, "reason": reason})
            continue
        mw = obj.matrix_world
        verts = []
        # Blender is Z-up / right-handed, Roblox is Y-up / right-handed:
        # (x, y, z) -> (x, z, -y) is a pure rotation, so face winding survives.
        for v in mesh.vertices:
            c = mw @ v.co
            verts.append([round(float(c.x), 4), round(float(c.z), 4), round(float(-c.y), 4)])
        smooth = 0
        try:
            for p in mesh.polygons:
                if p.use_smooth:
                    smooth += 1
            flat = smooth * 2 < len(mesh.polygons)
        except Exception:
            flat = False
        color = mesh_color(obj)
        # 1.83.0: per-corner split normals + UVs + per-material groups so the
        # Studio importer can build smooth shading, UV sets and one MeshPart
        # per material instead of one flat, single-colour blob per object.
        corner_normals, corner_uvs, tri_mats = dump_corners(obj, mesh, mw, want_normals and not flat, want_uvs)
        try:
            pv = mw.translation if hasattr(mw, "translation") else (mw @ Vector((0.0, 0.0, 0.0)))
            pivot = [round(float(pv.x), 4), round(float(pv.z), 4), round(float(-pv.y), 4)]
        except Exception:
            pivot = None
        try:
            slots = [slot.material for slot in obj.material_slots]
        except Exception:
            slots = []
        if not slots and getattr(obj, "active_material", None) is not None:
            slots = [obj.active_material]
        props = total_props(obj)
        par = getattr(obj, "parent", None)
        parent = par.name if par is not None else None
        if eval_obj is not None:
            try:
                eval_obj.to_mesh_clear()
            except Exception:
                pass
        groups = {}
        order = []
        for ti in range(tri_count):
            mi = tri_mats[ti] if tri_mats else 0
            if mi not in groups:
                groups[mi] = []
                order.append(mi)
            groups[mi].append(ti)
        multi = len(order) > 1
        for mi in order:
            tri_ids = groups[mi]
            if multi:
                remap = {}
                g_verts = []
                g_faces = []
                for ti in tri_ids:
                    for k in range(3):
                        vi = tris[ti * 3 + k]
                        if vi not in remap:
                            remap[vi] = len(g_verts)
                            g_verts.append(verts[vi])
                        g_faces.append(remap[vi])
            else:
                g_verts, g_faces = verts, tris
            mat = slots[mi] if 0 <= mi < len(slots) else None
            name = obj.name if not multi else "%s_%s" % (obj.name, (mat.name if mat is not None else "Slot%d" % mi))
            entry = {"name": name, "object": obj.name, "verts": g_verts, "faces": g_faces, "tris": len(tri_ids), "flat": flat}
            if pivot:
                entry["pivot"] = pivot
            pbr = material_pbr(mat)
            if pbr:
                entry["material"] = pbr
                if pbr.get("color"):
                    entry["color"] = pbr["color"]
            elif color:
                entry["color"] = color
            if corner_normals:
                entry["normals"] = [corner_normals[ti] for ti in tri_ids] if multi else corner_normals
            if corner_uvs:
                entry["uvs"] = [corner_uvs[ti] for ti in tri_ids] if multi else corner_uvs
            if props:
                entry["props"] = props
            if parent:
                entry["parent"] = parent
            meshes.append(entry)
        total_v += vert_count
        total_t += tri_count
    return meshes


def dump_corners(obj, mesh, mw, want_normals, want_uvs):
    """Per-triangle corner normals ([[nx,ny,nz]*3] per tri, Y-up, rounded) and
    UVs ([[u,v]*3] per tri) plus the material index per triangle, all in
    loop_triangles order (the order mesh_triangles() emits)."""
    normals = []
    uvs = []
    mats = []
    try:
        lt = getattr(mesh, "loop_triangles", None)
        if lt is None or len(lt) == 0:
            return [], [], []
        nmat = None
        if want_normals:
            try:
                nmat = mw.to_3x3().inverted_safe().transposed()
            except Exception:
                nmat = mw.to_3x3()
        uv_layer = None
        if want_uvs:
            try:
                uv_layer = mesh.uv_layers.active
            except Exception:
                uv_layer = None
        uv_data = uv_layer.data if uv_layer is not None else None
        for t in lt:
            mats.append(int(getattr(t, "material_index", 0)))
            if nmat is not None:
                tri_n = []
                for n in t.split_normals:
                    w = (nmat @ Vector(n)).normalized()
                    tri_n.append([round(float(w.x), 3), round(float(w.z), 3), round(float(-w.y), 3)])
                normals.append(tri_n)
            if uv_data is not None:
                tri_uv = []
                for li in t.loops:
                    uv = uv_data[li].uv
                    tri_uv.append([round(float(uv[0]), 4), round(float(uv[1]), 4)])
                uvs.append(tri_uv)
    except Exception:
        return [], [], mats
    return normals, uvs, mats


def write_mesh_file(meshes):
    if not MESH:
        return ""
    try:
        return write_wrapped(MESH, json.dumps({"ok": True, "meshes": meshes}, ensure_ascii=True, separators=(",", ":")))
    except Exception:
        return ""


def try_export_fbx(fp):
    enable_io()
    ensure_object_mode()
    kwargs_list = [
        dict(filepath=fp, use_selection=True, apply_scale_options="FBX_SCALE_UNITS",
             axis_forward="-Z", axis_up="Y", apply_unit_scale=True, add_leaf_bones=False,
             bake_space_transform=True),
        dict(filepath=fp, use_selection=True, path_mode="AUTO"),
        dict(filepath=fp),
    ]
    ops = []
    if hasattr(bpy.ops.wm, "fbx_export"):
        ops.append(bpy.ops.wm.fbx_export)
    if hasattr(bpy.ops.export_scene, "fbx"):
        ops.append(bpy.ops.export_scene.fbx)
    last = "FBX exporter not found — enable the FBX add-on in Blender Preferences"
    for op in ops:
        for kw in kwargs_list:
            try:
                ret = run_op(op, **kw)
                if os.path.isfile(fp) and os.path.getsize(fp) > 0:
                    return True, None
                last = "FBX operator returned %s and wrote no file" % (ret,)
            except TypeError:
                continue
            except Exception as e:
                last = str(e)
    return False, last


def try_import_fbx(fp):
    enable_io()
    ensure_object_mode()
    ops = []
    if hasattr(bpy.ops.wm, "fbx_import"):
        ops.append(bpy.ops.wm.fbx_import)
    if hasattr(bpy.ops.import_scene, "fbx"):
        ops.append(bpy.ops.import_scene.fbx)
    last = "FBX importer not found — enable the FBX add-on in Blender Preferences"
    for op in ops:
        for kw in (dict(filepath=fp, automatic_bone_orientation=True), dict(filepath=fp)):
            try:
                run_op(op, **kw)
                return True, None
            except TypeError:
                continue
            except Exception as e:
                last = str(e)
    return False, last


def try_export_obj(fp):
    enable_io()
    ensure_object_mode()
    ops = []
    if hasattr(bpy.ops.wm, "obj_export"):
        ops.append(bpy.ops.wm.obj_export)
    if hasattr(bpy.ops.export_scene, "obj"):
        ops.append(bpy.ops.export_scene.obj)
    last = "OBJ exporter not found"
    for op in ops:
        for kw in (dict(filepath=fp, export_selected_objects=True), dict(filepath=fp, use_selection=True), dict(filepath=fp)):
            try:
                run_op(op, **kw)
                if os.path.isfile(fp):
                    return True, None
                last = "OBJ wrote no file"
            except TypeError:
                continue
            except Exception as e:
                last = str(e)
    return False, last


def try_import_obj(fp):
    enable_io()
    ensure_object_mode()
    ops = []
    if hasattr(bpy.ops.wm, "obj_import"):
        ops.append(bpy.ops.wm.obj_import)
    if hasattr(bpy.ops.import_scene, "obj"):
        ops.append(bpy.ops.import_scene.obj)
    last = "OBJ importer not found"
    for op in ops:
        try:
            run_op(op, filepath=fp)
            return True, None
        except Exception as e:
            last = str(e)
    return False, last


def cmd_export_fbx():
    fp = str(ARGS.get("filepath") or ARGS.get("path") or "").strip()
    if not fp:
        fp = os.path.join(default_dir(), "total_export.fbx")
    if not fp.lower().endswith(".fbx"):
        fp += ".fbx"
    folder = os.path.dirname(fp)
    if folder:
        os.makedirs(folder, exist_ok=True)
    names = ARGS.get("objects")
    objs = resolve_objects(names)
    n = select_only(objs)
    if n == 0:
        return emit({"ok": False, "error": "no mesh objects to export", "filepath": fp})
    try:
        run_op(bpy.ops.object.transform_apply, location=False, rotation=True, scale=True)
    except Exception:
        pass
    ok, err = try_export_fbx(fp)
    meshes = dump_meshes(names)
    mesh_path = write_mesh_file(meshes) if meshes else ""
    if not ok:
        return emit({
            "ok": True,
            "filepath": fp if os.path.isfile(fp) else "",
            "file_error": err,
            "objects": [m["name"] for m in meshes],
            "mesh_count": len(meshes),
            "mesh_file": mesh_path,
            "meshes": meshes,
            "note": "FBX file was not written, but meshes were dumped for Studio.",
        })
    return emit({
        "ok": True,
        "filepath": fp,
        "bytes": os.path.getsize(fp) if os.path.isfile(fp) else 0,
        "objects": [m["name"] for m in meshes],
        "mesh_count": len(meshes),
        "mesh_file": mesh_path,
        "meshes": meshes,
    })


def cmd_import_fbx():
    fp = str(ARGS.get("filepath") or ARGS.get("path") or ARGS.get("asset") or "").strip()
    if not fp:
        fp = os.path.join(default_dir(), "total_export.fbx")
    if not os.path.isfile(fp):
        return emit({"ok": False, "error": "FBX not found: " + fp, "filepath": fp})
    before = set(bpy.data.objects.keys())
    ok, err = try_import_fbx(fp)
    if not ok:
        return emit({"ok": False, "error": err, "filepath": fp})
    added = [k for k in bpy.data.objects.keys() if k not in before]
    return emit({"ok": True, "filepath": fp, "imported": added})


def cmd_export_obj():
    fp = str(ARGS.get("filepath") or ARGS.get("path") or "").strip() or os.path.join(default_dir(), "total_export.obj")
    if not fp.lower().endswith(".obj"):
        fp += ".obj"
    os.makedirs(os.path.dirname(fp) or ".", exist_ok=True)
    select_only(resolve_objects(ARGS.get("objects")))
    ok, err = try_export_obj(fp)
    if not ok:
        return emit({"ok": False, "error": err, "filepath": fp})
    return emit({"ok": True, "filepath": fp, "bytes": os.path.getsize(fp) if os.path.isfile(fp) else 0})


def cmd_import_obj():
    fp = str(ARGS.get("filepath") or ARGS.get("path") or "").strip()
    if not fp or not os.path.isfile(fp):
        return emit({"ok": False, "error": "OBJ not found: " + (fp or "(empty)")})
    before = set(bpy.data.objects.keys())
    ok, err = try_import_obj(fp)
    if not ok:
        return emit({"ok": False, "error": err})
    added = [k for k in bpy.data.objects.keys() if k not in before]
    return emit({"ok": True, "filepath": fp, "imported": added})


def cmd_dump():
    names = ARGS.get("objects")
    skipped = []
    meshes = dump_meshes(names, skipped)
    if not meshes:
        why = "no mesh objects in the Blender scene"
        if skipped:
            why = "no mesh could be sent: " + "; ".join("%s (%s)" % (k["name"], k["reason"]) for k in skipped[:6])
        return emit({"ok": False, "error": why, "skipped": skipped})
    mesh_path = write_mesh_file(meshes)
    roots = {}
    for o in bpy.data.objects:
        try:
            if o.type == "EMPTY" and o.get("total_asset"):
                pv = o.matrix_world.translation
                roots[o.name] = {"name": o.name, "studs_per_meter": float(o.get("total_studs_per_meter") or 0) or None, "origin": str(o.get("total_origin") or ""), "pivot": [round(float(pv.x), 4), round(float(pv.z), 4), round(float(-pv.y), 4)]}
        except Exception:
            pass
    parents = set(m.get("parent") for m in meshes if m.get("parent"))
    used_roots = [roots[n] for n in parents if n in roots]
    suggested = None
    for r in used_roots:
        if r.get("studs_per_meter"):
            suggested = r["studs_per_meter"]
            break
    attachments = dump_attachments(parents or None)
    return emit({
        "ok": True,
        "objects": [m["name"] for m in meshes],
        "mesh_count": len(meshes),
        "mesh_file": mesh_path,
        "tris": sum(m["tris"] for m in meshes),
        "verts": sum(len(m["verts"]) for m in meshes),
        "materials": sorted(set((m.get("material") or {}).get("name") for m in meshes if m.get("material"))),
        "with_uvs": sum(1 for m in meshes if m.get("uvs")),
        "with_normals": sum(1 for m in meshes if m.get("normals")),
        "assets": used_roots,
        "attachments": attachments,
        "suggested_scale": suggested,
        "skipped": skipped,
        "meshes": meshes,
    })


def cmd_group():
    ensure_object_mode()
    name = str(ARGS.get("name") or "Group")
    objs = resolve_objects(ARGS.get("objects"))
    if not objs:
        return emit({"ok": False, "error": "no objects to group"})
    coll = bpy.data.collections.get(name) or bpy.data.collections.new(name)
    if coll.name not in bpy.context.scene.collection.children:
        try:
            bpy.context.scene.collection.children.link(coll)
        except Exception:
            pass
    empty = bpy.data.objects.new(name, None)
    empty.empty_display_type = "PLAIN_AXES"
    try:
        coll.objects.link(empty)
    except Exception:
        bpy.context.scene.collection.objects.link(empty)
    for o in objs:
        try:
            mw = o.matrix_world.copy()
            o.parent = empty
            o.matrix_world = mw
        except Exception:
            pass
        if o.name not in coll.objects:
            try:
                coll.objects.link(o)
            except Exception:
                pass
    select_only([empty] + objs)
    return emit({"ok": True, "group": empty.name, "collection": coll.name, "objects": [o.name for o in objs]})


def cmd_ungroup():
    ensure_object_mode()
    name = str(ARGS.get("name") or "")
    empty = bpy.data.objects.get(name) if name else active()
    if empty is None:
        return emit({"ok": False, "error": "no group empty to ungroup"})
    children = list(empty.children)
    for c in children:
        mw = c.matrix_world.copy()
        c.parent = None
        c.matrix_world = mw
    coll = bpy.data.collections.get(empty.name)
    if coll:
        try:
            bpy.context.scene.collection.children.unlink(coll)
        except Exception:
            pass
    try:
        bpy.data.objects.remove(empty, do_unlink=True)
    except Exception:
        pass
    return emit({"ok": True, "ungrouped": [c.name for c in children]})


def cmd_parent():
    ensure_object_mode()
    parent_name = str(ARGS.get("parent") or ARGS.get("name") or "")
    parent = bpy.data.objects.get(parent_name)
    objs = resolve_objects(ARGS.get("objects"))
    if parent is None or not objs:
        return emit({"ok": False, "error": "parent and objects are required"})
    linked = []
    keep = bool(ARGS.get("keep_transform", True))
    for o in objs:
        if o == parent:
            continue
        mw = o.matrix_world.copy() if keep else None
        o.parent = parent
        if keep:
            o.matrix_world = mw
        linked.append(o.name)
    return emit({"ok": True, "parent": parent.name, "objects": linked})


def cmd_unparent():
    objs = named_or_sel()
    names = []
    for o in objs:
        if o.parent:
            mw = o.matrix_world.copy()
            o.parent = None
            o.matrix_world = mw
            names.append(o.name)
    return emit({"ok": True, "objects": names})


def cmd_join():
    ensure_object_mode()
    objs = resolve_objects(ARGS.get("objects"))
    meshes = [o for o in objs if o.type == "MESH"]
    if len(meshes) < 2:
        return emit({"ok": False, "error": "join needs at least two mesh objects"})
    select_only(meshes)
    run_op(bpy.ops.object.join)
    obj = active()
    if ARGS.get("name") and obj:
        set_name(obj, ARGS.get("name"))
    return emit({"ok": True, "name": obj.name if obj else "", "joined": [o.name for o in meshes]})


def cmd_move_to_collection():
    name = str(ARGS.get("collection") or ARGS.get("name") or "Collection")
    objs = named_or_sel()
    coll = bpy.data.collections.get(name) or bpy.data.collections.new(name)
    if coll.name not in bpy.context.scene.collection.children:
        try:
            bpy.context.scene.collection.children.link(coll)
        except Exception:
            pass
    moved = []
    for o in objs:
        if o.name not in coll.objects:
            try:
                coll.objects.link(o)
                moved.append(o.name)
            except Exception:
                pass
    return emit({"ok": True, "collection": coll.name, "objects": moved})


def cmd_list_collections():
    cols = []
    for c in bpy.data.collections:
        cols.append({"name": c.name, "objects": [o.name for o in c.objects]})
    return emit({"ok": True, "collections": cols})


def cmd_list_objects():
    items = []
    for o in bpy.data.objects:
        items.append({
            "name": o.name, "type": o.type,
            "location": [round(x, 4) for x in o.location],
            "rotation_deg": [round(math.degrees(x), 2) for x in o.rotation_euler],
            "scale": [round(x, 4) for x in o.scale],
            "dimensions": [round(x, 4) for x in o.dimensions] if hasattr(o, "dimensions") else None,
            "hide": bool(o.hide_get()) if hasattr(o, "hide_get") else bool(o.hide_viewport),
            "parent": o.parent.name if o.parent else None,
            "collections": [c.name for c in o.users_collection],
        })
    return emit({"ok": True, "objects": items, "selected": [o.name for o in bpy.context.selected_objects]})


def cmd_delete():
    ensure_object_mode()
    objs = named_or_sel()
    names = [o.name for o in objs]
    select_only(objs)
    try:
        run_op(bpy.ops.object.delete)
    except Exception:
        for o in objs:
            try:
                bpy.data.objects.remove(o, do_unlink=True)
            except Exception:
                pass
    return emit({"ok": True, "deleted": names})


def cmd_duplicate():
    ensure_object_mode()
    objs = named_or_sel()
    if not objs:
        return emit({"ok": False, "error": "nothing to duplicate"})
    select_only(objs)
    run_op(bpy.ops.object.duplicate)
    created = list(bpy.context.selected_objects)
    offset = ARGS.get("offset") or ARGS.get("location")
    if offset is not None:
        off = vec3("offset", vec3("location", (0, 0, 0)))
        for o in created:
            o.location = Vector(o.location) + Vector(off)
    if ARGS.get("name") and created:
        set_name(created[0], ARGS.get("name"))
    return emit({"ok": True, "objects": [o.name for o in created]})


def cmd_rename():
    obj = bpy.data.objects.get(str(ARGS.get("name") or ARGS.get("object") or "")) or active()
    new = str(ARGS.get("new_name") or ARGS.get("to") or "")
    if obj is None or not new:
        return emit({"ok": False, "error": "name and new_name are required"})
    old = obj.name
    set_name(obj, new)
    return emit({"ok": True, "from": old, "to": obj.name})


def cmd_select():
    objs = named_or_sel()
    n = select_only(objs)
    return emit({"ok": True, "selected": [o.name for o in objs], "count": n})


def cmd_select_all():
    ensure_object_mode()
    run_op(bpy.ops.object.select_all, action="SELECT")
    return emit({"ok": True, "selected": [o.name for o in bpy.context.selected_objects]})


def cmd_deselect():
    ensure_object_mode()
    run_op(bpy.ops.object.select_all, action="DESELECT")
    return emit({"ok": True, "selected": []})


def cmd_invert_selection():
    ensure_object_mode()
    run_op(bpy.ops.object.select_all, action="INVERT")
    return emit({"ok": True, "selected": [o.name for o in bpy.context.selected_objects]})


def cmd_select_children():
    objs = named_or_sel()
    kids = []
    for o in objs:
        kids.extend(list(o.children_recursive) if hasattr(o, "children_recursive") else list(o.children))
    select_only(kids or objs)
    return emit({"ok": True, "selected": [o.name for o in (kids or objs)]})


def cmd_get_selection():
    sel = list(bpy.context.selected_objects)
    act = active()
    return emit({"ok": True, "selected": [o.name for o in sel], "active": act.name if act else None})


def cmd_capture_id():
    if ARGS.get("objects") or ARGS.get("name"):
        objs = named_or_sel()
    else:
        objs = list(bpy.context.selected_objects)
    items = []
    for o in objs:
        rec = {
            "name": o.name,
            "type": o.type,
            "session_uid": int(getattr(o, "session_uid", 0) or 0),
            "data": o.data.name if getattr(o, "data", None) else None,
            "data_session_uid": int(getattr(o.data, "session_uid", 0) or 0) if getattr(o, "data", None) else None,
            "location": [round(float(o.location.x), 5), round(float(o.location.y), 5), round(float(o.location.z), 5)],
            "materials": [s.material.name for s in o.material_slots if s.material],
            "collections": [c.name for c in o.users_collection],
        }
        items.append(rec)
    act = active()
    msg = ("captured %d id(s)" % len(items)) if items else "nothing selected"
    return emit({"ok": True, "count": len(items), "items": items, "active": act.name if act else None, "text": msg})


def cmd_transform():
    ensure_object_mode()
    objs = named_or_sel()
    if not objs:
        return emit({"ok": False, "error": "no objects to transform"})
    loc = ARGS.get("location")
    rot = ARGS.get("rotation")
    rot_deg = ARGS.get("rotation_deg") or ARGS.get("degrees")
    sca = ARGS.get("scale")
    dim = ARGS.get("dimensions") or ARGS.get("size")
    changed = []
    for o in objs:
        if loc is not None:
            o.location = vec3("location", tuple(o.location))
        if rot_deg is not None:
            d = vec3("rotation_deg", vec3("degrees"))
            o.rotation_euler = [math.radians(x) for x in d]
        elif rot is not None:
            o.rotation_euler = vec3("rotation", tuple(o.rotation_euler))
        if sca is not None:
            if isinstance(sca, (int, float)):
                o.scale = (float(sca), float(sca), float(sca))
            else:
                o.scale = vec3("scale", tuple(o.scale))
        if dim is not None and hasattr(o, "dimensions"):
            if isinstance(dim, (int, float)):
                o.dimensions = (float(dim), float(dim), float(dim))
            else:
                o.dimensions = Vector(vec3("dimensions", vec3("size", tuple(o.dimensions))))
        changed.append(o.name)
    return emit({"ok": True, "objects": changed})


def cmd_translate():
    ensure_object_mode()
    objs = named_or_sel()
    off = vec3("offset", vec3("location", (0, 0, 0)))
    for o in objs:
        o.location = Vector(o.location) + Vector(off)
    return emit({"ok": True, "objects": [o.name for o in objs], "offset": list(off)})


def cmd_rotate_deg():
    ensure_object_mode()
    objs = named_or_sel()
    d = vec3("rotation_deg", vec3("degrees", (0, 0, 0)))
    add = bool(ARGS.get("add", False))
    for o in objs:
        rad = [math.radians(x) for x in d]
        if add:
            o.rotation_euler = [a + b for a, b in zip(list(o.rotation_euler), rad)]
        else:
            o.rotation_euler = rad
    return emit({"ok": True, "objects": [o.name for o in objs], "rotation_deg": list(d)})


def cmd_set_dimensions():
    ensure_object_mode()
    objs = named_or_sel()
    dim = ARGS.get("dimensions") or ARGS.get("size")
    if dim is None:
        return emit({"ok": False, "error": "dimensions [x,y,z] required"})
    for o in objs:
        if isinstance(dim, (int, float)):
            o.dimensions = (float(dim), float(dim), float(dim))
        else:
            o.dimensions = Vector(vec3("dimensions", vec3("size")))
    return emit({"ok": True, "objects": [o.name for o in objs], "dimensions": [list(o.dimensions) for o in objs]})


def cmd_apply_transforms():
    ensure_object_mode()
    objs = named_or_sel()
    select_only(objs)
    run_op(bpy.ops.object.transform_apply, location=bool(ARGS.get("location", False)),
           rotation=bool(ARGS.get("rotation", True)), scale=bool(ARGS.get("scale", True)))
    return emit({"ok": True, "objects": [o.name for o in objs]})


def cmd_set_origin():
    ensure_object_mode()
    objs = named_or_sel()
    select_only(objs)
    kind = str(ARGS.get("type") or "ORIGIN_GEOMETRY")
    run_op(bpy.ops.object.origin_set, type=kind)
    return emit({"ok": True, "objects": [o.name for o in objs], "type": kind})


def cmd_origin_to_bottom():
    ensure_object_mode()
    objs = named_or_sel()
    done = []
    scene = bpy.context.scene
    for obj in objs:
        if obj.type != "MESH" or obj.data is None or len(obj.data.vertices) == 0:
            continue
        mw = obj.matrix_world
        world = [mw @ v.co for v in obj.data.vertices]
        min_z = min(c.z for c in world)
        mid_x = (min(c.x for c in world) + max(c.x for c in world)) / 2.0
        mid_y = (min(c.y for c in world) + max(c.y for c in world)) / 2.0
        scene.cursor.location = (mid_x, mid_y, min_z)
        select_only([obj])
        run_op(bpy.ops.object.origin_set, type="ORIGIN_CURSOR")
        done.append(obj.name)
    return emit({"ok": True, "objects": done})


def cmd_drop_to_ground():
    ensure_object_mode()
    objs = named_or_sel()
    done = []
    for obj in objs:
        if obj.type != "MESH" or obj.data is None or len(obj.data.vertices) == 0:
            obj.location.z = 0
            done.append(obj.name)
            continue
        mw = obj.matrix_world
        min_z = min((mw @ v.co).z for v in obj.data.vertices)
        obj.location.z -= min_z
        done.append(obj.name)
    return emit({"ok": True, "objects": done})


def cmd_center():
    ensure_object_mode()
    objs = named_or_sel()
    for o in objs:
        o.location = (0.0, 0.0, 0.0)
    return emit({"ok": True, "objects": [o.name for o in objs]})


def cmd_snap_to_grid():
    ensure_object_mode()
    objs = named_or_sel()
    step = float(ARGS.get("step") or 1)
    for o in objs:
        o.location = Vector((round(o.location.x / step) * step, round(o.location.y / step) * step, round(o.location.z / step) * step))
    return emit({"ok": True, "objects": [o.name for o in objs], "step": step})


def cmd_shade_smooth():
    ensure_object_mode()
    objs = named_or_sel()
    select_only(objs)
    try:
        run_op(bpy.ops.object.shade_smooth)
    except Exception:
        for o in objs:
            if o.type == "MESH":
                for p in o.data.polygons:
                    p.use_smooth = True
    return emit({"ok": True, "objects": [o.name for o in objs]})


def cmd_shade_flat():
    ensure_object_mode()
    objs = named_or_sel()
    select_only(objs)
    try:
        run_op(bpy.ops.object.shade_flat)
    except Exception:
        for o in objs:
            if o.type == "MESH":
                for p in o.data.polygons:
                    p.use_smooth = False
    return emit({"ok": True, "objects": [o.name for o in objs]})


def cmd_set_material():
    name = str(ARGS.get("name") or ARGS.get("object") or "")
    objs = named_or_sel() if not name else [bpy.data.objects.get(name) or active()]
    objs = [o for o in objs if o is not None]
    if not objs:
        return emit({"ok": False, "error": "mesh object required"})
    mat_name = str(ARGS.get("material") or ((objs[0].name if objs else "Total") + "_Mat"))
    color = ARGS.get("color") or ARGS.get("rgb") or [0.8, 0.8, 0.8, 1]
    if len(color) == 3:
        color = list(color) + [1]
    mat = bpy.data.materials.get(mat_name) or bpy.data.materials.new(mat_name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = tuple(float(c) for c in color[:4])
    assigned = []
    for obj in objs:
        if obj.type != "MESH":
            continue
        if obj.data.materials:
            obj.data.materials[0] = mat
        else:
            obj.data.materials.append(mat)
        assigned.append(obj.name)
    return emit({"ok": True, "objects": assigned, "material": mat.name, "color": color})


def cmd_add_modifier():
    obj = bpy.data.objects.get(str(ARGS.get("name") or ARGS.get("object") or "")) or active()
    if obj is None:
        objs = named_or_sel()
        obj = objs[0] if objs else None
    if obj is None:
        return emit({"ok": False, "error": "object required"})
    kind = str(ARGS.get("type") or ARGS.get("modifier") or "SUBSURF").upper()
    alias = {"SUBSURF": "SUBSURF", "SUBDIVISION": "SUBSURF", "BEVEL": "BEVEL", "SOLIDIFY": "SOLIDIFY",
             "MIRROR": "MIRROR", "ARRAY": "ARRAY", "BOOLEAN": "BOOLEAN", "DECIMATE": "DECIMATE",
             "TRIANGULATE": "TRIANGULATE", "REMESH": "REMESH", "WELD": "WELD"}
    kind = alias.get(kind, kind)
    if kind not in set(alias.values()):
        return emit({"ok": False, "error": "unsupported modifier type: " + kind, "error_class": "invalid_enum", "deterministic": True,
                     "value": kind, "allowed": sorted(set(alias.values())),
                     "hint": "pick one of " + ", ".join(sorted(set(alias.values()))) + " (blender_add_modifier type) - other modifiers need blender_execute_code"})
    try:
        mod = obj.modifiers.new(name=kind.title(), type=kind)
    except Exception as exc:
        return emit(classify_exception(exc, "add_modifier"))
    if mod is None:
        return emit({"ok": False, "error": "Blender refused modifier " + kind + " on " + obj.name + " (" + obj.type + ")", "error_class": "invalid_context",
                     "hint": "this modifier only applies to MESH objects - check the object type with blender_introspect"})
    if kind == "SUBSURF":
        mod.levels = int(ARGS.get("levels") or 1)
    if kind == "BEVEL":
        mod.width = float(ARGS.get("width") or 0.02)
        mod.segments = int(ARGS.get("segments") or 2)
    if kind == "SOLIDIFY":
        mod.thickness = float(ARGS.get("thickness") or 0.05)
    if kind == "ARRAY":
        mod.count = int(ARGS.get("count") or 3)
        off = ARGS.get("offset")
        if off is not None:
            mod.use_relative_offset = True
            mod.relative_offset_displace = vec3("offset", (1, 0, 0))
    if kind == "MIRROR":
        axis = str(ARGS.get("axis") or "X").upper()
        mod.use_axis = (axis == "X", axis == "Y", axis == "Z")
    if kind == "DECIMATE":
        mod.ratio = float(ARGS.get("ratio") or 0.5)
    if kind == "BOOLEAN":
        target = bpy.data.objects.get(str(ARGS.get("target") or ""))
        if target:
            mod.object = target
            mod.operation = str(ARGS.get("operation") or "DIFFERENCE")
    if ARGS.get("apply"):
        ensure_object_mode()
        select_only([obj])
        try:
            run_op(bpy.ops.object.modifier_apply, modifier=mod.name)
        except Exception:
            pass
    return emit({"ok": True, "object": obj.name, "modifier": kind})


def cmd_boolean():
    ARGS["type"] = "BOOLEAN"
    if "apply" not in ARGS:
        ARGS["apply"] = True
    return cmd_add_modifier()


def cmd_apply_modifiers():
    ensure_object_mode()
    objs = named_or_sel()
    applied = []
    for obj in objs:
        select_only([obj])
        for mod in list(obj.modifiers):
            try:
                run_op(bpy.ops.object.modifier_apply, modifier=mod.name)
                applied.append(obj.name + ":" + mod.name)
            except Exception:
                try:
                    obj.modifiers.remove(mod)
                except Exception:
                    pass
    return emit({"ok": True, "applied": applied})


def cmd_remove_modifier():
    objs = named_or_sel()
    kind = str(ARGS.get("type") or ARGS.get("modifier") or "").upper()
    removed = []
    for obj in objs:
        for mod in list(obj.modifiers):
            if not kind or mod.type == kind or mod.name.upper() == kind:
                obj.modifiers.remove(mod)
                removed.append(obj.name)
    return emit({"ok": True, "objects": removed})


def cmd_triangulate():
    objs = [o for o in named_or_sel() if o.type == "MESH"]
    if not objs:
        return emit({"ok": False, "error": "no mesh"})
    in_edit(objs, lambda: run_op(bpy.ops.mesh.quads_convert_to_tris))
    return emit({"ok": True, "objects": [o.name for o in objs]})


def cmd_decimate():
    ARGS["type"] = "DECIMATE"
    ARGS["apply"] = True if "apply" not in ARGS else ARGS.get("apply")
    return cmd_add_modifier()


def cmd_merge():
    objs = [o for o in named_or_sel() if o.type == "MESH"]
    dist = float(ARGS.get("distance") or 0.0001)
    def _m():
        try:
            run_op(bpy.ops.mesh.merge_by_distance, threshold=dist)
        except Exception:
            try:
                run_op(bpy.ops.mesh.remove_doubles, threshold=dist)
            except TypeError:
                run_op(bpy.ops.mesh.remove_doubles)
    in_edit(objs, _m)
    return emit({"ok": True, "objects": [o.name for o in objs], "distance": dist})


def cmd_recalc_normals():
    objs = [o for o in named_or_sel() if o.type == "MESH"]
    in_edit(objs, lambda: run_op(bpy.ops.mesh.normals_make_consistent, inside=bool(ARGS.get("inside", False))))
    return emit({"ok": True, "objects": [o.name for o in objs]})


def cmd_flip_normals():
    objs = [o for o in named_or_sel() if o.type == "MESH"]
    in_edit(objs, lambda: run_op(bpy.ops.mesh.flip_normals))
    return emit({"ok": True, "objects": [o.name for o in objs]})


def cmd_separate_loose():
    objs = [o for o in named_or_sel() if o.type == "MESH"]
    if not objs:
        return emit({"ok": False, "error": "no mesh"})
    before = set(bpy.data.objects.keys())
    in_edit(objs, lambda: run_op(bpy.ops.mesh.separate, type="LOOSE"))
    added = [k for k in bpy.data.objects.keys() if k not in before]
    return emit({"ok": True, "objects": added or [o.name for o in objs]})


def cmd_subdivide():
    objs = [o for o in named_or_sel() if o.type == "MESH"]
    cuts = int(ARGS.get("cuts") or ARGS.get("levels") or 1)
    in_edit(objs, lambda: run_op(bpy.ops.mesh.subdivide, number_cuts=cuts))
    return emit({"ok": True, "objects": [o.name for o in objs], "cuts": cuts})


def cmd_uv_unwrap():
    objs = [o for o in named_or_sel() if o.type == "MESH"]
    if not objs:
        return emit({"ok": False, "error": "no mesh"})
    def _u():
        try:
            run_op(bpy.ops.uv.smart_project)
        except Exception:
            run_op(bpy.ops.uv.unwrap)
    in_edit(objs, _u)
    return emit({"ok": True, "objects": [o.name for o in objs]})


def cmd_array():
    ensure_object_mode()
    objs = named_or_sel()
    count = int(ARGS.get("count") or 3)
    offset = Vector(vec3("offset", (2, 0, 0)))
    unique = bool(ARGS.get("unique", True))
    created = []
    for o in objs:
        for i in range(1, count):
            dup = o.copy()
            if unique and getattr(o, "data", None) is not None:
                try:
                    dup.data = o.data.copy()
                except Exception:
                    pass
            dup.location = Vector(o.location) + offset * i
            bpy.context.scene.collection.objects.link(dup)
            created.append(dup.name)
    return emit({"ok": True, "objects": created, "count": count})


def cmd_mirror():
    ensure_object_mode()
    objs = named_or_sel()
    axis = str(ARGS.get("axis") or "X").upper()
    idx = {"X": 0, "Y": 1, "Z": 2}.get(axis, 0)
    created = []
    for o in objs:
        dup = o.copy()
        if getattr(o, "data", None) is not None:
            try:
                dup.data = o.data.copy()
            except Exception:
                pass
        bpy.context.scene.collection.objects.link(dup)
        sc = list(dup.scale)
        sc[idx] = -abs(sc[idx]) if sc[idx] != 0 else -1
        dup.scale = sc
        created.append(dup.name)
        select_only([dup])
        try:
            run_op(bpy.ops.object.transform_apply, location=False, rotation=False, scale=True)
        except Exception:
            pass
    return emit({"ok": True, "objects": created, "axis": axis})


def cmd_hide():
    objs = named_or_sel()
    for o in objs:
        try:
            o.hide_set(True)
        except Exception:
            o.hide_viewport = True
    return emit({"ok": True, "hidden": [o.name for o in objs]})


def cmd_unhide():
    names = as_list(ARGS.get("objects") or ([ARGS.get("name")] if ARGS.get("name") else None))
    objs = [bpy.data.objects.get(str(n)) for n in names] if names else list(bpy.data.objects)
    objs = [o for o in objs if o]
    for o in objs:
        try:
            o.hide_set(False)
        except Exception:
            o.hide_viewport = False
    return emit({"ok": True, "unhidden": [o.name for o in objs]})


def cmd_unhide_all():
    names = []
    for o in bpy.data.objects:
        try:
            o.hide_set(False)
        except Exception:
            o.hide_viewport = False
        names.append(o.name)
    return emit({"ok": True, "unhidden": names})


def cmd_hide_unselected():
    sel = set(bpy.context.selected_objects)
    hidden = []
    for o in bpy.data.objects:
        if o not in sel:
            try:
                o.hide_set(True)
            except Exception:
                o.hide_viewport = True
            hidden.append(o.name)
    return emit({"ok": True, "hidden": hidden})


def cmd_undo():
    try:
        bpy.ops.ed.undo()
    except Exception:
        run_op(bpy.ops.ed.undo)
    return emit({"ok": True, "undo": True})


def cmd_redo():
    try:
        bpy.ops.ed.redo()
    except Exception:
        run_op(bpy.ops.ed.redo)
    return emit({"ok": True, "redo": True})


def cmd_frame_selected():
    objs = named_or_sel()
    select_only(objs)
    try:
        run_op(bpy.ops.view3d.view_selected)
    except Exception:
        pass
    return emit({"ok": True, "objects": [o.name for o in objs]})


def cmd_stats():
    items = []
    for o in named_or_sel() or list(bpy.data.objects):
        verts = faces = 0
        if o.type == "MESH" and o.data:
            verts = len(o.data.vertices)
            faces = len(o.data.polygons)
        items.append({"name": o.name, "type": o.type, "verts": verts, "faces": faces,
                      "modifiers": [m.type for m in o.modifiers]})
    return emit({"ok": True, "objects": items})


def cmd_save_blend():
    fp = str(ARGS.get("filepath") or ARGS.get("path") or "").strip()
    if not fp:
        fp = os.path.join(default_dir(), "total_scene.blend")
    if not fp.lower().endswith(".blend"):
        fp += ".blend"
    os.makedirs(os.path.dirname(fp) or ".", exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=fp)
    return emit({"ok": True, "filepath": fp})


def cmd_look_at():
    obj = bpy.data.objects.get(str(ARGS.get("name") or "")) or active()
    if obj is None:
        return emit({"ok": False, "error": "object required"})
    target = bpy.data.objects.get(str(ARGS.get("target") or ""))
    if target is not None:
        loc = target.matrix_world.translation
    else:
        loc = Vector(vec3("location", (0, 0, 0)))
    direction = loc - obj.matrix_world.translation
    if direction.length < 1e-8:
        return emit({"ok": False, "error": "target is at the same location"})
    obj.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()
    return emit({"ok": True, "name": obj.name, "target": list(loc)})


def cmd_convert_to_mesh():
    ensure_object_mode()
    objs = named_or_sel()
    select_only(objs)
    try:
        run_op(bpy.ops.object.convert, target="MESH")
    except Exception as e:
        return emit({"ok": False, "error": str(e)})
    return emit({"ok": True, "objects": [o.name for o in bpy.context.selected_objects]})


def cmd_add_empty():
    ensure_object_mode()
    loc = vec3("location", (0, 0, 0))
    empty = bpy.data.objects.new(str(ARGS.get("name") or "Empty"), None)
    empty.location = loc
    bpy.context.scene.collection.objects.link(empty)
    return emit({"ok": True, "name": empty.name, "type": "EMPTY"})


def cmd_add_camera():
    ensure_object_mode()
    loc = vec3("location", (7.5, -6.5, 5.5))
    run_op(bpy.ops.object.camera_add, location=loc)
    obj = active()
    set_name(obj, ARGS.get("name") or "Camera")
    return emit({"ok": True, "name": obj.name if obj else "Camera", "type": "CAMERA"})


def cmd_add_light():
    ensure_object_mode()
    loc = vec3("location", (4, -4, 6))
    kind = str(ARGS.get("type") or "SUN").upper()
    if kind not in ("SUN", "POINT", "SPOT", "AREA"):
        kind = "SUN"
    run_op(bpy.ops.object.light_add, type=kind, location=loc)
    obj = active()
    set_name(obj, ARGS.get("name") or kind.title())
    energy = ARGS.get("energy")
    if energy is not None and obj and obj.data:
        try:
            obj.data.energy = float(energy)
        except Exception:
            pass
    return emit({"ok": True, "name": obj.name if obj else kind, "type": "LIGHT", "light": kind})


def cmd_add_text():
    ensure_object_mode()
    loc = vec3("location", (0, 0, 0))
    run_op(bpy.ops.object.text_add, location=loc)
    obj = active()
    set_name(obj, ARGS.get("name") or "Text")
    if obj and obj.data:
        obj.data.body = str(ARGS.get("text") or ARGS.get("body") or "TotalScript")
        if ARGS.get("extrude") is not None:
            try:
                obj.data.extrude = float(ARGS.get("extrude"))
            except Exception:
                pass
    return emit({"ok": True, "name": obj.name if obj else "Text", "type": "FONT"})


def cmd_clear_scene():
    ensure_object_mode()
    keep = set(str(x) for x in (ARGS.get("keep") or []))
    removed = []
    for o in list(bpy.data.objects):
        if o.name in keep:
            continue
        removed.append(o.name)
        try:
            bpy.data.objects.remove(o, do_unlink=True)
        except Exception:
            pass
    return emit({"ok": True, "deleted": removed})



def cmd_align_camera_axis():
    axis = str(ARGS.get("axis") or ARGS.get("view") or "front").lower().replace(" ", "_")
    dist = float(ARGS.get("distance") or 12.0)
    target = bpy.data.objects.get(str(ARGS.get("target") or ""))
    if target is not None:
        center = target.matrix_world.translation.copy()
    else:
        sel = [o for o in bpy.context.selected_objects if getattr(o, "type", "") != "CAMERA"]
        if sel:
            acc = Vector((0.0, 0.0, 0.0))
            for o in sel:
                acc += o.matrix_world.translation
            center = acc / float(len(sel))
        else:
            center = Vector(vec3("location", (0.0, 0.0, 0.0)))
    offsets = {
        "front": Vector((0.0, -dist, 0.0)),
        "back": Vector((0.0, dist, 0.0)),
        "right": Vector((dist, 0.0, 0.0)),
        "left": Vector((-dist, 0.0, 0.0)),
        "top": Vector((0.0, 0.0, dist)),
        "bottom": Vector((0.0, 0.0, -dist)),
        "iso": Vector((dist * 0.72, -dist * 0.72, dist * 0.62)),
        "camera": Vector((dist * 0.72, -dist * 0.72, dist * 0.62)),
    }
    off = offsets.get(axis, offsets["front"])
    cam = bpy.data.objects.get(str(ARGS.get("name") or ""))
    if cam is None or getattr(cam, "type", "") != "CAMERA":
        cam = next((o for o in bpy.data.objects if o.type == "CAMERA"), None)
    if cam is None:
        ensure_object_mode()
        run_op(bpy.ops.object.camera_add, location=tuple(center + off))
        cam = active()
        set_name(cam, ARGS.get("name") or "Camera")
    else:
        cam.location = center + off
    direction = center - cam.matrix_world.translation
    if direction.length > 1e-8:
        cam.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()
    try:
        bpy.context.scene.camera = cam
    except Exception:
        pass
    ov = view_override()
    if ov:
        try:
            with bpy.context.temp_override(**ov):
                bpy.ops.view3d.view_camera()
        except Exception:
            pass
    return emit({"ok": True, "name": cam.name if cam else "Camera", "axis": axis, "location": list(cam.location) if cam else None})


def cmd_view_axis():
    axis = str(ARGS.get("axis") or ARGS.get("view") or "FRONT").upper()
    aliases = {"ISO": "iso", "CAMERA": "iso", "PERSP": "iso"}
    if axis in aliases:
        ARGS["axis"] = aliases[axis]
        return cmd_align_camera_axis()
    mapping = {"FRONT": "FRONT", "BACK": "BACK", "LEFT": "LEFT", "RIGHT": "RIGHT", "TOP": "TOP", "BOTTOM": "BOTTOM"}
    typ = mapping.get(axis, "FRONT")
    ov = view_override()
    if not ov:
        return emit({"ok": False, "error": "no 3D viewport to align"})
    try:
        with bpy.context.temp_override(**ov):
            bpy.ops.view3d.view_axis(type=typ)
    except Exception as e:
        return emit({"ok": False, "error": str(e)})
    return emit({"ok": True, "axis": typ})


def cmd_camera_to_view():
    ov = view_override()
    if not ov:
        return emit({"ok": False, "error": "no 3D viewport"})
    try:
        with bpy.context.temp_override(**ov):
            bpy.ops.view3d.camera_to_view()
    except Exception as e:
        return emit({"ok": False, "error": str(e)})
    cam = getattr(bpy.context.scene, "camera", None)
    return emit({"ok": True, "name": cam.name if cam else None})


def cmd_set_camera_lens():
    cam = bpy.data.objects.get(str(ARGS.get("name") or ""))
    if cam is None or getattr(cam, "type", "") != "CAMERA":
        cam = getattr(bpy.context.scene, "camera", None)
    if cam is None or getattr(cam, "type", "") != "CAMERA":
        cam = next((o for o in bpy.data.objects if o.type == "CAMERA"), None)
    if cam is None or cam.type != "CAMERA":
        return emit({"ok": False, "error": "no camera in the scene"})
    data = cam.data
    if ARGS.get("lens") is not None:
        try:
            data.lens = float(ARGS.get("lens"))
        except Exception:
            pass
    if ARGS.get("clip_start") is not None:
        try:
            data.clip_start = float(ARGS.get("clip_start"))
        except Exception:
            pass
    if ARGS.get("clip_end") is not None:
        try:
            data.clip_end = float(ARGS.get("clip_end"))
        except Exception:
            pass
    if ARGS.get("ortho") is True:
        data.type = "ORTHO"
        if ARGS.get("ortho_scale") is not None:
            try:
                data.ortho_scale = float(ARGS.get("ortho_scale"))
            except Exception:
                pass
    elif ARGS.get("ortho") is False:
        data.type = "PERSP"
    return emit({"ok": True, "name": cam.name, "lens": getattr(data, "lens", None), "type": data.type})



def cmd_scale():
    ensure_object_mode()
    objs = named_or_sel()
    s = vec3("scale", vec3("factor", (1.0, 1.0, 1.0)))
    mul = ARGS.get("multiply")
    if mul is None:
        mul = True
    names = []
    for o in objs:
        if mul:
            o.scale = Vector((o.scale[0] * s[0], o.scale[1] * s[1], o.scale[2] * s[2]))
        else:
            o.scale = Vector(s)
        names.append(o.name)
    return emit({"ok": True, "objects": names, "scale": list(s), "multiply": bool(mul)})


def cmd_bevel():
    objs = [o for o in named_or_sel() if o.type == "MESH"]
    width = float(ARGS.get("width") or ARGS.get("offset") or 0.05)
    segs = int(ARGS.get("segments") or 2)
    if not objs:
        return emit({"ok": False, "error": "no mesh selected"})
    in_edit(objs, lambda: run_op(bpy.ops.mesh.bevel, offset=width, segments=max(1, segs)))
    return emit({"ok": True, "objects": [o.name for o in objs], "width": width, "segments": segs})


def cmd_solidify():
    thickness = float(ARGS.get("thickness") or 0.1)
    objs = [o for o in named_or_sel() if o.type == "MESH"]
    if not objs:
        return emit({"ok": False, "error": "no mesh selected"})
    names = []
    for o in objs:
        m = o.modifiers.new(name="Solidify", type="SOLIDIFY")
        m.thickness = thickness
        names.append(o.name)
    return emit({"ok": True, "objects": names, "thickness": thickness})


def cmd_extrude():
    objs = [o for o in named_or_sel() if o.type == "MESH"]
    dist = float(ARGS.get("distance") or ARGS.get("offset") or 0.5)
    if not objs:
        return emit({"ok": False, "error": "no mesh selected"})
    def _fn():
        run_op(bpy.ops.mesh.extrude_region)
        run_op(bpy.ops.transform.translate, value=(0.0, 0.0, dist), orient_type="NORMAL")
    in_edit(objs, _fn)
    return emit({"ok": True, "objects": [o.name for o in objs], "distance": dist})


def cmd_add_curve():
    ensure_object_mode()
    loc = vec3("location", (0.0, 0.0, 0.0))
    run_op(bpy.ops.curve.primitive_bezier_curve_add, location=loc)
    obj = active()
    set_name(obj, ARGS.get("name") or "Curve")
    return emit({"ok": True, "name": obj.name if obj else None})


def cmd_add_armature():
    ensure_object_mode()
    loc = vec3("location", (0.0, 0.0, 0.0))
    run_op(bpy.ops.object.armature_add, location=loc)
    obj = active()
    set_name(obj, ARGS.get("name") or "Armature")
    return emit({"ok": True, "name": obj.name if obj else None})


def cmd_keyframe_insert():
    scene = bpy.context.scene
    frame = int(ARGS.get("frame") if ARGS.get("frame") is not None else scene.frame_current)
    data_path = str(ARGS.get("data_path") or "location")
    objs = named_or_sel()
    try:
        scene.frame_set(frame)
    except Exception:
        pass
    names = []
    for o in objs:
        inserted = False
        for path in (data_path, "location", "rotation_euler", "scale"):
            try:
                o.keyframe_insert(data_path=path)
                inserted = True
                if path == data_path:
                    break
            except Exception:
                continue
        if inserted:
            names.append(o.name)
    return emit({"ok": True, "frame": frame, "objects": names, "data_path": data_path})


def cmd_set_frame():
    frame = int(ARGS.get("frame") or 1)
    bpy.context.scene.frame_set(frame)
    return emit({"ok": True, "frame": int(bpy.context.scene.frame_current)})


def cmd_set_active_camera():
    name = str(ARGS.get("name") or "")
    cam = bpy.data.objects.get(name) if name else None
    if cam is None or getattr(cam, "type", "") != "CAMERA":
        cam = getattr(bpy.context.scene, "camera", None)
    if cam is None or getattr(cam, "type", "") != "CAMERA":
        cam = next((o for o in bpy.data.objects if o.type == "CAMERA"), None)
    if cam is None or getattr(cam, "type", "") != "CAMERA":
        return emit({"ok": False, "error": "no camera in the scene"})
    bpy.context.scene.camera = cam
    return emit({"ok": True, "camera": cam.name})


def cmd_track_to():
    target = bpy.data.objects.get(str(ARGS.get("target") or ""))
    if target is None:
        return emit({"ok": False, "error": "target object required"})
    objs = named_or_sel()
    names = []
    for o in objs:
        if o == target:
            continue
        c = o.constraints.new(type="TRACK_TO")
        c.target = target
        try:
            c.track_axis = "TRACK_NEGATIVE_Z"
            c.up_axis = "UP_Y"
        except Exception:
            pass
        names.append(o.name)
    return emit({"ok": True, "objects": names, "target": target.name})


def cmd_cursor_to_selected():
    objs = named_or_sel()
    if not objs:
        return emit({"ok": False, "error": "nothing selected"})
    acc = Vector((0.0, 0.0, 0.0))
    for o in objs:
        acc += o.matrix_world.translation
    loc = acc / float(len(objs))
    bpy.context.scene.cursor.location = loc
    return emit({"ok": True, "cursor": [loc.x, loc.y, loc.z], "objects": [o.name for o in objs]})


def cmd_randomize_transform():
    import random
    objs = named_or_sel()
    loc_amt = float(ARGS.get("location") or 0.5)
    rot_amt = float(ARGS.get("rotation") or 0.0)
    scl_amt = float(ARGS.get("scale") or 0.0)
    if ARGS.get("seed") is not None:
        random.seed(int(ARGS.get("seed")))
    names = []
    for o in objs:
        o.location = Vector(o.location) + Vector((
            random.uniform(-loc_amt, loc_amt),
            random.uniform(-loc_amt, loc_amt),
            random.uniform(-loc_amt, loc_amt),
        ))
        if rot_amt:
            o.rotation_euler[2] += math.radians(random.uniform(-rot_amt, rot_amt))
        if scl_amt:
            f = 1.0 + random.uniform(-scl_amt, scl_amt)
            o.scale = Vector((o.scale[0] * f, o.scale[1] * f, o.scale[2] * f))
        names.append(o.name)
    return emit({"ok": True, "objects": names})


def cmd_hide_render():
    objs = named_or_sel()
    hide = ARGS.get("hide")
    if hide is None:
        hide = True
    for o in objs:
        o.hide_render = bool(hide)
    return emit({"ok": True, "objects": [o.name for o in objs], "hide_render": bool(hide)})


def cmd_subdivision():
    levels = int(ARGS.get("levels") or 2)
    render_levels = int(ARGS.get("render_levels") or max(levels, 2))
    objs = [o for o in named_or_sel() if o.type == "MESH"]
    if not objs:
        return emit({"ok": False, "error": "no mesh selected"})
    names = []
    for o in objs:
        m = o.modifiers.new(name="Subdivision", type="SUBSURF")
        m.levels = max(0, levels)
        m.render_levels = max(0, render_levels)
        names.append(o.name)
    return emit({"ok": True, "objects": names, "levels": levels})


def cmd_origin_to_geometry():
    ensure_object_mode()
    objs = named_or_sel()
    if not objs:
        return emit({"ok": False, "error": "nothing selected"})
    select_only(objs)
    run_op(bpy.ops.object.origin_set, type="ORIGIN_GEOMETRY")
    return emit({"ok": True, "objects": [o.name for o in objs]})




def cmd_export_gltf():
    path = ARGS.get("filepath") or os.path.join(default_dir(), "total_export.glb")
    fmt = str(ARGS.get("format") or ("GLB" if str(path).lower().endswith(".glb") else "GLTF_SEPARATE")).upper()
    objs = named_or_sel()
    if ARGS.get("objects"):
        select_only(objs)
    os.makedirs(os.path.dirname(path) or default_dir(), exist_ok=True)
    op = getattr(bpy.ops.export_scene, "gltf", None)
    if op is None:
        return emit({"ok": False, "error": "GLTF exporter is unavailable in this Blender installation"})
    op(filepath=path, export_format=fmt, use_selection=bool(ARGS.get("objects")))
    return emit({"ok": True, "filepath": path, "format": fmt, "objects": [o.name for o in objs]})


def cmd_import_gltf():
    path = str(ARGS.get("filepath") or "")
    if not path or not os.path.isfile(path):
        return emit({"ok": False, "error": "filepath does not exist"})
    before = set(bpy.data.objects.keys())
    op = getattr(bpy.ops.import_scene, "gltf", None)
    if op is None:
        return emit({"ok": False, "error": "GLTF importer is unavailable in this Blender installation"})
    op(filepath=path)
    return emit({"ok": True, "filepath": path, "objects": sorted(set(bpy.data.objects.keys()) - before)})


def cmd_scene_cleanup():
    removed = {"collections": 0, "materials": 0}
    if ARGS.get("empty_collections", True):
        for col in list(bpy.data.collections):
            if not col.objects and not col.children:
                bpy.data.collections.remove(col)
                removed["collections"] += 1
    if ARGS.get("unused_materials", False):
        for mat in list(bpy.data.materials):
            if mat.users == 0:
                bpy.data.materials.remove(mat)
                removed["materials"] += 1
    if ARGS.get("purge_orphans", True):
        try:
            for _ in range(3):
                bpy.ops.outliner.orphans_purge(do_recursive=True)
        except Exception:
            pass
    return emit({"ok": True, "removed": removed, "objects": len(bpy.data.objects)})


def cmd_set_world():
    world = bpy.context.scene.world or bpy.data.worlds.new("World")
    bpy.context.scene.world = world
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    color = ARGS.get("color") or [0.05, 0.05, 0.05, 1.0]
    rgba = list(color[:4]) + [1.0] * max(0, 4 - len(color))
    if bg:
        bg.inputs["Color"].default_value = rgba[:4]
        bg.inputs["Strength"].default_value = float(ARGS.get("strength") or 1.0)
    return emit({"ok": True, "color": rgba[:4], "strength": float(ARGS.get("strength") or 1.0)})


def cmd_set_render():
    scene = bpy.context.scene
    engine = str(ARGS.get("engine") or scene.render.engine)
    available = {getattr(x, "identifier", str(x)) for x in scene.render.bl_rna.properties["engine"].enum_items}
    if engine not in available:
        return emit({"ok": False, "error": "unsupported render engine: " + engine, "available": sorted(available)})
    scene.render.engine = engine
    scene.render.resolution_x = max(1, int(ARGS.get("width") or scene.render.resolution_x))
    scene.render.resolution_y = max(1, int(ARGS.get("height") or scene.render.resolution_y))
    if ARGS.get("filepath"):
        scene.render.filepath = str(ARGS["filepath"])
    if ARGS.get("frame_start") is not None: scene.frame_start = int(ARGS["frame_start"])
    if ARGS.get("frame_end") is not None: scene.frame_end = int(ARGS["frame_end"])
    samples = int(ARGS.get("samples") or 0)
    if samples:
        target = getattr(scene, "cycles", None) or getattr(scene, "eevee", None) or getattr(scene, "eevee_next", None)
        if target and hasattr(target, "samples"): target.samples = samples
    return emit({"ok": True, "engine": engine, "resolution": [scene.render.resolution_x, scene.render.resolution_y], "filepath": scene.render.filepath})


def cmd_render_image():
    scene = bpy.context.scene
    if not scene.camera:
        return emit({"ok": False, "error": "no active camera"})
    path = str(ARGS.get("filepath") or os.path.join(default_dir(), "total_render.png"))
    os.makedirs(os.path.dirname(path) or default_dir(), exist_ok=True)
    scene.render.filepath = path
    if ARGS.get("frame") is not None: scene.frame_set(int(ARGS["frame"]))
    bpy.ops.render.render(write_still=True)
    return emit({"ok": True, "filepath": path, "frame": scene.frame_current, "camera": scene.camera.name})


def cmd_principled_material():
    objs = named_or_sel()
    if not objs:
        return emit({"ok": False, "error": "nothing selected"})
    name = str(ARGS.get("material") or "Total_Material")
    mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if not bsdf:
        return emit({"ok": False, "error": "Principled BSDF node unavailable"})
    color = ARGS.get("color") or [0.8, 0.8, 0.8, 1.0]
    color = list(color[:4]) + [1.0] * max(0, 4 - len(color))
    bsdf.inputs["Base Color"].default_value = color[:4]
    bsdf.inputs["Metallic"].default_value = float(ARGS.get("metallic") or 0.0)
    bsdf.inputs["Roughness"].default_value = float(ARGS.get("roughness") if ARGS.get("roughness") is not None else 0.5)
    if ARGS.get("emission") is not None:
        socket = bsdf.inputs.get("Emission Color") or bsdf.inputs.get("Emission")
        if socket:
            emission = list(ARGS["emission"][:4]) + [1.0] * max(0, 4 - len(ARGS["emission"]))
            socket.default_value = emission[:4]
        strength = bsdf.inputs.get("Emission Strength")
        if strength: strength.default_value = float(ARGS.get("emission_strength") or 1.0)
    for obj in objs:
        if getattr(obj, "data", None) and hasattr(obj.data, "materials"):
            if obj.data.materials: obj.data.materials[0] = mat
            else: obj.data.materials.append(mat)
    return emit({"ok": True, "material": mat.name, "objects": [o.name for o in objs]})


def cmd_inset():
    objs = [o for o in named_or_sel() if o.type == "MESH"]
    if not objs: return emit({"ok": False, "error": "no mesh selected"})
    thickness = float(ARGS.get("thickness") or 0.1)
    depth = float(ARGS.get("depth") or 0.0)
    in_edit(objs, lambda: run_op(bpy.ops.mesh.inset, thickness=thickness, depth=depth))
    return emit({"ok": True, "objects": [o.name for o in objs], "thickness": thickness, "depth": depth})


def cmd_add_bone():
    arm = bpy.data.objects.get(str(ARGS.get("armature") or ""))
    if not arm or arm.type != "ARMATURE": return emit({"ok": False, "error": "armature not found"})
    select_only([arm]); run_op(bpy.ops.object.mode_set, mode="EDIT")
    try:
        bone = arm.data.edit_bones.new(str(ARGS.get("name") or "Bone"))
        bone.head = Vector(ARGS.get("head") or [0, 0, 0]); bone.tail = Vector(ARGS.get("tail") or [0, 0, 1])
        parent = arm.data.edit_bones.get(str(ARGS.get("parent") or ""))
        if parent: bone.parent = parent
        result = {"ok": True, "armature": arm.name, "bone": bone.name}
    finally: run_op(bpy.ops.object.mode_set, mode="OBJECT")
    return emit(result)


def cmd_normalize_weights():
    objs = [o for o in named_or_sel() if o.type == "MESH"]
    if not objs: return emit({"ok": False, "error": "no mesh selected"})
    for obj in objs:
        select_only([obj])
        if not obj.vertex_groups: continue
        run_op(bpy.ops.object.mode_set, mode="WEIGHT_PAINT")
        try: run_op(bpy.ops.object.vertex_group_normalize_all, lock_active=False)
        finally: run_op(bpy.ops.object.mode_set, mode="OBJECT")
    return emit({"ok": True, "objects": [o.name for o in objs]})



def cmd_scene_list():
    return emit({"ok": True, "scenes": [{"name": s.name, "objects": len(s.objects), "active": s == bpy.context.scene} for s in bpy.data.scenes]})

def cmd_scene_create():
    name = str(ARGS.get("name") or "Scene")
    scene = bpy.data.scenes.new(name)
    return emit({"ok": True, "name": scene.name})

def cmd_scene_delete():
    scene = bpy.data.scenes.get(str(ARGS.get("name") or ""))
    if scene is None: return emit({"ok": False, "error": "scene not found"})
    if len(bpy.data.scenes) <= 1: return emit({"ok": False, "error": "cannot delete the only scene"})
    name=scene.name; bpy.data.scenes.remove(scene); return emit({"ok": True, "deleted": name})

def cmd_scene_duplicate():
    src=bpy.data.scenes.get(str(ARGS.get("name") or "")) or bpy.context.scene
    copy=src.copy();copy.name=str(ARGS.get("new_name") or (src.name+" Copy"));return emit({"ok":True,"name":copy.name,"source":src.name})

def cmd_scene_set_active():
    scene=bpy.data.scenes.get(str(ARGS.get("name") or ""))
    if scene is None:return emit({"ok":False,"error":"scene not found"})
    try:bpy.context.window.scene=scene
    except Exception as e:return emit({"ok":False,"error":str(e)})
    return emit({"ok":True,"name":scene.name})

def cmd_get_transform():
    obj=bpy.data.objects.get(str(ARGS.get("name") or "")) or active()
    if obj is None:return emit({"ok":False,"error":"object required"})
    return emit({"ok":True,"name":obj.name,"location":list(obj.location),"rotation":list(obj.rotation_euler),"scale":list(obj.scale),"dimensions":list(obj.dimensions)})

def cmd_introspect():
    """Read-only self-check: Blender version, what the named/active object really is,
    its modifiers (with the settable properties), materials, dimensions and the
    operators/enums the other commands depend on. Nothing is changed."""
    info = {"ok": True, "blender": blender_version(), "mode": None, "object": None, "objects": [], "modifier_types": sorted(["SUBSURF", "BEVEL", "SOLIDIFY", "MIRROR", "ARRAY", "BOOLEAN", "DECIMATE", "TRIANGULATE", "REMESH", "WELD"]),
            "light_types": ["SUN", "POINT", "SPOT", "AREA"], "origin_types": ["ORIGIN_GEOMETRY", "ORIGIN_CURSOR", "ORIGIN_CENTER_OF_MASS", "ORIGIN_CENTER_OF_VOLUME", "GEOMETRY_ORIGIN"], "note": "read-only"}
    try:
        info["mode"] = bpy.context.mode
    except Exception:
        pass
    try:
        scene = bpy.context.scene
        info["render_engines"] = sorted({getattr(x, "identifier", str(x)) for x in scene.render.bl_rna.properties["engine"].enum_items})
        info["engine"] = scene.render.engine
        info["frame_range"] = [scene.frame_start, scene.frame_end]
        info["unit_scale"] = getattr(scene.unit_settings, "scale_length", 1.0)
    except Exception:
        pass
    try:
        info["objects"] = [{"name": o.name, "type": o.type, "visible": bool(o.visible_get()) if hasattr(o, "visible_get") else True} for o in bpy.data.objects][:200]
        info["materials"] = [m.name for m in bpy.data.materials][:200]
        info["collections"] = [c.name for c in bpy.data.collections][:200]
    except Exception:
        pass
    want = str(ARGS.get("name") or ARGS.get("object") or "")
    obj = bpy.data.objects.get(want) if want else active()
    if want and obj is None:
        info["ok"] = False
        info["error"] = "object not found: " + want
        info["error_class"] = "resource_missing"
        info["hint"] = "exact names only - pick one from objects[]"
        return emit(info)
    if obj is not None:
        d = {"name": obj.name, "type": obj.type, "parent": obj.parent.name if obj.parent else None, "modifiers": [], "materials": [], "custom_props": {}}
        for key, fn in (("location", lambda: [round(float(v), 4) for v in obj.location]), ("rotation_deg", lambda: [round(math.degrees(float(v)), 2) for v in obj.rotation_euler]),
                        ("scale", lambda: [round(float(v), 4) for v in obj.scale]), ("dimensions", lambda: [round(float(v), 4) for v in obj.dimensions]),
                        ("collections", lambda: [c.name for c in obj.users_collection])):
            try:
                d[key] = fn()
            except Exception:
                d[key] = None
        for mod in obj.modifiers:
            props = {}
            try:
                for pr in mod.bl_rna.properties:
                    if pr.identifier in ("rna_type", "name", "type") or getattr(pr, "is_readonly", False):
                        continue
                    val = getattr(mod, pr.identifier, None)
                    if isinstance(val, (int, float, bool, str)):
                        props[pr.identifier] = val
                    elif hasattr(val, "__len__") and not isinstance(val, (str, bytes)):
                        try:
                            props[pr.identifier] = [float(x) if isinstance(x, (int, float)) else str(x) for x in val][:4]
                        except Exception:
                            pass
                    elif val is not None and hasattr(val, "name"):
                        props[pr.identifier] = val.name
                    if len(props) >= 40:
                        break
            except Exception:
                pass
            d["modifiers"].append({"name": mod.name, "type": mod.type, "properties": props})
        if getattr(obj, "data", None) is not None and hasattr(obj.data, "materials"):
            d["materials"] = [m.name if m else None for m in obj.data.materials]
        if obj.type == "MESH":
            me = obj.data
            try:
                d["mesh"] = {"vertices": len(me.vertices), "edges": len(getattr(me, "edges", [])), "faces": len(me.polygons), "tris": sum(max(0, len(pg.vertices) - 2) for pg in me.polygons),
                             "uv_layers": [u.name for u in me.uv_layers], "smooth_faces": sum(1 for pg in me.polygons if getattr(pg, "use_smooth", False)), "has_custom_normals": bool(getattr(me, "has_custom_normals", False))}
            except Exception as exc:
                d["mesh"] = {"error": str(exc)[:200]}
        try:
            for k in obj.keys():
                if not str(k).startswith("_"):
                    v = obj[k]
                    d["custom_props"][str(k)] = v if isinstance(v, (int, float, bool, str)) else str(v)
        except Exception:
            pass
        info["object"] = d
    return emit(info)


def cmd_modifier_list():
    obj=bpy.data.objects.get(str(ARGS.get("name") or "")) or active()
    if obj is None:return emit({"ok":False,"error":"object required"})
    return emit({"ok":True,"name":obj.name,"modifiers":[{"name":m.name,"type":m.type,"show_viewport":m.show_viewport,"show_render":m.show_render} for m in obj.modifiers]})

def cmd_modifier_configure():
    obj=bpy.data.objects.get(str(ARGS.get("name") or "")) or active();mn=str(ARGS.get("modifier") or "")
    if obj is None:return emit({"ok":False,"error":"object required"})
    mod=obj.modifiers.get(mn)
    if mod is None:return emit({"ok":False,"error":"modifier not found: "+mn,"error_class":"resource_missing","available":[m.name for m in obj.modifiers],"hint":"use one of the listed modifier names (blender_modifier_list / blender_introspect)"})
    changed={}
    for key,value in dict(ARGS.get("properties") or {}).items():
        if key.startswith("_") or not hasattr(mod,key):
            props=[p.identifier for p in getattr(getattr(mod,"bl_rna",None),"properties",[]) if not getattr(p,"is_readonly",False) and p.identifier not in ("rna_type","name","type")] if hasattr(mod,"bl_rna") else []
            return emit({"ok":False,"error":"invalid modifier property: "+str(key),"error_class":"unknown_parameter","deterministic":True,"parameter":str(key),"available":props[:40],"hint":"blender_introspect {name} lists the real settable properties of each modifier in this Blender version"})
        try:setattr(mod,key,value);changed[key]=value
        except Exception as e:
            info=classify_exception(e,"modifier_configure");info["parameter"]=str(key);return emit(info)
    return emit({"ok":True,"name":obj.name,"modifier":mod.name,"changed":changed})

def cmd_material_create():
    name=str(ARGS.get("material") or ARGS.get("name") or "Material")
    if bpy.data.materials.get(name):return emit({"ok":False,"error":"material already exists"})
    mat=bpy.data.materials.new(name);mat.use_nodes=True;return emit({"ok":True,"material":mat.name})

def cmd_material_duplicate():
    src=bpy.data.materials.get(str(ARGS.get("material") or ARGS.get("name") or ""))
    if src is None:return emit({"ok":False,"error":"material not found"})
    copy=src.copy();copy.name=str(ARGS.get("new_name") or (src.name+" Copy"));return emit({"ok":True,"material":copy.name,"source":src.name})

def cmd_material_remove():
    mat=bpy.data.materials.get(str(ARGS.get("material") or ARGS.get("name") or ""))
    if mat is None:return emit({"ok":False,"error":"material not found"})
    name=mat.name;bpy.data.materials.remove(mat,do_unlink=True);return emit({"ok":True,"deleted":name})

def material_nodes():
    mat=bpy.data.materials.get(str(ARGS.get("material") or ""));
    if mat is None:return None,None
    mat.use_nodes=True;return mat,mat.node_tree

def cmd_node_inspect():
    mat,tree=material_nodes()
    if tree is None:return emit({"ok":False,"error":"material not found"})
    return emit({"ok":True,"material":mat.name,"nodes":[{"name":n.name,"type":n.bl_idname,"inputs":[i.name for i in n.inputs],"outputs":[o.name for o in n.outputs]} for n in tree.nodes],"links":[{"from":l.from_node.name,"from_socket":l.from_socket.name,"to":l.to_node.name,"to_socket":l.to_socket.name} for l in tree.links]})

def cmd_node_create():
    mat,tree=material_nodes()
    if tree is None:return emit({"ok":False,"error":"material not found"})
    try:n=tree.nodes.new(str(ARGS.get("type") or "ShaderNodeValue"));n.name=str(ARGS.get("name") or n.name);return emit({"ok":True,"node":n.name,"type":n.bl_idname})
    except Exception as e:return emit({"ok":False,"error":str(e)})

def cmd_node_delete():
    mat,tree=material_nodes();n=tree and tree.nodes.get(str(ARGS.get("name") or ""))
    if n is None:return emit({"ok":False,"error":"node not found"})
    name=n.name;tree.nodes.remove(n);return emit({"ok":True,"deleted":name})

def cmd_uv_inspect():
    rows=[]
    for obj in named_or_sel():
        if obj.type=="MESH":rows.append({"name":obj.name,"uv_layers":[u.name for u in obj.data.uv_layers],"active":obj.data.uv_layers.active.name if obj.data.uv_layers.active else None})
    return emit({"ok":True,"objects":rows})

def cmd_uv_pack():
    ensure_object_mode();objs=[o for o in named_or_sel() if o.type=="MESH"]
    if not objs:return emit({"ok":False,"error":"mesh object required"})
    select_only(objs);bpy.context.view_layer.objects.active=objs[0];bpy.ops.object.mode_set(mode="EDIT");bpy.ops.mesh.select_all(action="SELECT");bpy.ops.uv.pack_islands(margin=float(ARGS.get("margin") or 0.001));bpy.ops.object.mode_set(mode="OBJECT");return emit({"ok":True,"objects":[o.name for o in objs]})

def cmd_animation_list():
    rows=[]
    for obj in bpy.data.objects:
        ad=obj.animation_data
        if ad and ad.action:rows.append({"object":obj.name,"action":ad.action.name,"frame_range":list(ad.action.frame_range),"fcurves":len(ad.action.fcurves)})
    return emit({"ok":True,"animations":rows})

DISPATCH = {
    "scene_list": cmd_scene_list, "scene_create": cmd_scene_create, "scene_delete": cmd_scene_delete,
    "scene_duplicate": cmd_scene_duplicate, "scene_set_active": cmd_scene_set_active,
    "get_transform": cmd_get_transform, "modifier_list": cmd_modifier_list, "modifier_configure": cmd_modifier_configure,
    "material_create": cmd_material_create, "material_duplicate": cmd_material_duplicate, "material_remove": cmd_material_remove,
    "node_inspect": cmd_node_inspect, "node_create": cmd_node_create, "node_delete": cmd_node_delete,
    "uv_inspect": cmd_uv_inspect, "uv_pack": cmd_uv_pack, "animation_list": cmd_animation_list, "introspect": cmd_introspect,
    "export_gltf": cmd_export_gltf,
    "import_gltf": cmd_import_gltf,
    "scene_cleanup": cmd_scene_cleanup,
    "set_world": cmd_set_world,
    "set_render": cmd_set_render,
    "render_image": cmd_render_image,
    "principled_material": cmd_principled_material,
    "inset": cmd_inset,
    "add_bone": cmd_add_bone,
    "normalize_weights": cmd_normalize_weights,
    "export_fbx": cmd_export_fbx,
    "import_fbx": cmd_import_fbx,
    "export_obj": cmd_export_obj,
    "import_obj": cmd_import_obj,
    "dump": cmd_dump,
    "group": cmd_group,
    "ungroup": cmd_ungroup,
    "parent": cmd_parent,
    "unparent": cmd_unparent,
    "join": cmd_join,
    "move_to_collection": cmd_move_to_collection,
    "list_collections": cmd_list_collections,
    "list_objects": cmd_list_objects,
    "delete": cmd_delete,
    "duplicate": cmd_duplicate,
    "rename": cmd_rename,
    "select": cmd_select,
    "select_all": cmd_select_all,
    "deselect": cmd_deselect,
    "invert_selection": cmd_invert_selection,
    "select_children": cmd_select_children,
    "get_selection": cmd_get_selection,
    "capture_id": cmd_capture_id,
    "transform": cmd_transform,
    "translate": cmd_translate,
    "rotate_deg": cmd_rotate_deg,
    "set_dimensions": cmd_set_dimensions,
    "apply_transforms": cmd_apply_transforms,
    "set_origin": cmd_set_origin,
    "origin_to_bottom": cmd_origin_to_bottom,
    "drop_to_ground": cmd_drop_to_ground,
    "center": cmd_center,
    "snap_to_grid": cmd_snap_to_grid,
    "shade_smooth": cmd_shade_smooth,
    "shade_flat": cmd_shade_flat,
    "set_material": cmd_set_material,
    "add_modifier": cmd_add_modifier,
    "boolean": cmd_boolean,
    "apply_modifiers": cmd_apply_modifiers,
    "remove_modifier": cmd_remove_modifier,
    "triangulate": cmd_triangulate,
    "decimate": cmd_decimate,
    "merge": cmd_merge,
    "recalc_normals": cmd_recalc_normals,
    "flip_normals": cmd_flip_normals,
    "separate_loose": cmd_separate_loose,
    "subdivide": cmd_subdivide,
    "uv_unwrap": cmd_uv_unwrap,
    "array": cmd_array,
    "mirror": cmd_mirror,
    "hide": cmd_hide,
    "unhide": cmd_unhide,
    "unhide_all": cmd_unhide_all,
    "hide_unselected": cmd_hide_unselected,
    "undo": cmd_undo,
    "redo": cmd_redo,
    "frame_selected": cmd_frame_selected,
    "stats": cmd_stats,
    "save_blend": cmd_save_blend,
    "look_at": cmd_look_at,
    "convert_to_mesh": cmd_convert_to_mesh,
    "add_cube": lambda: add_primitive("primitive_cube_add", ARGS.get("name") or "Cube", {"size": float(ARGS.get("size") or 2)}),
    "add_sphere": lambda: add_primitive("primitive_uv_sphere_add", ARGS.get("name") or "Sphere", {"radius": float(ARGS.get("radius") or ARGS.get("size") or 1)}),
    "add_ico_sphere": lambda: add_primitive("primitive_ico_sphere_add", ARGS.get("name") or "IcoSphere", {"radius": float(ARGS.get("radius") or ARGS.get("size") or 1)}),
    "add_cylinder": lambda: add_primitive("primitive_cylinder_add", ARGS.get("name") or "Cylinder", {"radius": float(ARGS.get("radius") or 1), "depth": float(ARGS.get("depth") or ARGS.get("height") or 2)}),
    "add_cone": lambda: add_primitive("primitive_cone_add", ARGS.get("name") or "Cone", {"radius1": float(ARGS.get("radius") or 1), "depth": float(ARGS.get("depth") or ARGS.get("height") or 2)}),
    "add_plane": lambda: add_primitive("primitive_plane_add", ARGS.get("name") or "Plane", {"size": float(ARGS.get("size") or 2)}),
    "add_grid": lambda: add_primitive("primitive_grid_add", ARGS.get("name") or "Grid", {"size": float(ARGS.get("size") or 2)}),
    "add_circle": lambda: add_primitive("primitive_circle_add", ARGS.get("name") or "Circle", {"radius": float(ARGS.get("radius") or 1)}),
    "add_torus": lambda: add_primitive("primitive_torus_add", ARGS.get("name") or "Torus"),
    "add_monkey": lambda: add_primitive("primitive_monkey_add", ARGS.get("name") or "Suzanne"),
    "add_empty": cmd_add_empty,
    "add_camera": cmd_add_camera,
    "align_camera_axis": cmd_align_camera_axis,
    "view_axis": cmd_view_axis,
    "camera_to_view": cmd_camera_to_view,
    "set_camera_lens": cmd_set_camera_lens,
    "add_light": cmd_add_light,
    "add_text": cmd_add_text,
    "clear_scene": cmd_clear_scene,
    "scale": cmd_scale,
    "bevel": cmd_bevel,
    "solidify": cmd_solidify,
    "extrude": cmd_extrude,
    "add_curve": cmd_add_curve,
    "add_armature": cmd_add_armature,
    "keyframe_insert": cmd_keyframe_insert,
    "set_frame": cmd_set_frame,
    "set_active_camera": cmd_set_active_camera,
    "track_to": cmd_track_to,
    "cursor_to_selected": cmd_cursor_to_selected,
    "randomize_transform": cmd_randomize_transform,
    "hide_render": cmd_hide_render,
    "subdivision": cmd_subdivision,
    "origin_to_geometry": cmd_origin_to_geometry,
}

try:
    fn = DISPATCH.get(str(CMD).strip())
    if not fn:
        emit({"ok": False, "error": "unknown blender command: " + str(CMD)})
    else:
        fn()
except Exception as exc:  # structured failure classes (1.84.0) - never a bare traceback
    emit(classify_exception(exc, CMD))
